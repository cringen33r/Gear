# a11y: управление с клавиатуры

- `focus-realm/` — переход по Tab между крупными областями UI в порядке ОКП, а не DOM, в том числе через `iframe`;
- `grid/` — навигация по таблицам: указатель по строкам или ячейкам, выделение диапазона, вход в ячейку;
- `hotkeys.service.ts` — глобальные горячие клавиши;
- `keyboard-event-manager.ts` — общая таблица привязок клавиш для всего перечисленного.

Включается токенами `FOCUS_REALM_ENABLED_TOKEN` и `GRID_KEYBOARD_ENABLED_TOKEN` (по умолчанию выключено).

## Клавиши

| Где | Клавиши | Действие |
| --- | --- | --- |
| везде | Tab / Shift+Tab за краем области | следующая / предыдущая доступная область |
| везде | Tab / Shift+Tab на `<body>` | первая / последняя доступная область |
| везде | Ctrl+Tab / Ctrl+Shift+Tab | следующая / предыдущая область сразу |
| таблица | ↑ ↓ ← →, Home / End | навигация; с Shift — выделение строк |
| таблица | Ctrl+A | выделить все строки |
| таблица | Alt (отдельно) | режим строк / ячеек |
| таблица | Enter / Space | действия из `gridActionsConfig` (по умолчанию Enter — войти в ячейку) |
| таблица | Escape | выйти из ячейки |
| таблица | Tab | уйти из таблицы |
| таблица | `customGridActions` | пользовательские действия, например Delete |

Ctrl+Tab обычные браузеры не передают странице: там сочетание стоит сменить в `HotkeysService`.

## Области фокуса

```html
<main webuiFocusRealm="content">…</main>
```

```ts
router.init('moduled-core'); // 'monolith-core' | 'moduled-core' | 'module'

router.iframeJumpRequest$.subscribe((request) => frame.contentWindow?.postMessage(request, MODULE_ORIGIN));
window.addEventListener('message', (event) => {
  if (event.origin === MODULE_ORIGIN) {
    router.acceptExternalRequest(event.data); // некорректные данные отбрасываются
  }
});
```

Директива регистрирует область и ставит до и после неё невидимые порталы. Tab за край области попадает на портал, и тот просит роутер о переходе.

### Защита от циклов

Области образуют кольцо (`FOCUS_REALM_ORDER`). Роутер проверяет области по шагам от исходной: шаг 1 — соседняя, шаг N — сама исходная. Если на шаге k область в соседнем документе, роутер передаёт ему `{ hostRealmId, direction, step: k }`, и сосед продолжает обход с шага k, а не начинает заново. Шаг только растёт, после шага N обход прекращается. Поэтому документы не могут перекидывать запрос друг другу бесконечно — даже при рассогласованной конфигурации, когда оба считают область чужой.

Область, которая не смогла принять фокус, тоже продолжает тот же обход с `step + 1`.

## Таблицы

Компонент таблицы наследует `GridBaseComponent`, предоставляет `GridService` и вызывает `gridService.init(...)` при каждом изменении строк или колонок (указатель сохраняет позицию). Сущности наследуют `GridEntityComponent` с `entity = 'header' | 'row' | 'cell'` и `gridEntityId` (id колонки, строки или `'<rowId>:<columnId>'`). Id строк должны совпадать с `TreeNode.id`.

## Изменения API относительно версии из продукта

- Роутер: вместо `routingRequestSubject$.next(...)` — `requestRouting(...)`; сообщения соседа — в `acceptExternalRequest(data)`. Запросы для соседа (`iframeJumpRequest$`) содержат `step`, его нужно передавать как есть. `unregisterRealm` принимает функцию проверки, переданную при регистрации.
- `RealmRouterConfig`: `register` / `unregister` / `getPresence` / `isAvailable`.
- `GridEntityComponent`, `GridBaseComponent` — абстрактные `@Directive()`.
- `CustomGridActions`: модификаторы сравниваются точно (Delete не срабатывает на Ctrl+Delete).
- Удалены `KnownKeys`, `downKeys` / `upKeys` / `badKeys`.

Модули продукта, которых нет в репозитории, заменены заглушками в `src/app/mocks`.
