import { distinctUntilChanged, filter } from 'rxjs/operators';
import { FocusMonitor } from '@angular/cdk/a11y';
import { Component, DestroyRef, ElementRef, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { injectDebugFor } from '../../mocks/debug';

import { FocusDirection, FocusRealmId } from './focus-realm.types';
import { FocusRealmRouterService } from './focus-realm-router.service';
import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';

/**
 * Невидимый фокусируемый элемент на границе области фокуса. Создаётся {@link FocusRealmDirective} перед областью
 * (`backward`) и после неё (`forward`).
 *
 * Пока фокус внутри области, портал «взведён» (`tabindex="0"`): штатный Tab с последнего элемента области
 * попадает на портал, и портал запрашивает у роутера прыжок в следующую область. В остальное время портал
 * исключён из табуляции.
 */
@Component({
  selector: 'webui-focus-portal',
  template: ``,
  host: {
    class: 'cdk-visually-hidden',
    '[class.forward]': 'direction() === "forward"',
    '[class.backward]': 'direction() === "backward"',
    '[style.outline]': '"none"',
    tabindex: '-1',
  },
})
export class FocusPortalComponent {
  readonly hostRealmId = input.required<FocusRealmId>();
  readonly direction = input.required<FocusDirection>();

  private readonly focusMonitor = inject(FocusMonitor);
  private readonly host: HTMLElement = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly destroyRef = inject(DestroyRef);
  private readonly focusRealmRouter = inject(FocusRealmRouterService);
  private readonly debug = injectDebugFor('FOCUS_REALM');
  private readonly featureToken = inject(FOCUS_REALM_ENABLED_TOKEN);

  protected readonly isArmed = signal(false);

  constructor() {
    if (this.featureToken) {
      this.subscribeToFocused();
    }
  }

  /**
   * Включает портал в табуляцию и выключает из неё. `tabindex` выставляется синхронно, а не привязкой в шаблоне:
   * Tab может прийти раньше следующего change detection, и невзведённый портал браузер пропустит.
   */
  setArmed(isArmed: boolean): void {
    this.isArmed.set(isArmed);
    this.host.tabIndex = isArmed ? 0 : -1;
  }

  /** Срабатывает только на попадание табуляцией (`'keyboard'`) во взведённый портал. */
  private subscribeToFocused(): void {
    this.focusMonitor
      .monitor(this.host)
      .pipe(
        distinctUntilChanged(),
        filter((focusOrigin) => focusOrigin === 'keyboard' && this.isArmed()),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe(() => {
        this.debug.debug(
          'PORTAL',
          this.hostRealmId(),
          `Leaving through ${this.direction()}-portal`,
        );
        this.focusRealmRouter.requestRouting({
          hostRealmId: this.hostRealmId(),
          direction: this.direction(),
        });
      });
    this.destroyRef.onDestroy(() => this.focusMonitor.stopMonitoring(this.host));
  }
}
