import { InjectionToken } from '@angular/core';

/**
 * Включает области фокуса ({@link FocusRealmRouterService}, {@link FocusRealmDirective}) и встроенные горячие клавиши
 * перехода между ними. По умолчанию выключено: директивы областей ничего не делают.
 */
export const FOCUS_REALM_ENABLED_TOKEN = new InjectionToken<boolean>(
  'Токен, активирующий функционал фокусных областей UI',
  {
    factory: (): boolean => false,
  },
);
