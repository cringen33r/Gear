import { createEnvironmentInjector, EnvironmentInjector } from '@angular/core';
import { TestBed } from '@angular/core/testing';

import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';
import { FocusRealmRouterService } from './focus-realm-router.service';
import { FocusRealmId, FocusRealmJumpEvent, RealmRouterType } from './focus-realm.types';

function pressTab(target: EventTarget, init: KeyboardEventInit = {}): KeyboardEvent {
  const event = new KeyboardEvent('keydown', {
    code: 'Tab',
    bubbles: true,
    cancelable: true,
    ...init,
  });
  target.dispatchEvent(event);
  return event;
}

const routerInjectors: EnvironmentInjector[] = [];

/** A router in its own injector, as in a separate document. */
function createRouter(type: RealmRouterType): FocusRealmRouterService {
  const injector = createEnvironmentInjector(
    [{ provide: FOCUS_REALM_ENABLED_TOKEN, useValue: true }, FocusRealmRouterService],
    TestBed.inject(EnvironmentInjector),
  );
  routerInjectors.push(injector);
  const router = injector.get(FocusRealmRouterService);
  router.init(type);
  return router;
}

function collectJumps(router: FocusRealmRouterService): (FocusRealmId | undefined)[] {
  const targets: (FocusRealmId | undefined)[] = [];
  router.realmJumpEvent$.subscribe((jump) => targets.push(jump.targetRealmId));
  return targets;
}

describe('FocusRealmRouterService', () => {
  let router: FocusRealmRouterService;
  let jumps: FocusRealmJumpEvent[];

  function setup(type: RealmRouterType = 'monolith-core', isEnabled = true): void {
    TestBed.configureTestingModule({
      providers: [{ provide: FOCUS_REALM_ENABLED_TOKEN, useValue: isEnabled }],
    });
    router = TestBed.inject(FocusRealmRouterService);
    router.init(type);
    jumps = [];
    router.realmJumpEvent$.subscribe((jump) => jumps.push(jump));
  }

  /** Registers a button as a realm; a jump to the realm focuses the button. */
  function addRealm(realmId: FocusRealmId, isAvailable = (): boolean => true): HTMLElement {
    const button = document.createElement('button');
    document.body.appendChild(button);
    router.registerRealm(realmId, isAvailable);
    router.realmJumpEvent$.subscribe((jump) => jump.targetRealmId === realmId && button.focus());
    return button;
  }

  afterEach(() => {
    routerInjectors.splice(0).forEach((injector) => injector.destroy());
    TestBed.resetTestingModule();
    document.body.innerHTML = '';
  });

  describe('routing within a document', () => {
    beforeEach(() => setup());

    it('jumps to the next available realm in the order, skipping unavailable ones', () => {
      addRealm('tabs');
      addRealm('contextPanel', () => false);
      addRealm('navPanel');

      router.requestRouting({ hostRealmId: 'tabs', direction: 'forward' });

      expect(jumps.map((jump) => jump.targetRealmId)).toEqual(['navPanel']);
    });

    it('wraps around in both directions', () => {
      addRealm('tabs');
      addRealm('mainToolbarSMP');

      router.requestRouting({ hostRealmId: 'mainToolbarSMP', direction: 'forward' });
      router.requestRouting({ hostRealmId: 'tabs', direction: 'backward' });

      expect(jumps.map((jump) => jump.targetRealmId)).toEqual(['tabs', 'mainToolbarSMP']);
    });

    it('from <body> starts at the first realm forward and at the last realm backward', () => {
      addRealm('tabs');
      addRealm('navPanel');

      router.requestRouting({ hostRealmId: undefined, direction: 'forward' });
      router.requestRouting({ hostRealmId: undefined, direction: 'backward' });

      expect(jumps.map((jump) => jump.targetRealmId)).toEqual(['tabs', 'navPanel']);
    });

    it('the only available realm wraps to itself', () => {
      addRealm('content');

      router.requestRouting({ hostRealmId: 'content', direction: 'forward' });

      expect(jumps.map((jump) => jump.targetRealmId)).toEqual(['content']);
    });

    it('reports no target when nothing is available', () => {
      addRealm('content', () => false);

      router.requestRouting({ hostRealmId: 'content', direction: 'forward' });

      expect(jumps.map((jump) => jump.targetRealmId)).toEqual([undefined]);
    });

    it('continuing a walk past the full circle stops it', () => {
      addRealm('content');

      router.requestRouting({ hostRealmId: 'content', direction: 'forward', step: 13 });

      expect(jumps.map((jump) => jump.targetRealmId)).toEqual([undefined]);
    });

    it('a stale directive cannot unregister a newer one with the same id', () => {
      const oldChecker = (): boolean => true;
      const newChecker = (): boolean => true;
      router.registerRealm('content', oldChecker);
      router.registerRealm('content', newChecker);

      router.unregisterRealm('content', oldChecker);

      expect(router.config.getPresence('content')).toBe('local');
    });
  });

  it('ignores requests before init and when disabled', () => {
    setup('monolith-core', false);
    router.registerRealm('content', () => true);

    router.requestRouting({ hostRealmId: undefined, direction: 'forward' });

    expect(jumps).toEqual([]);
  });

  describe('neighbour documents', () => {
    it('hands the walk over with its step and blurs the local focus', () => {
      setup('moduled-core');
      const requests = vi.fn();
      router.iframeJumpRequest$.subscribe(requests);
      addRealm('mainToolbarSMP').focus();

      router.requestRouting({ hostRealmId: 'mainToolbarSMP', direction: 'backward' });

      // modulesMenu (step 1) is not registered, navPanel (step 2) is in the module
      expect(requests).toHaveBeenCalledWith({
        hostRealmId: 'mainToolbarSMP',
        direction: 'backward',
        step: 2,
      });
      expect(document.activeElement).toBe(document.body);
      expect(jumps).toEqual([]);
    });

    it.each([
      null,
      'forward',
      { direction: 'sideways' },
      { hostRealmId: '__proto__', direction: 'forward' },
      { hostRealmId: 'tabs', direction: 'forward', step: 0 },
      { hostRealmId: 'tabs', direction: 'forward', step: 13 },
      { hostRealmId: 'tabs', direction: 'forward', step: 1.5 },
    ])('rejects malformed external data %o', (data) => {
      setup('module');

      expect(router.acceptExternalRequest(data)).toBe(false);
      expect(jumps).toEqual([]);
    });

    describe('core and module connected to each other', () => {
      let core: FocusRealmRouterService;
      let module: FocusRealmRouterService;
      let handovers: number;

      function connect(): void {
        handovers = 0;
        const forward = (to: FocusRealmRouterService) => (request: unknown) => {
          // Safety net for the test itself: a regression must fail, not hang
          if (++handovers <= 50) {
            to.acceptExternalRequest(request);
          }
        };
        core.iframeJumpRequest$.subscribe(forward(module));
        module.iframeJumpRequest$.subscribe(forward(core));
      }

      it('an unavailable core realm does not bounce the request between documents', () => {
        core = createRouter('moduled-core');
        module = createRouter('module');
        connect();
        core.registerRealm('modulesMenu', () => true);
        core.registerRealm('mainToolbarSMP', () => false);
        module.registerRealm('content', () => false);
        const coreJumps = collectJumps(core);

        core.requestRouting({ hostRealmId: 'modulesMenu', direction: 'forward' });

        // core → module (nothing available there) → back to modulesMenu, which is the end of the circle
        expect(handovers).toBe(2);
        expect(coreJumps).toEqual(['modulesMenu']);
      });

      it('lands in the module realm that follows', () => {
        core = createRouter('moduled-core');
        module = createRouter('module');
        connect();
        core.registerRealm('modulesMenu', () => true);
        module.registerRealm('tabs', () => false);
        module.registerRealm('content', () => true);
        const moduleJumps = collectJumps(module);

        core.requestRouting({ hostRealmId: 'modulesMenu', direction: 'forward' });

        expect(handovers).toBe(1);
        expect(moduleJumps).toEqual(['content']);
      });

      it('stops after a full circle when nothing is available anywhere', () => {
        core = createRouter('moduled-core');
        module = createRouter('module');
        connect();
        core.registerRealm('modulesMenu', () => false);
        const coreJumps = collectJumps(core);
        const moduleJumps = collectJumps(module);

        core.requestRouting({ hostRealmId: 'modulesMenu', direction: 'forward' });

        expect(handovers).toBe(2);
        expect([...coreJumps, ...moduleJumps]).toEqual([undefined]);
      });

      it('terminates even when both documents consider the same realms foreign', () => {
        core = createRouter('moduled-core');
        module = createRouter('moduled-core');
        connect();
        const jumps = [...collectJumps(core), ...collectJumps(module)];

        core.requestRouting({ hostRealmId: undefined, direction: 'forward' });

        expect(handovers).toBeLessThanOrEqual(12);
        expect(jumps).toEqual([]);
      });
    });
  });

  describe('Tab from <body>', () => {
    it('moves focus into realms with Tab and Shift+Tab', () => {
      setup();
      const button = addRealm('content');

      const forward = pressTab(document.body);
      button.blur();
      const backward = pressTab(document.body, { shiftKey: true });

      expect(forward.defaultPrevented).toBe(true);
      expect(backward.defaultPrevented).toBe(true);
      expect(document.activeElement).toBe(button);
    });

    it('stays native when no realm takes focus', () => {
      setup();

      expect(pressTab(document.body).defaultPrevented).toBe(false);
    });

    it('is intercepted when the walk is handed to a neighbour', () => {
      setup('moduled-core');

      expect(pressTab(document.body).defaultPrevented).toBe(true);
    });

    it('is not intercepted when an element has focus or with Ctrl', () => {
      setup();
      addRealm('content');
      const button = document.createElement('button');
      document.body.appendChild(button);

      expect(pressTab(document.body, { ctrlKey: true }).defaultPrevented).toBe(false);
      button.focus();
      expect(pressTab(button).defaultPrevented).toBe(false);
    });

    it('a repeated init does not duplicate handling', () => {
      setup();
      addRealm('content');
      router.init('monolith-core');

      pressTab(document.body);

      expect(jumps).toHaveLength(1);
    });
  });
});
