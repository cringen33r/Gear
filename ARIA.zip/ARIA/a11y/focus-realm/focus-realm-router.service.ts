import { Observable, Subject } from 'rxjs';
import { DestroyRef, DOCUMENT, inject, Injectable, signal } from '@angular/core';

import { injectDebugFor } from '../../mocks/debug';
import { KeyboardEventManager, Modifier } from '../keyboard-event-manager';

import {
  FocusRealmId,
  FocusRealmJumpEvent,
  FocusRoutingRequestEvent,
  ModuleToolbarRealmId,
  RealmRouterType,
} from './focus-realm.types';
import { findNextStep, getRealmAtStep, toRoutingRequest } from './focus-realm.utils';
import { RealmRouterConfig } from './realm-router-config';
import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';

/**
 * Маршрутизация табуляции между областями интерфейса в обход нативного DOM-порядка по
 * {@link https://wiki.infotecs.int/spaces/UEG/pages/218846316/%D0%9E%D0%9A%D0%9F+%D0%A3%D0%BF%D1%80%D0%B0%D0%B2%D0%BB%D0%B5%D0%BD%D0%B8%D0%B5+%D1%81+%D0%BA%D0%BB%D0%B0%D0%B2%D0%B8%D0%B0%D1%82%D1%83%D1%80%D1%8B | ОКП «Управление с клавиатуры»}.
 *
 * Вмешивается, только когда пользователь выходит из области табуляцией (портал {@link FocusPortalComponent})
 * или фокус сброшен на `<body>`. Находит следующую доступную область и сообщает о прыжке ({@link realmJumpEvent$});
 * если область в соседнем документе — выдаёт запрос в {@link iframeJumpRequest$}.
 *
 * ### Подключение
 * 1. Включить {@link FOCUS_REALM_ENABLED_TOKEN} и вызвать {@link init} с типом роутера документа.
 * 2. Пересылать {@link iframeJumpRequest$} в соседний документ через `postMessage`.
 * 3. Полученное от соседа сообщение (проверив `event.origin`) передать в {@link acceptExternalRequest}.
 * 4. Повесить {@link FocusRealmDirective} на контейнеры областей (см. {@link FocusRealmId}).
 *
 * ### Защита от циклов
 * Обход кольца областей ведётся по шагам ({@link FocusRoutingRequestEvent.step}). Сосед продолжает обход с шага,
 * на котором его передали, и никогда не начинает заново, поэтому шаг только растёт. После полного круга
 * обход прекращается, даже если документы продолжают передавать его друг другу.
 */
@Injectable({
  providedIn: 'root',
})
export class FocusRealmRouterService {
  private readonly document = inject(DOCUMENT);
  private readonly featureToken = inject(FOCUS_REALM_ENABLED_TOKEN);
  private readonly debug = injectDebugFor('FOCUS_REALM');
  private detachKeyboard: (() => void) | null = null;
  /** Последний запрос передан в соседний документ. */
  private isLastRoutedToIframe = false;

  /** Существует с момента создания: области могут регистрироваться и до {@link init}. */
  readonly config = new RealmRouterConfig('monolith-core');

  /** Область, в которой сейчас фокус (обновляется прыжками и фокусом внутри области). */
  readonly currentRealm = signal<FocusRealmId | undefined>(undefined);

  private readonly realmJumpEventSubject$ = new Subject<FocusRealmJumpEvent>();
  readonly realmJumpEvent$: Observable<FocusRealmJumpEvent> =
    this.realmJumpEventSubject$.asObservable();

  private readonly iframeJumpRequestSubject$ = new Subject<Required<FocusRoutingRequestEvent>>();
  /** Запросы для соседнего документа: следующая область находится там. */
  readonly iframeJumpRequest$: Observable<Required<FocusRoutingRequestEvent>> =
    this.iframeJumpRequestSubject$.asObservable();

  /** Tab, когда фокус сброшен на `<body>`, уводит в области. */
  private readonly keyboard = new KeyboardEventManager([
    {
      code: 'Tab',
      modifiers: [Modifier.None, Modifier.Shift],
      repeat: true,
      when: () => this.isFocusReset(),
      // Маршрутизация синхронна: если фокус не перешёл в область и запрос не ушёл соседу, Tab остаётся нативным
      handler: (event) => {
        this.isLastRoutedToIframe = false;
        this.requestRouting({
          hostRealmId: undefined,
          direction: event.shiftKey ? 'backward' : 'forward',
        });
        return !this.isFocusReset() || this.isLastRoutedToIframe;
      },
    },
  ]);

  constructor() {
    inject(DestroyRef).onDestroy(() => this.detachKeyboard?.());
  }

  /** Включает маршрутизацию; повторный вызов только меняет тип роутера. */
  init(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId): void {
    if (!this.featureToken) {
      return;
    }
    this.config.changeType(type, moduleToolbarId);
    this.detachKeyboard ??= this.keyboard.attach(this.document);
  }

  registerRealm(realmId: FocusRealmId, checker: () => boolean): void {
    this.config.register(realmId, checker);
  }

  unregisterRealm(realmId: FocusRealmId, checker: () => boolean): void {
    this.config.unregister(realmId, checker);
  }

  /** Прыжок из области `hostRealmId` (или с `<body>`) к следующей доступной. */
  requestRouting(request: FocusRoutingRequestEvent): void {
    if (this.isInitialized) {
      this.route(request, false);
    }
  }

  /**
   * Запрос от соседнего документа. Некорректные данные отбрасываются.
   * @returns `true`, если запрос принят.
   */
  acceptExternalRequest(data: unknown): boolean {
    const request = toRoutingRequest(data);
    if (!request || !this.isInitialized) {
      this.debug.warn('REQUEST', 'EXTERNAL', 'Rejected');
      return false;
    }
    this.route(request, true);
    return true;
  }

  private route(
    { hostRealmId, direction, step: fromStep = 1 }: FocusRoutingRequestEvent,
    isExternal: boolean,
  ): void {
    // Сосед передал обход на шаге, где область для него в iframe, т.е. должна быть здесь. Если и здесь она
    // 'iframe' (рассогласованная конфигурация), пропускаем её — иначе запрос вернулся бы с тем же шагом.
    const handedRealm = isExternal ? getRealmAtStep(hostRealmId, direction, fromStep) : undefined;
    const step = findNextStep(hostRealmId, direction, fromStep, (realmId) =>
      realmId === handedRealm
        ? this.config.getPresence(realmId) === 'local' && this.config.isAvailable(realmId)
        : this.config.isAvailable(realmId),
    );
    if (step === null) {
      this.debug.warn('ROUTING', hostRealmId, 'No available realms');
      this.realmJumpEventSubject$.next({
        hostRealmId,
        direction,
        step: fromStep,
        targetRealmId: undefined,
      });
      return;
    }
    const targetRealmId = getRealmAtStep(hostRealmId, direction, step);
    this.debug.log('ROUTING', hostRealmId, `${direction} → ${targetRealmId} (step ${step})`);
    if (this.config.getPresence(targetRealmId) === 'iframe') {
      this.isLastRoutedToIframe = true;
      // Фокус уходит в другой документ: снимаем его здесь, чтобы при возврате сработал сброс на <body>
      (this.document.activeElement as HTMLElement | null)?.blur();
      this.currentRealm.set(undefined);
      this.iframeJumpRequestSubject$.next({ hostRealmId, direction, step });
    } else {
      this.realmJumpEventSubject$.next({ hostRealmId, direction, step, targetRealmId });
    }
  }

  private get isInitialized(): boolean {
    return this.detachKeyboard !== null;
  }

  private isFocusReset(): boolean {
    const active = this.document.activeElement;
    return !active || active === this.document.body;
  }
}
