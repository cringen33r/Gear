import { InteractivityChecker } from '@angular/cdk/a11y';
import { Component, signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';
import { FocusRealmDirective } from './focus-realm.directive';
import { FocusRealmRouterService } from './focus-realm-router.service';
import { FocusRealmId } from './focus-realm.types';

/** jsdom has no layout: tabbability is decided by tabIndex. */
const checkerStub: Partial<InteractivityChecker> = {
  isFocusable: (element) => element.tabIndex >= 0,
  isTabbable: (element) => element.tabIndex >= 0,
};

@Component({
  imports: [FocusRealmDirective],
  template: `
    <div webuiFocusRealm="tabs" data-testid="tabs">
      <button data-testid="tabs-1">1</button>
      <button data-testid="tabs-2">2</button>
    </div>
    @if (showContent()) {
      <div [webuiFocusRealm]="contentId()" data-testid="content">
        @if (hasContentButton()) {
          <button data-testid="content-1">c</button>
        }
      </div>
    }
  `,
})
class HostComponent {
  readonly showContent = signal(true);
  readonly contentId = signal<FocusRealmId | undefined>('content');
  readonly hasContentButton = signal(true);
}

describe('FocusRealmDirective', () => {
  let fixture: ComponentFixture<HostComponent>;
  let router: FocusRealmRouterService;

  async function setup(isEnabled = true): Promise<void> {
    TestBed.configureTestingModule({
      providers: [
        { provide: FOCUS_REALM_ENABLED_TOKEN, useValue: isEnabled },
        { provide: InteractivityChecker, useValue: checkerStub },
      ],
    });
    router = TestBed.inject(FocusRealmRouterService);
    router.init('monolith-core');
    fixture = TestBed.createComponent(HostComponent);
    document.body.appendChild(fixture.nativeElement);
    await fixture.whenStable();
  }

  function query(testId: string): HTMLElement | null {
    return fixture.nativeElement.querySelector(`[data-testid="${testId}"]`);
  }

  function portalsAround(testId: string): { before: Element | null; after: Element | null } {
    const host = query(testId);
    return {
      before: host?.previousElementSibling ?? null,
      after: host?.nextElementSibling ?? null,
    };
  }

  afterEach(() => {
    fixture?.destroy();
    TestBed.resetTestingModule();
    document.body.innerHTML = '';
  });

  it('registers the realm after render and sets the data attribute', async () => {
    await setup();

    expect(query('tabs')?.getAttribute('data-focusrealm')).toBe('tabs');
    expect(router.config.getPresence('tabs')).toBe('local');
    expect(router.config.getPresence('content')).toBe('local');
  });

  it('creates the backward portal before the realm and the forward one after it', async () => {
    await setup();

    const { before, after } = portalsAround('tabs');
    expect(before?.tagName).toBe('WEBUI-FOCUS-PORTAL');
    expect(before?.classList).toContain('backward');
    expect(after?.tagName).toBe('WEBUI-FOCUS-PORTAL');
    expect(after?.classList).toContain('forward');
    expect(after?.classList).toContain('cdk-visually-hidden');
    expect(after?.getAttribute('tabindex')).toBe('-1');
  });

  it('a jump focuses the first element and arms the portals', async () => {
    await setup();

    router.requestRouting({ hostRealmId: 'tabs', direction: 'forward' });

    // No change detection wait: Tab may come right after the jump
    expect(document.activeElement).toBe(query('content-1'));
    expect(router.currentRealm()).toBe('content');
    expect(portalsAround('content').after?.getAttribute('tabindex')).toBe('0');
    expect(portalsAround('tabs').after?.getAttribute('tabindex')).toBe('-1');
  });

  it('a backward jump focuses the last element', async () => {
    await setup();

    router.requestRouting({ hostRealmId: 'content', direction: 'backward' });

    expect(document.activeElement).toBe(query('tabs-2'));
  });

  it('a realm without focusable elements is skipped', async () => {
    await setup();
    fixture.componentInstance.hasContentButton.set(false);
    await fixture.whenStable();

    router.requestRouting({ hostRealmId: 'tabs', direction: 'forward' });

    expect(document.activeElement).toBe(query('tabs-1'));
  });

  it('destroying the realm removes its registration and portals', async () => {
    await setup();
    fixture.componentInstance.showContent.set(false);
    await fixture.whenStable();

    expect(router.config.getPresence('content')).toBeUndefined();
    expect(fixture.nativeElement.querySelectorAll('webui-focus-portal')).toHaveLength(2);
  });

  it('a re-shown realm registers again', async () => {
    await setup();
    fixture.componentInstance.showContent.set(false);
    await fixture.whenStable();
    fixture.componentInstance.showContent.set(true);
    await fixture.whenStable();

    router.requestRouting({ hostRealmId: 'tabs', direction: 'forward' });

    expect(document.activeElement).toBe(query('content-1'));
  });

  it('changing the id re-registers the realm', async () => {
    await setup();
    fixture.componentInstance.contentId.set('navPanel');
    await fixture.whenStable();

    expect(router.config.getPresence('content')).toBeUndefined();
    expect(router.config.getPresence('navPanel')).toBe('local');
    expect(query('content')?.getAttribute('data-focusrealm')).toBe('navPanel');
  });

  it('a realm without an id is not registered', async () => {
    await setup();
    fixture.componentInstance.contentId.set(undefined);
    await fixture.whenStable();

    expect(router.config.getPresence('content')).toBeUndefined();
  });

  it('focus inside a realm (e.g. by mouse) updates the current realm', async () => {
    await setup();

    query('tabs-2')?.focus();
    await fixture.whenStable();

    expect(router.currentRealm()).toBe('tabs');
    expect(portalsAround('tabs').after?.getAttribute('tabindex')).toBe('0');
  });

  it('does nothing when disabled and is destroyed without errors', async () => {
    await setup(false);

    expect(fixture.nativeElement.querySelectorAll('webui-focus-portal')).toHaveLength(0);
    expect(router.config.getPresence('tabs')).toBeUndefined();
    fixture.componentInstance.showContent.set(false);
    await fixture.whenStable();
    expect(() => fixture.destroy()).not.toThrow();
  });
});
