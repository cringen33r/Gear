import { distinctUntilChanged, map } from 'rxjs/operators';
import { FocusMonitor, InteractivityChecker } from '@angular/cdk/a11y';
import {
  afterRenderEffect,
  ComponentRef,
  DestroyRef,
  Directive,
  ElementRef,
  inject,
  input,
  inputBinding,
  linkedSignal,
  Renderer2,
  untracked,
  ViewContainerRef,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { injectDebugFor } from '../../mocks/debug';
import { FocusBoundary, focusFocusableChild, getFocusableChild } from '../focus-utils';

import { FocusPortalComponent } from './focus-portal.component';
import { FocusDirection, FocusRealmId, FocusRealmJumpEvent } from './focus-realm.types';
import { FocusRealmRouterService } from './focus-realm-router.service';
import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';

/**
 * Директива области фокуса UI: `<div webuiFocusRealm="content">`.
 *
 * Ответственность:
 * 1. Регистрация области в {@link FocusRealmRouterService} (и перерегистрация при смене id);
 * 2. Создание порталов ({@link FocusPortalComponent}) до и после области;
 * 3. Установка фокуса на содержимое по событию прыжка ({@link FocusRealmRouterService.realmJumpEvent$});
 * 4. Взведение порталов, пока фокус внутри области.
 *
 * При выключенном {@link FOCUS_REALM_ENABLED_TOKEN} директива ничего не делает.
 */
@Directive({
  selector: '[webuiFocusRealm]',
  host: {
    '[attr.data-focusrealm]': 'realmId()',
  },
})
export class FocusRealmDirective {
  readonly webuiFocusRealm = input<FocusRealmId | undefined>(undefined);
  /** Идентификатор области. По умолчанию берётся из входа, но может быть переопределён программно. */
  readonly realmId = linkedSignal(() => this.webuiFocusRealm());

  private readonly host: HTMLElement = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly focusRealmRouter = inject(FocusRealmRouterService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly focusMonitor = inject(FocusMonitor);
  private readonly viewContainerRef = inject(ViewContainerRef);
  private readonly checker = inject(InteractivityChecker);
  private readonly renderer = inject(Renderer2);
  private readonly debug = injectDebugFor('FOCUS_REALM');
  private readonly featureToken = inject(FOCUS_REALM_ENABLED_TOKEN);

  /** Порталы `[backward, forward]`; создаются при первой регистрации. */
  private portals: ComponentRef<FocusPortalComponent>[] = [];
  private registeredRealmId: FocusRealmId | undefined;
  private disarmTimeout: ReturnType<typeof setTimeout> | undefined;
  /** Проверка доступности, переданная роутеру. По ней же снимается регистрация. */
  private readonly availabilityChecker = (): boolean => this.checkAvailability();

  constructor() {
    if (!this.featureToken) {
      return;
    }
    // Регистрация после рендера: порталы вставляются рядом с хостом, ему нужен родитель в DOM
    afterRenderEffect(() => {
      const realmId = this.realmId();
      untracked(() => this.syncRegistration(realmId));
    });
    this.subscribeToRealmJumps();
    this.subscribeToFocus();
    this.destroyRef.onDestroy(() => this.teardown());
  }

  private syncRegistration(realmId: FocusRealmId | undefined): void {
    if (realmId === this.registeredRealmId) {
      return;
    }
    this.unregisterSelf();
    if (!realmId) {
      this.setPortalsArmed(false);
      return;
    }
    this.setUpPortals();
    this.focusRealmRouter.registerRealm(realmId, this.availabilityChecker);
    this.registeredRealmId = realmId;
  }

  private unregisterSelf(): void {
    if (this.registeredRealmId) {
      this.focusRealmRouter.unregisterRealm(this.registeredRealmId, this.availabilityChecker);
      this.registeredRealmId = undefined;
    }
  }

  private setUpPortals(): void {
    if (this.portals.length) {
      return;
    }
    this.portals = (['backward', 'forward'] as const).map((direction) =>
      this.viewContainerRef.createComponent(FocusPortalComponent, {
        bindings: [
          inputBinding('direction', () => direction),
          inputBinding('hostRealmId', () => this.realmId()),
        ],
      }),
    );
    // Порталы создаются после хоста; задний переносим на место перед ним
    const parent = this.renderer.parentNode(this.host) as Node | null;
    parent?.insertBefore(this.portals[0].location.nativeElement, this.host);
  }

  private teardown(): void {
    clearTimeout(this.disarmTimeout);
    this.focusMonitor.stopMonitoring(this.host);
    this.unregisterSelf();
    this.portals.forEach((portal) => portal.destroy());
    this.portals = [];
  }

  private subscribeToFocus(): void {
    this.focusMonitor
      .monitor(this.host, true)
      .pipe(
        map((origin) => origin !== null),
        distinctUntilChanged(),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((isFocused) => {
        const realmId = this.registeredRealmId;
        if (!realmId) {
          return;
        }
        clearTimeout(this.disarmTimeout);
        if (isFocused) {
          this.debug.log('FOCUS', realmId, 'Focused');
          this.setPortalsArmed(true);
          this.focusRealmRouter.currentRealm.set(realmId);
        } else {
          // Отложенно: при выходе табуляцией фокус переходит на портал, и тот должен оставаться взведённым,
          // пока FocusMonitor не определит источник фокуса
          this.disarmTimeout = setTimeout(() => this.setPortalsArmed(false));
        }
      });
  }

  private setPortalsArmed(isArmed: boolean): void {
    this.portals.forEach((portal) => portal.instance.setArmed(isArmed));
  }

  private subscribeToRealmJumps(): void {
    this.focusRealmRouter.realmJumpEvent$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((jump) => this.handleJump(jump));
  }

  private handleJump(jump: FocusRealmJumpEvent): void {
    const realmId = this.registeredRealmId;
    if (!realmId) {
      return;
    }
    if (jump.targetRealmId !== realmId) {
      this.setPortalsArmed(false);
      return;
    }
    if (this.checkAvailability() && this.setFocus(jump.direction)) {
      this.setPortalsArmed(true);
      this.focusRealmRouter.currentRealm.set(realmId);
      return;
    }
    // Продолжаем тот же обход со следующего шага: новый обход от этой области мог бы зациклиться
    this.debug.warn('REALM', realmId, 'Realm is unreachable, requesting further routing');
    this.setPortalsArmed(false);
    this.focusRealmRouter.requestRouting({ ...jump, step: jump.step + 1 });
  }

  private setFocus(direction: FocusDirection): boolean {
    const boundary: FocusBoundary = direction === 'forward' ? 'start' : 'end';
    return focusFocusableChild(this.host, boundary, this.checker);
  }

  private checkAvailability(): boolean {
    if (!this.host.isConnected || !this.host.parentElement) {
      this.debug.error('FOCUS', this.realmId(), 'No connection to DOM');
      return false;
    }
    const hasFocusable = !!getFocusableChild(this.host, 'start', this.checker);
    if (!hasFocusable) {
      this.debug.warn('FOCUS', this.realmId(), 'No focusable children');
    }
    return hasFocusable;
  }
}
