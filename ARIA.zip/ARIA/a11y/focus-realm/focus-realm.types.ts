/** Области тулбаров модулей: у каждого модуля собственный компонент тулбара, поэтому области заданы явно. */
export const MODULE_TOOLBAR_REALM_IDS = [
  'mainToolbarVPN',
  'mainToolbarNVS',
  'mainToolbarPMM',
  'mainToolbarCB',
  'mainToolbarROC',
] as const;

/**
 * Все области фокуса UI в порядке обхода по Tab. Порядок задан ОКП «Управление с клавиатуры»
 * и не совпадает с порядком в DOM.
 */
export const FOCUS_REALM_ORDER = [
  'tabs',
  'content',
  'contextPanel',
  'navPanel',
  'modulesMenu',
  // В ядре для каждого модуля свой `smp-module-page-layout` и собственный `webui-toolbar`
  'mainToolbarSMP',
  'mainToolbarAdmin',
  ...MODULE_TOOLBAR_REALM_IDS,
] as const;

export type ModuleToolbarRealmId = (typeof MODULE_TOOLBAR_REALM_IDS)[number];

/** Заранее определённые области фокуса на UI. */
export type FocusRealmId = (typeof FOCUS_REALM_ORDER)[number];

/**
 * Присутствие области: в этом же документе (`'local'`), в родительском или дочернем документе (`'iframe'`)
 * либо нигде (`undefined`).
 * Область в `iframe` считается всегда доступной, поскольку её невозможно проверить: маршрутизация передаётся
 * в соседний модуль, где эта область может быть объявлена.
 */
export type FocusRealmPresence = 'local' | 'iframe' | undefined;

/** Направление перехода фокуса. */
export type FocusDirection = 'forward' | 'backward';

/**
 * Запрос маршрутизатору на прыжок с области `hostRealmId` на следующую доступную в направлении `direction`.
 * `hostRealmId === undefined` — прыжок с `<body>`.
 *
 * Обход идёт по кольцу {@link FOCUS_REALM_ORDER}: шаг `k` — k-я область от исходной в направлении `direction`.
 * `step` — с какого шага продолжить обход (по умолчанию 1). Его передаёт соседний документ, когда следующая
 * область оказалась у него: обход продолжается, а не начинается заново, поэтому документы не могут
 * перекидывать запрос друг другу бесконечно.
 */
export interface FocusRoutingRequestEvent {
  hostRealmId: FocusRealmId | undefined;
  direction: FocusDirection;
  step?: number;
}

/**
 * Широковещательное событие о прыжке в область `targetRealmId`, найденную на шаге `step` обхода по запросу.
 * `targetRealmId === undefined` — доступных областей нет.
 */
export interface FocusRealmJumpEvent extends Required<FocusRoutingRequestEvent> {
  targetRealmId: FocusRealmId | undefined;
}

/**
 * Тип роутера в документе. Определяет, какие области находятся в соседних документах (`iframe`):
 * - `'monolith-core'` — ядро без модулей, все области локальные;
 * - `'moduled-core'` — ядро, контент модулей во вложенном `iframe` (`tabs`, `content`, `contextPanel`, `navPanel`);
 * - `'module'` — модуль во `iframe`, меню модулей и тулбар модуля — в ядре.
 */
export type RealmRouterType = 'module' | 'moduled-core' | 'monolith-core';
