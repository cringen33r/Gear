import { FOCUS_REALM_ORDER } from './focus-realm.types';
import { findNextStep, getRealmAtStep, toRoutingRequest } from './focus-realm.utils';
import { RealmRouterConfig } from './realm-router-config';

describe('focus-realm.utils', () => {
  const count = FOCUS_REALM_ORDER.length;

  it('getRealmAtStep walks the ring from the host, or from the edge without one', () => {
    expect(getRealmAtStep('tabs', 'forward', 1)).toBe('content');
    expect(getRealmAtStep('tabs', 'backward', 1)).toBe('mainToolbarROC');
    expect(getRealmAtStep('tabs', 'forward', count)).toBe('tabs');
    expect(getRealmAtStep(undefined, 'forward', 1)).toBe('tabs');
    expect(getRealmAtStep(undefined, 'backward', 1)).toBe('mainToolbarROC');
  });

  it('findNextStep returns the first available step and null past the circle', () => {
    const isAvailable = (realmId: string): boolean => realmId === 'navPanel';

    expect(findNextStep('tabs', 'forward', 1, isAvailable)).toBe(3);
    expect(findNextStep('tabs', 'forward', 4, isAvailable)).toBeNull();
    expect(findNextStep('tabs', 'forward', count + 1, () => true)).toBeNull();
  });

  describe('toRoutingRequest', () => {
    it('returns a copy with known fields only and a default step', () => {
      expect(toRoutingRequest({ hostRealmId: 'tabs', direction: 'forward', extra: 1 })).toEqual({
        hostRealmId: 'tabs',
        direction: 'forward',
        step: 1,
      });
      expect(toRoutingRequest({ direction: 'backward', step: 3 })).toEqual({
        hostRealmId: undefined,
        direction: 'backward',
        step: 3,
      });
    });

    it.each([
      undefined,
      null,
      'forward',
      { direction: 'left' },
      { hostRealmId: 'constructor', direction: 'forward' },
      { direction: 'forward', step: '2' },
      { direction: 'forward', step: count + 1 },
    ])('rejects %o', (data) => {
      expect(toRoutingRequest(data)).toBeNull();
    });
  });
});

describe('RealmRouterConfig', () => {
  it('marks neighbour realms as iframe by router type', () => {
    const core = new RealmRouterConfig('moduled-core');
    const module = new RealmRouterConfig('module', 'mainToolbarVPN');

    expect(core.getPresence('content')).toBe('iframe');
    expect(core.getPresence('modulesMenu')).toBeUndefined();
    expect(module.getPresence('modulesMenu')).toBe('iframe');
    expect(module.getPresence('mainToolbarVPN')).toBe('iframe');
    expect(module.getPresence('mainToolbarNVS')).toBeUndefined();
  });

  it('changeType resets the previous type', () => {
    const config = new RealmRouterConfig('module', 'mainToolbarVPN');

    config.changeType('monolith-core');

    expect(config.getPresence('modulesMenu')).toBeUndefined();
    expect(config.getPresence('mainToolbarVPN')).toBeUndefined();
  });

  it('a local registration wins over the type and is checked for availability', () => {
    const config = new RealmRouterConfig('moduled-core');
    let isAvailable = true;
    const checker = (): boolean => isAvailable;
    config.register('content', checker);

    expect(config.getPresence('content')).toBe('local');
    expect(config.isAvailable('content')).toBe(true);
    isAvailable = false;
    expect(config.isAvailable('content')).toBe(false);

    config.unregister('content', checker);
    expect(config.getPresence('content')).toBe('iframe');
    expect(config.isAvailable('content')).toBe(true);
  });

  it('unknown realms are unavailable', () => {
    expect(new RealmRouterConfig('monolith-core').isAvailable('content')).toBe(false);
  });
});
