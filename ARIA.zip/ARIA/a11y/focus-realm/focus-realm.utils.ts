import {
  FOCUS_REALM_ORDER,
  FocusDirection,
  FocusRealmId,
  FocusRoutingRequestEvent,
} from './focus-realm.types';

const REALM_COUNT = FOCUS_REALM_ORDER.length;

/** Область на шаге `step` кольца от `hostRealmId` (без него — от края: перед первой или после последней). */
export function getRealmAtStep(
  hostRealmId: FocusRealmId | undefined,
  direction: FocusDirection,
  step: number,
): FocusRealmId {
  const sign = direction === 'forward' ? 1 : -1;
  const edge = direction === 'forward' ? -1 : REALM_COUNT;
  const hostIndex = hostRealmId ? FOCUS_REALM_ORDER.indexOf(hostRealmId) : edge;
  const index = (((hostIndex + sign * step) % REALM_COUNT) + REALM_COUNT) % REALM_COUNT;
  return FOCUS_REALM_ORDER[index];
}

/**
 * Первый шаг начиная с `fromStep`, на котором область доступна. Шагов в кольце ровно столько, сколько областей:
 * последний шаг возвращается к самой `hostRealmId` (единственная область переходит сама в себя).
 * @returns `null`, если до конца кольца доступных областей нет.
 */
export function findNextStep(
  hostRealmId: FocusRealmId | undefined,
  direction: FocusDirection,
  fromStep: number,
  isAvailable: (realmId: FocusRealmId) => boolean,
): number | null {
  for (let step = Math.max(1, fromStep); step <= REALM_COUNT; step++) {
    if (isAvailable(getRealmAtStep(hostRealmId, direction, step))) {
      return step;
    }
  }
  return null;
}

export function isFocusRealmId(value: unknown): value is FocusRealmId {
  return (FOCUS_REALM_ORDER as readonly unknown[]).includes(value);
}

/**
 * Проверяет запрос из недоверенного источника (`postMessage`): известные область и направление,
 * целый шаг в пределах кольца. Возвращает копию только с этими полями либо `null`.
 */
export function toRoutingRequest(data: unknown): FocusRoutingRequestEvent | null {
  if (typeof data !== 'object' || data === null) {
    return null;
  }
  const { hostRealmId, direction, step = 1 } = data as Record<string, unknown>;
  const isValid =
    (hostRealmId === undefined || isFocusRealmId(hostRealmId)) &&
    (direction === 'forward' || direction === 'backward') &&
    Number.isInteger(step) &&
    (step as number) >= 1 &&
    (step as number) <= REALM_COUNT;
  return isValid ? { hostRealmId, direction, step: step as number } : null;
}
