import {
  FocusRealmId,
  FocusRealmPresence,
  ModuleToolbarRealmId,
  RealmRouterType,
} from './focus-realm.types';

/**
 * Присутствие областей фокуса в документе. Складывается из двух источников:
 * - тип роутера ({@link RealmRouterType}) отмечает области соседнего документа как `'iframe'`;
 * - регистрация директивы отмечает область как `'local'` — это важнее типа.
 */
export class RealmRouterConfig {
  private readonly iframeRealms = new Set<FocusRealmId>();
  private readonly checkers = new Map<FocusRealmId, () => boolean>();

  constructor(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId) {
    this.changeType(type, moduleToolbarId);
  }

  changeType(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId): void {
    this.iframeRealms.clear();
    if (type === 'module') {
      this.iframeRealms.add('modulesMenu');
      if (moduleToolbarId) {
        this.iframeRealms.add(moduleToolbarId);
      }
    } else if (type === 'moduled-core') {
      for (const realmId of ['tabs', 'content', 'contextPanel', 'navPanel'] as const) {
        this.iframeRealms.add(realmId);
      }
    }
  }

  getPresence(realmId: FocusRealmId | undefined): FocusRealmPresence {
    if (!realmId) {
      return undefined;
    }
    if (this.checkers.has(realmId)) {
      return 'local';
    }
    return this.iframeRealms.has(realmId) ? 'iframe' : undefined;
  }

  /** Локальная область — по проверке директивы; область соседнего документа считается доступной. */
  isAvailable(realmId: FocusRealmId): boolean {
    const checker = this.checkers.get(realmId);
    return checker ? checker() : this.iframeRealms.has(realmId);
  }

  register(realmId: FocusRealmId, checker: () => boolean): void {
    this.checkers.set(realmId, checker);
  }

  /** Снимает регистрацию, только если она принадлежит `checker`: старая директива не снимет новую с тем же id. */
  unregister(realmId: FocusRealmId, checker: () => boolean): void {
    if (this.checkers.get(realmId) === checker) {
      this.checkers.delete(realmId);
    }
  }
}
