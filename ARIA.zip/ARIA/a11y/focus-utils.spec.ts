import { InteractivityChecker } from '@angular/cdk/a11y';

import { focusFocusableChild, getFocusableChild, getNextFocusable } from './focus-utils';

/** jsdom has no layout: tabbability is decided by tabIndex and the `hidden` attribute. */
const checker = {
  isFocusable: (element: HTMLElement) => element.tabIndex >= 0 && !element.closest('[hidden]'),
  isTabbable: (element: HTMLElement) => element.tabIndex >= 0,
} as InteractivityChecker;

function render(html: string): HTMLElement {
  document.body.innerHTML = html;
  return document.body;
}

function byId(id: string): HTMLElement {
  return document.getElementById(id) as HTMLElement;
}

describe('focus-utils', () => {
  afterEach(() => {
    document.body.innerHTML = '';
  });

  describe('getFocusableChild', () => {
    beforeEach(() => {
      render(`
        <div id="root" tabindex="0">
          <span><button id="first">1</button></span>
          <button id="hidden" hidden>h</button>
          <div id="container" tabindex="0">
            <button id="nested">n</button>
          </div>
          <button id="disabled" tabindex="-1">d</button>
        </div>
      `);
    });

    it("'start' is the first in DOM order, the root itself is not considered", () => {
      expect(getFocusableChild(byId('root'), 'start', checker)).toBe(byId('first'));
    });

    it("'end' is the last in DOM order: a descendant goes after its container", () => {
      expect(getFocusableChild(byId('root'), 'end', checker)).toBe(byId('nested'));
    });

    it('skips hidden and non-tabbable elements', () => {
      byId('first').remove();

      expect(getFocusableChild(byId('root'), 'start', checker)).toBe(byId('container'));
    });

    it('returns null without candidates or root', () => {
      expect(getFocusableChild(byId('disabled'), 'start', checker)).toBeNull();
      expect(getFocusableChild(null, 'start', checker)).toBeNull();
    });
  });

  describe('focusFocusableChild', () => {
    it('focuses and reports success', () => {
      render(`<div id="root"><input id="input" /></div>`);

      expect(focusFocusableChild(byId('root'), 'start', checker)).toBe(true);
      expect(document.activeElement).toBe(byId('input'));
    });

    it('reports failure when focus did not move', () => {
      render(`<div id="root"><button id="button">b</button></div>`);
      vi.spyOn(byId('button'), 'focus').mockImplementation(() => undefined);

      expect(focusFocusableChild(byId('root'), 'start', checker)).toBe(false);
    });

    it('returns false without candidates', () => {
      render(`<div id="root"><span>text</span></div>`);

      expect(focusFocusableChild(byId('root'), 'end', checker)).toBe(false);
    });
  });

  describe('getNextFocusable', () => {
    beforeEach(() => {
      render(`
        <button id="before">before</button>
        <section>
          <div id="grid" tabindex="0"><button id="inside">i</button></div>
          <span>text</span>
        </section>
        <footer><a id="after" href="#" tabindex="0">after</a></footer>
      `);
    });

    it('forward: the first candidate after the root, climbing up the ancestors', () => {
      expect(getNextFocusable(byId('grid'), 'forward', checker)).toBe(byId('after'));
    });

    it('backward: the last candidate before the root', () => {
      expect(getNextFocusable(byId('grid'), 'backward', checker)).toBe(byId('before'));
    });

    it('does not look inside the root', () => {
      byId('after').remove();

      expect(getNextFocusable(byId('grid'), 'forward', checker)).toBeNull();
    });

    it('does not modify the DOM', () => {
      const html = document.body.innerHTML;

      getNextFocusable(byId('grid'), 'forward', checker);

      expect(document.body.innerHTML).toBe(html);
    });
  });
});
