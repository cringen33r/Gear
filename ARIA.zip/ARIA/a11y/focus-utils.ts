import { InteractivityChecker } from '@angular/cdk/a11y';

import { FeatureDebug } from '../mocks/debug';

import { FocusDirection } from './focus-realm/focus-realm.types';

/** С какого края искать: `'start'` — первый элемент в порядке DOM, `'end'` — последний. */
export type FocusBoundary = 'start' | 'end';

/**
 * Ставит фокус на первый (`'start'`) или последний (`'end'`) элемент внутри `root`, доступный для табуляции.
 * @returns `true`, если фокус действительно перешёл на найденный элемент.
 */
export function focusFocusableChild(
  root: HTMLElement,
  boundary: FocusBoundary,
  checker: InteractivityChecker,
): boolean {
  const element = getFocusableChild(root, boundary, checker);
  element?.focus();
  return !!element && element.ownerDocument.activeElement === element;
}

/**
 * Первый или последний в порядке DOM потомок `root`, доступный для табуляции. Сам `root` не рассматривается.
 * Порядок совпадает с нативной табуляцией без положительных `tabindex`.
 */
export function getFocusableChild(
  root: Element | null,
  boundary: FocusBoundary,
  checker: InteractivityChecker,
): HTMLElement | null {
  if (!root) {
    return null;
  }
  const children = Array.from(root.children);
  if (boundary === 'end') {
    children.reverse();
  }
  for (const child of children) {
    const found = findTabbable(child, boundary, checker);
    if (found) {
      return found;
    }
  }
  return null;
}

/**
 * Ближайший за пределами `root` элемент, доступный для табуляции в направлении `direction`:
 * поиск идёт по соседям `root`, затем по соседям его предков.
 * @returns `null`, если до конца документа таких элементов нет.
 */
export function getNextFocusable(
  root: HTMLElement,
  direction: FocusDirection,
  checker: InteractivityChecker,
  debug?: FeatureDebug,
): HTMLElement | null {
  const boundary: FocusBoundary = direction === 'forward' ? 'start' : 'end';
  const nextSibling = (element: Element): Element | null =>
    direction === 'forward' ? element.nextElementSibling : element.previousElementSibling;

  for (let node: Element | null = root; node; node = node.parentElement) {
    for (let sibling = nextSibling(node); sibling; sibling = nextSibling(sibling)) {
      const found = findTabbable(sibling, boundary, checker);
      if (found) {
        debug?.debug('FOCUS', found.tagName, 'Next focusable found');
        return found;
      }
    }
  }
  debug?.debug('FOCUS', root.tagName, `Nothing focusable ${direction}`);
  return null;
}

/** Сам элемент или его потомок, доступный для табуляции, с учётом порядка обхода. */
function findTabbable(
  element: Element,
  boundary: FocusBoundary,
  checker: InteractivityChecker,
): HTMLElement | null {
  const self = isTabbable(element, checker) ? element : null;
  // В порядке DOM элемент идёт раньше своих потомков
  if (boundary === 'start') {
    return self ?? getFocusableChild(element, boundary, checker);
  }
  return getFocusableChild(element, boundary, checker) ?? self;
}

function isTabbable(element: Element, checker: InteractivityChecker): element is HTMLElement {
  return (
    element instanceof HTMLElement && checker.isFocusable(element) && checker.isTabbable(element)
  );
}
