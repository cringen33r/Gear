import { filter } from 'rxjs/operators';
import { DestroyRef, Directive, inject, InputSignal, output } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { TreeNode } from '../../mocks/tree-node';

import { GridService } from './grid.service';
import { GridAction } from './grid.types';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { getRowColumnIds } from './grid-utils';

/**
 * Базовый класс компонента таблицы с клавиатурной навигацией.
 *
 * Контракт наследника:
 * - предоставить {@link GridService} в `providers` компонента;
 * - реализовать {@link initGrid} и вызывать в нём `gridService.init(...)` при каждом изменении строк или колонок;
 *   id строк в конфиге должны совпадать с `id` узлов {@link items};
 * - реализовать {@link scrollIntoCenterIfNeededById}, {@link checkNodes} и {@link expandNodes};
 * - при необходимости подписаться на {@link subscribeToGridRowPointer} для прокрутки к строке под указателем.
 *
 * Базовый класс транслирует пользовательские действия в {@link customGridAction} и выполняет действия над строками
 * из конфига (`'check'`, `'expand'`, `'toggle-context-panel'`) для строки под указателем или выделенного диапазона.
 */
@Directive()
export abstract class GridBaseComponent<T = unknown> {
  protected readonly gridService = inject(GridService);
  protected readonly destroyRef = inject(DestroyRef);
  protected readonly gridKeyboardToken = inject(GRID_KEYBOARD_ENABLED_TOKEN);

  /** Имя сработавшего пользовательского действия. */
  readonly customGridAction = output<string>();
  /** Узел, для которого нужно переключить контекстную панель. */
  readonly contextPanelToggled = output<TreeNode<T>>();

  abstract readonly items: InputSignal<TreeNode<T>[]>;

  protected constructor() {
    if (this.gridKeyboardToken) {
      this.subscribeToGridCustomActions();
      this.subscribeToGridRowActions();
    }
  }

  abstract scrollIntoCenterIfNeededById(nodeId: string): void;
  protected abstract checkNodes(nodes: TreeNode<T>[]): void;
  protected abstract expandNodes(nodes: TreeNode<T>[]): void;
  protected abstract initGrid(): void;

  /** Прокручивает таблицу к строке под указателем. */
  protected subscribeToGridRowPointer(): void {
    this.gridService.pointer$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((pointer) => {
      if (pointer?.targetId) {
        const [rowId] = getRowColumnIds(pointer.targetId);
        this.scrollIntoCenterIfNeededById(rowId);
      }
    });
  }

  private subscribeToGridCustomActions(): void {
    this.gridService.customAction$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((action) => this.customGridAction.emit(action));
  }

  private subscribeToGridRowActions(): void {
    this.gridService.gridAction$
      .pipe(
        filter((action) => action.currentPointer.state.position?.type === 'row'),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((action) => this.performRowAction(action));
  }

  private performRowAction({ action, currentPointer }: GridAction): void {
    const rowAction = this.gridService.getActionFor('row', action);
    const pointedId = currentPointer.targetId;
    const selectedIds = currentPointer.selectedTargetIds ?? (pointedId ? [pointedId] : []);
    switch (rowAction) {
      case 'check':
        this.checkNodes(this.getNodesByIds(selectedIds));
        break;
      case 'expand':
        this.expandNodes(this.getNodesByIds(selectedIds));
        break;
      case 'toggle-context-panel': {
        const [node] = pointedId ? this.getNodesByIds([pointedId]) : [];
        if (node) {
          this.contextPanelToggled.emit(node);
        }
        break;
      }
    }
  }

  /** Узлы по идентификаторам строк — устойчиво к свёрнутым узлам и виртуальной прокрутке, в отличие от индексов. */
  private getNodesByIds(ids: readonly string[]): TreeNode<T>[] {
    const idSet = new Set(ids);
    return this.items().filter((node) => idSet.has(node.id));
  }
}
