import { InteractivityChecker } from '@angular/cdk/a11y';
import { Component, ElementRef, input, signal, viewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TreeNode } from '../../mocks/tree-node';

import { GridBaseComponent } from './grid-base.component';
import { GridEntityComponent } from './grid-entity.component';
import { defaultGridActionsConfig } from './grid-keyboard-defaults.config';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { GridService } from './grid.service';

/** jsdom has no layout: tabbability is decided by tabIndex. */
const checkerStub: Partial<InteractivityChecker> = {
  isFocusable: (element) => element.tabIndex >= 0,
  isTabbable: (element) => element.tabIndex >= 0,
};

@Component({ selector: 'hw-test-cell', template: '<ng-content />' })
class TestCellComponent extends GridEntityComponent<'cell'> {
  protected entity = 'cell' as const;
}

@Component({ selector: 'hw-test-header', template: '<ng-content />' })
class TestHeaderComponent extends GridEntityComponent<'header'> {
  protected entity = 'header' as const;
}

@Component({ selector: 'hw-test-row', template: '<ng-content />' })
class TestRowComponent extends GridEntityComponent<'row'> {
  protected entity = 'row' as const;
}

@Component({
  selector: 'hw-test-grid',
  providers: [GridService],
  imports: [TestCellComponent, TestHeaderComponent, TestRowComponent],
  template: `
    <div #grid tabindex="0" data-testid="grid">
      @for (column of columns; track column) {
        <hw-test-header [gridEntityId]="column" [attr.data-testid]="column" />
      }
      @for (node of items(); track node.id) {
        <hw-test-row [gridEntityId]="node.id" [attr.data-testid]="node.id">
          @for (column of columns; track column) {
            @if (!hiddenCells().includes(node.id + ':' + column)) {
              <hw-test-cell
                [gridEntityId]="node.id + ':' + column"
                [attr.data-testid]="node.id + ':' + column"
              >
                <button>{{ node.data }} {{ column }}</button>
              </hw-test-cell>
            }
          }
        </hw-test-row>
      }
    </div>
  `,
})
class TestGridComponent extends GridBaseComponent<string> {
  readonly items = input<TreeNode<string>[]>([
    { id: 'r1', data: 'one' },
    { id: 'r2', data: 'two' },
    { id: 'r3', data: 'three' },
  ]);
  readonly columns = ['c1', 'c2'];
  readonly hiddenCells = signal<string[]>([]);
  readonly grid = viewChild.required<ElementRef<HTMLElement>>('grid');

  readonly checked: TreeNode<string>[][] = [];
  readonly expanded: TreeNode<string>[][] = [];
  readonly scrolledTo: string[] = [];

  constructor() {
    super();
    this.subscribeToGridRowPointer();
  }

  initGrid(): void {
    this.gridService.init({
      rowIds: this.items().map((node) => node.id),
      columnIds: this.columns,
      getHost: () => this.grid().nativeElement,
      isRowingOnly: false,
      gridActionsConfig: {
        ...defaultGridActionsConfig,
        row: { primary: 'toggle-context-panel', secondary: 'check' },
      },
      customGridActions: [{ name: 'delete', key: 'Delete' }],
    });
  }

  scrollIntoCenterIfNeededById(nodeId: string): void {
    this.scrolledTo.push(nodeId);
  }

  protected checkNodes(nodes: TreeNode<string>[]): void {
    this.checked.push(nodes);
  }

  protected expandNodes(nodes: TreeNode<string>[]): void {
    this.expanded.push(nodes);
  }
}

describe('Grid entities', () => {
  let fixture: ComponentFixture<TestGridComponent>;
  let component: TestGridComponent;
  let service: GridService;
  let grid: HTMLElement;

  function byTestId(testId: string): HTMLElement {
    return fixture.nativeElement.querySelector(`[data-testid="${testId}"]`);
  }

  function press(code: string, init: KeyboardEventInit = {}, target: EventTarget = grid): void {
    const options = { code, bubbles: true, cancelable: true, ...init };
    target.dispatchEvent(new KeyboardEvent('keydown', options));
    target.dispatchEvent(new KeyboardEvent('keyup', options));
  }

  function click(element: HTMLElement, init: MouseEventInit = {}): void {
    element.dispatchEvent(new MouseEvent('click', { bubbles: true, ...init }));
  }

  beforeEach(async () => {
    TestBed.configureTestingModule({
      providers: [
        { provide: GRID_KEYBOARD_ENABLED_TOKEN, useValue: true },
        { provide: InteractivityChecker, useValue: checkerStub },
      ],
    });
    fixture = TestBed.createComponent(TestGridComponent);
    component = fixture.componentInstance;
    document.body.appendChild(fixture.nativeElement);
    await fixture.whenStable();
    component.initGrid();
    service = fixture.debugElement.injector.get(GridService);
    grid = component.grid().nativeElement;
    grid.focus();
    await fixture.whenStable();
  });

  afterEach(() => {
    fixture.destroy();
    document.body.innerHTML = '';
  });

  describe('pointer', () => {
    it('highlights the entity under the pointer', async () => {
      press('ArrowDown');
      await fixture.whenStable();

      expect(byTestId('r1').classList).toContain('pointed');
      expect(byTestId('r1').getAttribute('gridid')).toBe('r1');
      expect(byTestId('c1').classList).not.toContain('pointed');
      expect(component.scrolledTo.at(-1)).toBe('r1');
    });

    it('a click moves the pointer, Shift+click selects a range', async () => {
      const removeAllRanges = vi.spyOn(document.getSelection() as Selection, 'removeAllRanges');

      click(byTestId('r1'));
      expect(removeAllRanges).not.toHaveBeenCalled();
      click(byTestId('r3'), { shiftKey: true });
      await fixture.whenStable();

      expect(service.pointer()?.selectedTargetIds).toEqual(['r1', 'r2', 'r3']);
      expect(byTestId('r2').classList).toContain('range-pointed');
      expect(removeAllRanges).toHaveBeenCalledTimes(1);
    });
  });

  describe('row actions', () => {
    it('Space checks the selected range, resolving nodes by id', () => {
      press('ArrowDown');
      press('ArrowDown', { shiftKey: true });
      press('Space');

      expect(component.checked).toEqual([
        [
          { id: 'r1', data: 'one' },
          { id: 'r2', data: 'two' },
        ],
      ]);
    });

    it('Enter toggles the context panel for the pointed row', () => {
      const toggled: TreeNode<string>[] = [];
      component.contextPanelToggled.subscribe((node) => toggled.push(node));

      press('ArrowDown');
      press('ArrowDown');
      press('Enter');

      expect(toggled).toEqual([{ id: 'r2', data: 'two' }]);
    });

    it('a custom action is re-emitted as an output', () => {
      const actions: string[] = [];
      component.customGridAction.subscribe((action) => actions.push(action));

      press('ArrowDown');
      press('Delete');

      expect(actions).toEqual(['delete']);
    });
  });

  describe('entering a cell (focus trap)', () => {
    async function enterCell(cellId: string): Promise<HTMLElement> {
      press('AltLeft', { altKey: true });
      press('ArrowDown');
      if (cellId.endsWith('c2')) {
        press('ArrowRight');
      }
      press('Enter');
      await fixture.whenStable();
      return byTestId(cellId);
    }

    it('Enter focuses the cell content and traps focus', async () => {
      const cell = await enterCell('r1:c1');

      expect(document.activeElement).toBe(cell.querySelector('button'));
      expect(cell.classList).toContain('focus-trapped');
      expect(service.isFocusTrapActive()).toBe(true);
    });

    it('Escape returns focus to the grid', async () => {
      const cell = await enterCell('r1:c1');

      press('Escape', {}, cell.querySelector('button') as HTMLElement);
      await fixture.whenStable();

      expect(document.activeElement).toBe(grid);
      expect(cell.classList).not.toContain('focus-trapped');
      expect(service.isFocusTrapActive()).toBe(false);
      expect(service.pointer()?.targetId).toBe('r1:c1');
    });

    it('focus leaving the grid releases the trap without pulling focus back', async () => {
      const outside = document.createElement('button');
      document.body.appendChild(outside);
      const cell = await enterCell('r1:c1');

      outside.focus();
      await fixture.whenStable();

      expect(document.activeElement).toBe(outside);
      expect(cell.classList).not.toContain('focus-trapped');
      expect(service.isFocusTrapActive()).toBe(false);
    });

    it('destroying the trapped cell clears the service flag', async () => {
      await enterCell('r1:c2');

      component.hiddenCells.set(['r1:c2']);
      await fixture.whenStable();

      expect(service.isFocusTrapActive()).toBe(false);
    });

    it('a repeated action on a trapped cell does not create a second trap', async () => {
      const cell = await enterCell('r1:c1');
      const anchors = cell.parentElement?.querySelectorAll('.cdk-focus-trap-anchor').length;

      service.releaseFocusTrap();
      grid.focus();
      press('Enter');
      press('Enter');
      await fixture.whenStable();

      expect(cell.parentElement?.querySelectorAll('.cdk-focus-trap-anchor').length).toBe(anchors);
    });
  });
});
