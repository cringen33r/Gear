import { fromEvent } from 'rxjs';
import { filter } from 'rxjs/operators';
import { FocusTrap, FocusTrapFactory, InteractivityChecker } from '@angular/cdk/a11y';
import {
  computed,
  DestroyRef,
  Directive,
  effect,
  ElementRef,
  inject,
  input,
  OnInit,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { injectDebugFor } from '../../mocks/debug';
import { getFocusableChild } from '../focus-utils';

import { GridService } from './grid.service';
import { CellPrimaryAction, GridAction, GridEntity } from './grid.types';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { getRowColumnIds, getUnitedColumnsIfNeeded } from './grid-utils';

/**
 * Базовый класс сущности таблицы: заголовка колонки, строки или ячейки.
 *
 * Наследник задаёт {@link entity} и получает:
 * - классы `pointed` / `range-pointed` по указателю {@link GridService} и атрибут `gridid`;
 * - перевод указателя на себя по клику (Shift+клик по строке расширяет выделение);
 * - выполнение действий из {@link GridService.gridAction$} по конфигу таблицы. Сейчас поддерживается
 *   `'focus-first'` — вход в содержимое ячейки: фокус на первый интерактивный элемент и focus trap (класс
 *   `focus-trapped`). Выход — Escape или уход указателя с сущности.
 *
 * Идентификатор сущности задаётся входом `gridEntityId`: id строки, id колонки или `'<rowId>:<columnId>'` для ячейки.
 */
@Directive({
  host: {
    '[class.pointed]': 'isPointed()',
    '[class.range-pointed]': 'isRangePointed()',
    '[class.focus-trapped]': 'isFocusTrapped()',
    '[attr.gridid]': 'gridEntityId()',
  },
})
export abstract class GridEntityComponent<E extends GridEntity> implements OnInit {
  /** Колонки из {@link GridConfig.columnsToUnite} приводятся к первой из них. */
  readonly gridEntityId = input<string | undefined, string | undefined>(undefined, {
    transform: (id: string | undefined) =>
      getUnitedColumnsIfNeeded(this.gridService.config?.columnsToUnite ?? [], id),
  });

  protected abstract entity: E;

  protected readonly destroyRef = inject(DestroyRef);
  protected readonly gridService = inject(GridService);
  protected readonly debug = injectDebugFor('GRID');
  protected readonly host: HTMLElement = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  protected readonly featureToken = inject(GRID_KEYBOARD_ENABLED_TOKEN);
  private readonly focusTrapFactory = inject(FocusTrapFactory);
  private readonly checker = inject(InteractivityChecker);

  private focusTrap: FocusTrap | undefined;
  private isDestroyed = false;
  protected readonly isFocusTrapped = signal(false);

  /** Реализации действий сущности. Наследник может переопределить или отключить (`undefined`). */
  protected gridActions: Partial<Record<CellPrimaryAction, () => void>> | undefined = {
    'focus-first': () => this.focusFirst(),
  };
  /** Подписываться ли на действия таблицы. */
  protected withActions = true;

  /** Сущность (или её строка) входит в выделенный диапазон. */
  protected readonly isRangePointed = computed(() =>
    this.matchesPointer(this.gridService.pointer()?.selectedTargetIds ?? []),
  );

  /** На сущность (или её строку) указывает указатель. */
  protected readonly isPointed = computed(() => {
    const targetId = this.gridService.pointer()?.targetId;
    return targetId !== undefined && this.matchesPointer([targetId]);
  });

  constructor() {
    // Указатель ушёл с ячейки или заголовка — выходим из её содержимого
    effect(() => {
      if (this.entity !== 'row' && !this.isPointed()) {
        this.destroyFocusTrap();
      }
    });
    this.destroyRef.onDestroy(() => {
      this.isDestroyed = true;
      this.destroyFocusTrap();
    });
  }

  ngOnInit(): void {
    if (!this.featureToken || !this.gridEntityId()) {
      return;
    }
    if (this.withActions) {
      this.subscribeToGridActions();
    }
    this.subscribeToMouseActions();
    this.subscribeToFocusTrapRelease();
  }

  private matchesPointer(ids: readonly string[]): boolean {
    const id = this.gridEntityId();
    if (!id) {
      return false;
    }
    const [rowId] = getRowColumnIds(id);
    return ids.includes(id) || ids.includes(rowId);
  }

  private focusFirst(): void {
    if (this.focusTrap) {
      return;
    }
    if (getFocusableChild(this.host, 'start', this.checker)) {
      this.debug.log('FOCUS', this.gridEntityId(), 'Activated first focusable');
      this.setupFocusTrap();
    } else {
      this.debug.warn('FOCUS', this.gridEntityId(), 'No focusable');
    }
  }

  private setupFocusTrap(): void {
    this.debug.log('FOCUS_TRAP', this.gridEntityId(), 'Handling focus trap');
    const focusTrap = this.focusTrapFactory.create(this.host);
    this.focusTrap = focusTrap;
    focusTrap.focusFirstTabbableElementWhenReady().then((isFocused) => {
      // За время ожидания trap мог быть снят или компонент уничтожен
      if (this.focusTrap !== focusTrap) {
        return;
      }
      if (isFocused && !this.isDestroyed) {
        focusTrap.enabled = true;
        this.isFocusTrapped.set(true);
        this.gridService.isFocusTrapActive.set(true);
      } else {
        this.destroyFocusTrap();
      }
    });
  }

  /**
   * Снимает focus trap. Фокус возвращается на таблицу, только если он был внутри сущности:
   * при уходе фокуса из таблицы (клик снаружи) таблица не должна забирать его обратно.
   */
  private destroyFocusTrap(): void {
    const focusTrap = this.focusTrap;
    if (!focusTrap) {
      return;
    }
    this.debug.log('FOCUS_TRAP', this.gridEntityId(), 'DestroyFocusTrap');
    const hadFocus = this.host.contains(this.host.ownerDocument.activeElement);
    focusTrap.destroy();
    this.focusTrap = undefined;
    this.isFocusTrapped.set(false);
    this.gridService.isFocusTrapActive.set(false);
    if (hadFocus && !this.isDestroyed) {
      this.gridService.focusTable();
    }
  }

  /** Escape внутри ячейки возвращает фокус в таблицу (см. {@link GridService.releaseFocusTrap}). */
  private subscribeToFocusTrapRelease(): void {
    this.gridService.focusTrapRelease$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.destroyFocusTrap());
  }

  private subscribeToMouseActions(): void {
    fromEvent<MouseEvent>(this.host, 'click')
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((event) => {
        const id = this.gridEntityId();
        if (!id) {
          return;
        }
        this.gridService.changePointerTo(this.entity, id, event.shiftKey);
        // Shift+клик выделяет диапазон строк — браузерное выделение текста при этом только мешает
        if (event.shiftKey) {
          this.host.ownerDocument.getSelection()?.removeAllRanges();
        }
      });
  }

  private subscribeToGridActions(): void {
    this.gridService.gridAction$
      .pipe(
        filter((action) => action.currentPointer.targetId === this.gridEntityId()),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((action) => this.performAction(action));
  }

  private performAction(action: GridAction): void {
    const entityAction = this.gridService.getActionFor(this.entity, action.action);
    const perform = entityAction && this.gridActions?.[entityAction as CellPrimaryAction];
    this.debug.log(
      'ACTION',
      this.entity,
      `Received '${action.action}' (${entityAction ?? 'no action'}) for ${this.gridEntityId()}`,
    );
    perform?.();
  }
}
