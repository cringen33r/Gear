import { GridActionsConfig, GridSettings } from './grid.types';

/** Действия по умолчанию: Enter на ячейке или заголовке переводит фокус в его содержимое. */
export const defaultGridActionsConfig: GridActionsConfig = {
  header: { primary: 'focus-first' },
  cell: { primary: 'focus-first' },
  row: {},
};

/** Типовые настройки таблиц продукта. */
export const defaultGridSettings: GridSettings = {
  gridActionsConfig: defaultGridActionsConfig,
  isRowingOnly: false,
  withWrap: false,
  customGridActions: [{ name: 'delete', key: 'Delete' }],
  columnsToUnite: ['checkbox', 'numberInLayer', 'priority'],
};
