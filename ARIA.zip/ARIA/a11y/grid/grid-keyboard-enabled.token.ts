import { InjectionToken } from '@angular/core';

/**
 * Включает клавиатурную навигацию по таблицам ({@link GridService}, {@link GridEntityComponent},
 * {@link GridBaseComponent}). По умолчанию выключено: всё работает как раньше, без перехвата клавиш.
 */
export const GRID_KEYBOARD_ENABLED_TOKEN = new InjectionToken<boolean>(
  'Токен, активирующий функционал управления таблицами с клавиатуры',
  {
    factory: (): boolean => false,
  },
);
