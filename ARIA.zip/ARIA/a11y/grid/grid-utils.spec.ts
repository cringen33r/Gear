import { getCellId, getRowColumnIds, getUnitedColumnsIfNeeded } from './grid-utils';

describe('grid-utils', () => {
  it('getCellId joins row and column', () => {
    expect(getCellId('r1', 'c1')).toBe('r1:c1');
    expect(getCellId(1, 2)).toBe('1:2');
  });

  it('getRowColumnIds splits a cell id', () => {
    expect(getRowColumnIds('r1:c1')).toEqual(['r1', 'c1']);
    expect(getRowColumnIds('r1')).toEqual(['r1']);
    expect(getRowColumnIds(undefined)).toEqual([]);
  });

  describe('getUnitedColumnsIfNeeded', () => {
    const united = ['checkbox', 'number'];

    it('maps a united column to the first one', () => {
      expect(getUnitedColumnsIfNeeded(united, 'number')).toBe('checkbox');
      expect(getUnitedColumnsIfNeeded(united, 'r1:number')).toBe('r1:checkbox');
    });

    it('leaves other ids untouched', () => {
      expect(getUnitedColumnsIfNeeded(united, 'name')).toBe('name');
      expect(getUnitedColumnsIfNeeded(united, 'r1:name')).toBe('r1:name');
      expect(getUnitedColumnsIfNeeded([], 'r1:number')).toBe('r1:number');
      expect(getUnitedColumnsIfNeeded(united, undefined)).toBeUndefined();
    });
  });
});
