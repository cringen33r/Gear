/** Разделитель id строки и колонки в id ячейки. Сами id строк и колонок не должны его содержать. */
const CELL_ID_SEPARATOR = ':';

/** Id ячейки: `'<rowId>:<columnId>'`. */
export function getCellId(rowId: string, columnId: string): string;
export function getCellId(rowId: number, columnId: number): string;
export function getCellId(rowId: number | string, columnId: number | string): string {
  return `${rowId}${CELL_ID_SEPARATOR}${columnId}`;
}

/** Разбирает id ячейки на `[rowId, columnId]`; id строки или колонки вернётся как `[id]`. */
export function getRowColumnIds(cellId: string | undefined): string[] {
  return cellId?.split(CELL_ID_SEPARATOR) ?? [];
}

/**
 * Приводит колонку из `columnsToUnite` (или ячейку в ней) к первой колонке группы:
 * объединённые колонки навигация проходит как одну.
 */
export function getUnitedColumnsIfNeeded(
  columnsToUnite: readonly string[],
  id: string | undefined,
): string | undefined {
  const [first, second] = getRowColumnIds(id);
  const isCellId = second !== undefined;
  const columnId = isCellId ? second : first;
  if (!columnId || !columnsToUnite.includes(columnId)) {
    return id;
  }
  return isCellId ? getCellId(first, columnsToUnite[0]) : columnsToUnite[0];
}
