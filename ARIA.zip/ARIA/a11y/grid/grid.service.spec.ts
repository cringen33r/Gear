import { InteractivityChecker } from '@angular/cdk/a11y';
import { TestBed } from '@angular/core/testing';

import { defaultGridActionsConfig } from './grid-keyboard-defaults.config';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { GridService } from './grid.service';
import { GridAction, GridConfig } from './grid.types';

/** jsdom has no layout: tabbability is decided by tabIndex. */
const checkerStub: Partial<InteractivityChecker> = {
  isFocusable: (element) => element.tabIndex >= 0,
  isTabbable: (element) => element.tabIndex >= 0,
};

function dispatch(
  target: EventTarget,
  type: string,
  code: string,
  init: KeyboardEventInit = {},
): KeyboardEvent {
  const event = new KeyboardEvent(type, { code, bubbles: true, cancelable: true, ...init });
  target.dispatchEvent(event);
  return event;
}

/** Full key press; returns the keydown, where native actions are prevented. */
function press(target: EventTarget, code: string, init: KeyboardEventInit = {}): KeyboardEvent {
  const down = dispatch(target, 'keydown', code, init);
  dispatch(target, 'keyup', code, init);
  return down;
}

describe('GridService', () => {
  let service: GridService;
  let host: HTMLElement;
  let actions: GridAction[];
  let customActions: string[];

  function setup(config: Partial<GridConfig> = {}, isEnabled = true): void {
    TestBed.configureTestingModule({
      providers: [
        GridService,
        { provide: GRID_KEYBOARD_ENABLED_TOKEN, useValue: isEnabled },
        { provide: InteractivityChecker, useValue: checkerStub },
      ],
    });
    service = TestBed.inject(GridService);
    actions = [];
    customActions = [];
    service.gridAction$.subscribe((action) => actions.push(action));
    service.customAction$.subscribe((name) => customActions.push(name));
    service.init({
      rowIds: ['r1', 'r2', 'r3'],
      columnIds: ['c1', 'c2'],
      getHost: () => host,
      isRowingOnly: false,
      gridActionsConfig: defaultGridActionsConfig,
      customGridActions: [{ name: 'delete', key: 'Delete' }],
      ...config,
    });
  }

  function pointedId(): string | undefined {
    return service.pointer()?.targetId;
  }

  beforeEach(() => {
    host = document.createElement('div');
    host.tabIndex = 0;
    document.body.appendChild(host);
  });

  afterEach(() => {
    TestBed.resetTestingModule();
    document.body.innerHTML = '';
  });

  describe('navigation', () => {
    beforeEach(() => {
      setup();
      host.focus();
    });

    it('focusing the grid points at the first header, blurring resets the pointer', () => {
      expect(pointedId()).toBe('c1');

      host.blur();

      expect(service.pointer()).toBeNull();
    });

    it('arrows move the pointer and Shift selects a range of rows', () => {
      expect(press(host, 'ArrowDown').defaultPrevented).toBe(true);
      press(host, 'ArrowDown', { shiftKey: true });

      expect(pointedId()).toBe('r2');
      expect(service.pointer()?.selectedTargetIds).toEqual(['r1', 'r2']);
    });

    it('End acts on keyup and prevents scrolling on keydown', () => {
      press(host, 'ArrowDown');
      const down = dispatch(host, 'keydown', 'End');
      expect(down.defaultPrevented).toBe(true);
      expect(pointedId()).toBe('r1');

      dispatch(host, 'keyup', 'End');
      expect(pointedId()).toBe('r3');
    });

    it('Ctrl+A selects all rows right after init, on any layout', () => {
      press(host, 'ArrowDown');

      expect(press(host, 'KeyA', { key: 'ф', ctrlKey: true }).defaultPrevented).toBe(true);
      expect(service.pointer()?.selectedTargetIds).toEqual(['r1', 'r2', 'r3']);
    });

    it('a lone Alt toggles the mode, Alt+Shift (layout switch) does not', () => {
      dispatch(host, 'keydown', 'AltLeft', { altKey: true });
      dispatch(host, 'keydown', 'ShiftLeft', { altKey: true, shiftKey: true });
      dispatch(host, 'keyup', 'ShiftLeft', { altKey: true });
      dispatch(host, 'keyup', 'AltLeft');
      expect(service.mode()).toBe('rowing');

      press(host, 'AltLeft', { altKey: true });
      expect(service.mode()).toBe('cellular');
    });
  });

  describe('actions', () => {
    beforeEach(() => {
      setup();
      host.focus();
      press(host, 'ArrowDown');
    });

    it('Enter and Space emit primary and secondary actions for the pointer', () => {
      press(host, 'Enter');
      press(host, 'Space');

      expect(actions.map((action) => action.action)).toEqual(['primary', 'secondary']);
      expect(actions[0].currentPointer.targetId).toBe('r1');
    });

    it('a keyup without a keydown in the grid is ignored', () => {
      dispatch(host, 'keyup', 'Enter');

      expect(actions).toEqual([]);
    });

    it('custom actions fire only with the declared modifiers', () => {
      press(host, 'Delete', { ctrlKey: true });
      press(host, 'Delete');

      expect(customActions).toEqual(['delete']);
    });
  });

  describe('with a focus trap in a cell', () => {
    let button: HTMLButtonElement;

    beforeEach(() => {
      setup();
      button = document.createElement('button');
      host.appendChild(button);
      host.focus();
      press(host, 'ArrowDown');
      service.isFocusTrapActive.set(true);
      button.focus();
    });

    it('Enter, Space and Tab belong to the cell content', () => {
      expect(press(button, 'Enter').defaultPrevented).toBe(false);
      expect(press(button, 'Space').defaultPrevented).toBe(false);
      expect(press(button, 'Tab').defaultPrevented).toBe(false);
      expect(actions).toEqual([]);
    });

    it('Escape requests leaving the cell and does not reach outer handlers', () => {
      const released = vi.fn();
      const outer = vi.fn();
      service.focusTrapRelease$.subscribe(released);
      document.body.addEventListener('keydown', outer);

      press(button, 'Escape');

      expect(released).toHaveBeenCalledTimes(1);
      expect(outer).not.toHaveBeenCalled();
      document.body.removeEventListener('keydown', outer);
    });

    it('arrows keep navigating and leave the cell', () => {
      press(button, 'ArrowDown');

      expect(pointedId()).toBe('r2');
    });
  });

  describe('Tab', () => {
    it('moves focus past the grid in both directions', () => {
      const before = document.createElement('button');
      const after = document.createElement('button');
      document.body.prepend(before);
      document.body.appendChild(after);
      setup();
      host.focus();

      expect(press(host, 'Tab').defaultPrevented).toBe(true);
      expect(document.activeElement).toBe(after);
      host.focus();
      press(host, 'Tab', { shiftKey: true });
      expect(document.activeElement).toBe(before);
    });

    it('stays native when nothing focusable follows the grid', () => {
      setup();
      host.focus();

      expect(press(host, 'Tab').defaultPrevented).toBe(false);
    });
  });

  describe('init and lifecycle', () => {
    it('nothing happens before init or when disabled', () => {
      setup({}, false);
      host.focus();

      expect(service.getActionFor('cell', 'primary')).toBeUndefined();
      expect(press(host, 'ArrowDown').defaultPrevented).toBe(false);
      expect(service.pointer()).toBeNull();
    });

    it('clicks with unknown ids or in the wrong mode are ignored', () => {
      setup();
      host.focus();

      service.changePointerTo('row', 'unknown');
      service.changePointerTo('cell', 'r2:c2');
      expect(pointedId()).toBe('c1');

      press(host, 'AltLeft', { altKey: true });
      service.changePointerTo('cell', 'r2:c2');
      expect(pointedId()).toBe('r2:c2');
    });

    it('re-init keeps the pointer position within the new bounds', () => {
      setup();
      host.focus();
      press(host, 'ArrowDown');
      press(host, 'End');

      service.init({ rowIds: ['a', 'b'], columnIds: ['c1'], getHost: () => host });

      expect(pointedId()).toBe('b');
    });

    it('re-init moves listeners to the new host and replaces custom actions', () => {
      setup();
      const oldHost = host;
      host = document.createElement('div');
      host.tabIndex = 0;
      document.body.appendChild(host);
      service.init({
        rowIds: ['r1'],
        columnIds: ['c1'],
        getHost: () => host,
        customGridActions: [{ name: 'copy', key: 'KeyC', ctrlKey: true }],
      });
      host.focus();
      press(host, 'ArrowDown');

      expect(press(oldHost, 'ArrowUp').defaultPrevented).toBe(false);
      press(host, 'Delete');
      press(host, 'KeyC', { ctrlKey: true });
      expect(customActions).toEqual(['copy']);
    });

    it('listeners are removed when the injector is destroyed', () => {
      setup();
      host.focus();
      TestBed.resetTestingModule();

      expect(press(host, 'ArrowDown').defaultPrevented).toBe(false);
    });
  });
});
