import { Subject } from 'rxjs';
import { distinctUntilChanged, map, takeUntil } from 'rxjs/operators';
import { computed, DestroyRef, inject, Injectable, signal } from '@angular/core';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { FocusMonitor, InteractivityChecker } from '@angular/cdk/a11y';

import { injectDebugFor } from '../../mocks/debug';
import { getNextFocusable } from '../focus-utils';
import { KeyboardEventManager, Modifier } from '../keyboard-event-manager';

import {
  CustomGridActions,
  GridAction,
  GridBasicAction,
  GridConfig,
  GridEntity,
  GridEntityAction,
  GridPointerState,
  MappedPointerState,
} from './grid.types';
import { GridPointer } from './grid-pointer';
import { getCellId, getRowColumnIds } from './grid-utils';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';

/** Минимальный интервал между шагами навигации при удержании клавиши, мс. */
const KEY_REPEAT_THROTTLE_MS = 32;

/**
 * Клавиатурная навигация по таблице. Предоставляется на уровне компонента таблицы
 * ({@link GridBaseComponent}), который вызывает {@link init} при каждом изменении строк или колонок.
 *
 * Фокус на таблице ставит указатель на первый заголовок, уход фокуса — сбрасывает его. Сущности таблицы
 * ({@link GridEntityComponent}) подсвечиваются по {@link pointer} и выполняют действия из {@link gridAction$}.
 *
 * Клавиши (на хосте таблицы):
 * - стрелки, Home/End (+Shift — выделение строк) — навигация, работает и изнутри ячейки, уводя из неё;
 * - Enter / Space — основное / дополнительное действие, Ctrl+A — выделить все строки, Alt — режим строк/ячеек,
 *   пользовательские действия — только вне ячейки с focus trap: там клавиши принадлежат её содержимому;
 * - Enter, Space, Home, End, Alt — на keyup: если действие переносит фокус в ячейку, отпускание клавиши
 *   не должно сработать на получившем фокус элементе;
 * - Escape — выйти из ячейки; Tab — уйти из таблицы, минуя её внутренние элементы.
 */
@Injectable()
export class GridService {
  private readonly destroyRef = inject(DestroyRef);
  private readonly focusMonitor = inject(FocusMonitor);
  private readonly checker = inject(InteractivityChecker);
  private readonly featureToken = inject(GRID_KEYBOARD_ENABLED_TOKEN);
  private readonly debug = injectDebugFor('GRID');

  /** Текущая конфигурация; `undefined` до {@link init}. */
  config: GridConfig | undefined;
  private gridPointer = new GridPointer({
    rowCount: 0,
    columnCount: 0,
    isRowingOnly: true,
    withWrap: false,
  });
  private rowIds: readonly string[] = [];
  private columnIds: readonly string[] = [];
  private host: HTMLElement | null = null;
  private detachKeyboard: (() => void) | null = null;
  private customActionDisposers: (() => void)[] = [];
  private readonly hostChange$ = new Subject<void>();

  private readonly pointerState = signal<GridPointerState | null>(null);
  /** Указатель в идентификаторах; `null`, если таблица не в фокусе. */
  readonly pointer = computed(() => this.mapPointerState(this.pointerState()));
  readonly pointer$ = toObservable(this.pointer).pipe(takeUntilDestroyed(this.destroyRef));
  readonly mode = signal(this.gridPointer.mode);
  /** Фокус заперт внутри ячейки (режим взаимодействия с её содержимым). */
  readonly isFocusTrapActive = signal(false);

  private readonly gridActionSubject$ = new Subject<GridAction>();
  readonly gridAction$ = this.gridActionSubject$.asObservable();
  private readonly customActionSubject$ = new Subject<string>();
  /** Имена сработавших {@link GridConfig.customGridActions}. */
  readonly customAction$ = this.customActionSubject$.asObservable();
  private readonly focusTrapReleaseSubject$ = new Subject<void>();
  /** Запросы на выход из ячейки с focus trap (Escape). */
  readonly focusTrapRelease$ = this.focusTrapReleaseSubject$.asObservable();

  private readonly keyboard = this.createKeyboard();

  constructor() {
    this.destroyRef.onDestroy(() => this.setHost(null));
  }

  init(config: GridConfig): void {
    if (!this.featureToken) {
      return;
    }
    this.debug.log('SERVICE', 'INIT', 'INIT');
    const previousPosition = this.pointerState()?.position ?? null;
    this.config = config;
    this.rowIds = config.rowIds;
    this.columnIds = config.columnIds;
    this.gridPointer = new GridPointer({
      rowCount: config.rowIds.length,
      columnCount: config.columnIds.length,
      isRowingOnly: config.isRowingOnly ?? true,
      withWrap: config.withWrap ?? false,
    });
    // Обновление данных не сбрасывает указатель: та же позиция в границах новой таблицы
    this.pointerState.set(previousPosition ? this.gridPointer.setPosition(previousPosition) : null);
    this.mode.set(this.gridPointer.mode);
    this.isFocusTrapActive.set(false);
    this.setCustomActions(config.customGridActions ?? []);
    this.setHost(config.getHost());
  }

  getActionFor(entity: GridEntity, action: GridBasicAction): GridEntityAction | undefined {
    return this.config?.gridActionsConfig?.[entity]?.[action];
  }

  /** Переводит указатель на сущность (по клику). Неизвестные id игнорируются. */
  changePointerTo(entity: GridEntity, id: string, shiftKey = false): void {
    const [rowId, columnId] = getRowColumnIds(id);
    const rowIndex = this.rowIds.indexOf(rowId);
    const columnIndex = this.columnIds.indexOf(entity === 'header' ? rowId : columnId);
    const mode = this.gridPointer.mode;
    if (entity === 'header' && columnIndex !== -1) {
      this.pointerState.set(this.gridPointer.setPosition({ type: 'header', columnIndex }));
    } else if (entity === 'row' && mode === 'rowing' && rowIndex !== -1) {
      this.pointerState.set(this.gridPointer.setPosition({ type: 'row', rowIndex }, shiftKey));
    } else if (entity === 'cell' && mode === 'cellular' && rowIndex !== -1 && columnIndex !== -1) {
      this.pointerState.set(this.gridPointer.setPosition({ type: 'cell', rowIndex, columnIndex }));
    }
  }

  focusTable(): void {
    this.host?.focus();
  }

  releaseFocusTrap(): void {
    this.focusTrapReleaseSubject$.next();
  }

  /** Переносит слежение за фокусом и клавиатурой на новый хост (`null` — отключить). */
  private setHost(host: HTMLElement | null): void {
    this.hostChange$.next();
    this.detachKeyboard?.();
    this.detachKeyboard = null;
    if (this.host) {
      this.focusMonitor.stopMonitoring(this.host);
    }
    this.host = host;
    if (!host) {
      return;
    }
    this.detachKeyboard = this.keyboard.attach(host);
    this.focusMonitor
      .monitor(host, true)
      .pipe(
        map((origin) => origin !== null),
        distinctUntilChanged(),
        takeUntil(this.hostChange$),
      )
      .subscribe((isFocused) =>
        this.pointerState.set(
          isFocused ? this.gridPointer.resetToFirstHeader() : this.gridPointer.setPosition(null),
        ),
      );
  }

  private createKeyboard(): KeyboardEventManager {
    const hasPointer = (): boolean => !!this.pointer();
    const isInGridMode = (): boolean => hasPointer() && !this.isFocusTrapActive();
    const withShift = [Modifier.None, Modifier.Shift];
    const step = { repeat: true, throttle: KEY_REPEAT_THROTTLE_MS, when: hasPointer };
    return new KeyboardEventManager([
      {
        ...step,
        code: 'ArrowDown',
        modifiers: withShift,
        handler: (e) => this.move((p) => p.moveDown(e.shiftKey)),
      },
      {
        ...step,
        code: 'ArrowUp',
        modifiers: withShift,
        handler: (e) => this.move((p) => p.moveUp(e.shiftKey)),
      },
      { ...step, code: 'ArrowLeft', handler: () => this.move((p) => p.moveLeft()) },
      { ...step, code: 'ArrowRight', handler: () => this.move((p) => p.moveRight()) },
      {
        code: 'Home',
        modifiers: withShift,
        trigger: 'keyup',
        when: hasPointer,
        handler: (_, press) => this.move((p) => p.moveHome(press.shiftKey)),
      },
      {
        code: 'End',
        modifiers: withShift,
        trigger: 'keyup',
        when: hasPointer,
        handler: (_, press) => this.move((p) => p.moveEnd(press.shiftKey)),
      },
      {
        code: 'KeyA',
        modifiers: Modifier.Ctrl,
        when: isInGridMode,
        handler: () => this.selectAll(),
      },
      {
        code: 'AltLeft',
        trigger: 'keyup',
        solo: true,
        when: isInGridMode,
        handler: () => this.changeMode(),
      },
      {
        code: ['Enter', 'NumpadEnter'],
        trigger: 'keyup',
        when: isInGridMode,
        handler: () => this.emitAction('primary'),
      },
      {
        code: 'Space',
        trigger: 'keyup',
        when: isInGridMode,
        handler: () => this.emitAction('secondary'),
      },
      {
        code: 'Escape',
        when: () => this.isFocusTrapActive(),
        handler: (event) => {
          // Escape поглощается таблицей, чтобы не закрыть заодно окружающий диалог
          event.stopPropagation();
          this.releaseFocusTrap();
        },
      },
      {
        code: 'Tab',
        modifiers: withShift,
        repeat: true,
        when: () => !this.isFocusTrapActive(),
        // Если за таблицей фокусировать нечего, Tab выполняется нативно
        handler: (event) => this.focusOutOfGrid(event.shiftKey),
      },
    ]);
  }

  /** Пользовательские действия регистрируются после встроенных и не могут их перекрыть. */
  private setCustomActions(actions: CustomGridActions[]): void {
    this.customActionDisposers.forEach((dispose) => dispose());
    this.customActionDisposers = actions.map((action) =>
      this.keyboard.add({
        code: action.key,
        // Неуказанный модификатор — «не зажат»: Delete не срабатывает на Ctrl+Delete
        modifiers:
          (action.ctrlKey ? Modifier.Ctrl : 0) |
          (action.shiftKey ? Modifier.Shift : 0) |
          (action.altKey ? Modifier.Alt : 0) |
          (action.metaKey ? Modifier.Meta : 0),
        when: () => !!this.pointer() && !this.isFocusTrapActive(),
        handler: () => this.customActionSubject$.next(action.name),
      }),
    );
  }

  private move(step: (pointer: GridPointer) => GridPointerState): void {
    this.pointerState.set(step(this.gridPointer));
  }

  private changeMode(): void {
    this.move((pointer) => pointer.changeMode());
    this.mode.set(this.gridPointer.mode);
  }

  /** Выделение всех строк — только в построчном режиме, но Ctrl+A перехватывается в любом. */
  private selectAll(): void {
    if (this.gridPointer.mode === 'rowing') {
      this.move((pointer) => pointer.selectAll());
      this.host?.ownerDocument.getSelection()?.removeAllRanges();
    }
  }

  private emitAction(action: GridBasicAction): void {
    const pointer = this.pointer();
    if (pointer) {
      this.debug.log('ACTION', action, pointer.targetId);
      this.gridActionSubject$.next({ action, currentPointer: pointer });
    }
  }

  private focusOutOfGrid(isBackward: boolean): boolean {
    const next =
      this.host && getNextFocusable(this.host, isBackward ? 'backward' : 'forward', this.checker);
    next?.focus();
    return !!next;
  }

  private mapPointerState(state: GridPointerState | null): MappedPointerState | null {
    const position = state?.position;
    if (!state || !position) {
      return null;
    }
    const rowId = 'rowIndex' in position ? this.rowIds[position.rowIndex] : undefined;
    const columnId = 'columnIndex' in position ? this.columnIds[position.columnIndex] : undefined;
    const targetIds = {
      header: columnId,
      row: rowId,
      cell: rowId && columnId && getCellId(rowId, columnId),
    };
    return {
      targetId: targetIds[position.type],
      state,
      selectedTargetIds: state.selectedRowRange?.map((index) => this.rowIds[index]) ?? null,
    };
  }
}
