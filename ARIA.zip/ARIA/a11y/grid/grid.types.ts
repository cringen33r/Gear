/** Сущность таблицы: заголовок колонки, строка или ячейка. */
export type GridEntity = 'header' | 'row' | 'cell';

/** Базовое действие: основное (Enter) или дополнительное (Space). */
export type GridBasicAction = 'primary' | 'secondary';

/** Событие базового действия над сущностью под указателем. */
export interface GridAction {
  action: GridBasicAction;
  currentPointer: MappedPointerState;
}

export interface HeaderPointerPosition {
  type: 'header';
  columnIndex: number;
}

export interface RowPointerPosition {
  type: 'row';
  rowIndex: number;
}

export interface CellPointerPosition {
  type: 'cell';
  rowIndex: number;
  columnIndex: number;
}

/** Позиция указателя в индексах; `null` — таблица не в фокусе. */
export type GridPointerPosition =
  HeaderPointerPosition | RowPointerPosition | CellPointerPosition | null;

/** Режим навигации: по строкам (`'rowing'`) или по ячейкам (`'cellular'`). */
export type GridNavigationMode = 'rowing' | 'cellular';

export interface GridPointerConfig {
  rowCount: number;
  columnCount: number;
  /** Запрещено переключение в режим ячеек. */
  isRowingOnly: boolean;
  /** Закольцована ли навигация на краях таблицы. */
  withWrap: boolean;
}

/** Состояние {@link GridPointer} в индексах. */
export interface GridPointerState {
  position: GridPointerPosition;
  /** Индексы выделенных строк по возрастанию; `null` — выделения нет. */
  selectedRowRange: number[] | null;
}

/** Состояние указателя в идентификаторах — то, что видят сущности таблицы. */
export interface MappedPointerState {
  /** Id колонки (заголовок), строки или ячейки (`'<rowId>:<columnId>'`). */
  targetId: string | undefined;
  state: GridPointerState;
  /** Id выделенных строк; `null` — выделения нет. */
  selectedTargetIds: string[] | null;
}

/**
 * Пользовательское действие таблицы, логика которого реализована на стороне модуля.
 * Срабатывает на `keydown` в режиме навигации по таблице, имя действия приходит в `GridService.customAction$`.
 * Модификаторы сравниваются точно: неуказанный модификатор должен быть не зажат.
 */
export interface CustomGridActions {
  /** Имя действия, передаваемое подписчикам. */
  name: string;
  /** Физическая клавиша в терминах `KeyboardEvent.code` (`'Delete'`, `'KeyC'`). */
  key: string;
  ctrlKey?: boolean;
  altKey?: boolean;
  metaKey?: boolean;
  shiftKey?: boolean;
}

/** Конфиг таблицы для `GridService.init`, формируемый компонентом таблицы. */
export type GridConfig = {
  /** Id строк в порядке отображения. */
  rowIds: readonly string[];
  /** Id колонок в порядке отображения. */
  columnIds: readonly string[];
  /** Фокусируемый хост таблицы: на нём слушается клавиатура. */
  getHost: () => HTMLElement;
} & GridSettings;

/** Основное действие строки: переключить контекстную панель. */
export type RowPrimaryAction = 'toggle-context-panel';
/** Дополнительное действие строки: отметить или раскрыть (для выделенного диапазона — все строки). */
export type RowSecondaryAction = 'check' | 'expand';
export type RowAction = RowPrimaryAction | RowSecondaryAction;
/** Действие ячейки или заголовка: войти в содержимое (фокус на первый элемент + focus trap). */
export type CellPrimaryAction = 'focus-first';
export type GridEntityAction = RowAction | CellPrimaryAction;

/** Действия сущности; отсутствующее действие — клавиша ничего не делает. */
export interface GridEntityActions<Primary, Secondary = never> {
  primary?: Primary;
  secondary?: Secondary;
}

/** Действия сущностей таблицы по Enter (`primary`) и Space (`secondary`). */
export interface GridActionsConfig {
  header: GridEntityActions<CellPrimaryAction>;
  cell: GridEntityActions<CellPrimaryAction>;
  row: GridEntityActions<RowPrimaryAction, RowSecondaryAction>;
}

/** Настройки клавиатурной навигации таблицы. */
export interface GridSettings {
  /** Действия сущностей. Не указанные сущности действий не имеют. */
  gridActionsConfig?: Partial<GridActionsConfig>;
  /** Навигация только по строкам, без режима ячеек. По умолчанию `true`. */
  isRowingOnly?: boolean;
  /** Закольцована ли навигация на краях таблицы. По умолчанию `false`. */
  withWrap?: boolean;
  /** Пользовательские действия, логика которых реализована на стороне модуля. */
  customGridActions?: CustomGridActions[];
  /** Id колонок, которые обрабатываются как одна (приводятся к первой). */
  columnsToUnite?: string[];
}
