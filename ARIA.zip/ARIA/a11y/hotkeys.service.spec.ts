import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';

import {
  FOCUS_REALM_ENABLED_TOKEN,
  FocusRealmId,
  FocusRealmRouterService,
  FocusRoutingRequestEvent,
} from './focus-realm';
import { HotkeysService } from './hotkeys.service';
import { Modifier } from './keyboard-event-manager';

function press(code: string, init: KeyboardEventInit = {}): KeyboardEvent {
  const down = new KeyboardEvent('keydown', { code, bubbles: true, cancelable: true, ...init });
  document.body.dispatchEvent(down);
  document.body.dispatchEvent(new KeyboardEvent('keyup', { code, bubbles: true, ...init }));
  return down;
}

describe('HotkeysService', () => {
  let service: HotkeysService;
  let requests: FocusRoutingRequestEvent[];
  const currentRealm = signal<FocusRealmId | undefined>(undefined);

  function setup(isFocusRealmEnabled = true): void {
    requests = [];
    currentRealm.set(undefined);
    TestBed.configureTestingModule({
      providers: [
        { provide: FOCUS_REALM_ENABLED_TOKEN, useValue: isFocusRealmEnabled },
        {
          provide: FocusRealmRouterService,
          useValue: {
            currentRealm,
            requestRouting: (r: FocusRoutingRequestEvent) => requests.push(r),
          },
        },
      ],
    });
    service = TestBed.inject(HotkeysService);
  }

  afterEach(() => TestBed.resetTestingModule());

  it('Ctrl+Tab / Ctrl+Shift+Tab jump from the current realm', () => {
    setup();
    service.init();
    currentRealm.set('content');

    const forward = press('Tab', { ctrlKey: true });
    press('Tab', { ctrlKey: true, shiftKey: true });

    expect(requests).toEqual([
      { hostRealmId: 'content', direction: 'forward' },
      { hostRealmId: 'content', direction: 'backward' },
    ]);
    expect(forward.defaultPrevented).toBe(true);
  });

  it('plain Tab is not intercepted', () => {
    setup();
    service.init();

    expect(press('Tab').defaultPrevented).toBe(false);
    expect(requests).toEqual([]);
  });

  it('realm hotkeys are not registered when focus realms are disabled', () => {
    setup(false);
    service.init();

    expect(press('Tab', { ctrlKey: true }).defaultPrevented).toBe(false);
    expect(requests).toEqual([]);
  });

  it('a repeated init does not duplicate handling', () => {
    setup();
    service.init();
    service.init();

    press('Tab', { ctrlKey: true });

    expect(requests).toHaveLength(1);
  });

  it('a hotkey registered before init works after it and can be unregistered', () => {
    setup(false);
    const handler = vi.fn();
    const unregister = service.register({ code: 'KeyK', modifiers: Modifier.Ctrl, handler });

    press('KeyK', { ctrlKey: true });
    service.init();
    press('KeyK', { ctrlKey: true });
    unregister();
    press('KeyK', { ctrlKey: true });

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it('stops listening when the injector is destroyed', () => {
    setup(false);
    const handler = vi.fn();
    service.register({ code: 'F2', handler });
    service.init();
    TestBed.resetTestingModule();

    press('F2');

    expect(handler).not.toHaveBeenCalled();
  });
});
