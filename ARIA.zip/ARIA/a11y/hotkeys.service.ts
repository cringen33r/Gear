import { DestroyRef, DOCUMENT, inject, Injectable } from '@angular/core';

import { FOCUS_REALM_ENABLED_TOKEN, FocusDirection, FocusRealmRouterService } from './focus-realm';
import { KeyBinding, KeyboardEventManager, Modifier } from './keyboard-event-manager';

/**
 * Глобальные горячие клавиши приложения (слушаются на `document`). Регистрировать можно и до {@link init}.
 *
 * Встроенные (при включённом {@link FOCUS_REALM_ENABLED_TOKEN}): Ctrl+Tab / Ctrl+Shift+Tab — переход
 * к следующей / предыдущей области фокуса, не проходя оставшиеся элементы текущей.
 */
@Injectable({
  providedIn: 'root',
})
export class HotkeysService {
  private readonly document = inject(DOCUMENT);
  private readonly focusRouter = inject(FocusRealmRouterService);
  private readonly isFocusRealmEnabled = inject(FOCUS_REALM_ENABLED_TOKEN);
  private readonly keyboard = new KeyboardEventManager();
  private detachKeyboard: (() => void) | null = null;

  constructor() {
    inject(DestroyRef).onDestroy(() => this.detachKeyboard?.());
  }

  /** Начинает слушать клавиатуру; повторный вызов ничего не делает. */
  init(): void {
    if (this.detachKeyboard) {
      return;
    }
    this.detachKeyboard = this.keyboard.attach(this.document);
    if (this.isFocusRealmEnabled) {
      this.register({
        code: 'Tab',
        modifiers: Modifier.Ctrl,
        handler: () => this.jumpToRealm('forward'),
      });
      this.register({
        code: 'Tab',
        modifiers: Modifier.Ctrl | Modifier.Shift,
        handler: () => this.jumpToRealm('backward'),
      });
    }
  }

  /** Регистрирует горячую клавишу; возвращает функцию отмены. */
  register(binding: KeyBinding): () => void {
    return this.keyboard.add(binding);
  }

  private jumpToRealm(direction: FocusDirection): void {
    this.focusRouter.requestRouting({ hostRealmId: this.focusRouter.currentRealm(), direction });
  }
}
