import { getModifiers, KeyBinding, KeyboardEventManager, Modifier } from './keyboard-event-manager';

function key(type: 'keydown' | 'keyup', code: string, init: KeyboardEventInit = {}): KeyboardEvent {
  return new KeyboardEvent(type, { code, cancelable: true, bubbles: true, ...init });
}

describe('KeyboardEventManager', () => {
  let handler: ReturnType<typeof vi.fn<KeyBinding['handler']>>;

  beforeEach(() => {
    handler = vi.fn<KeyBinding['handler']>();
  });

  it('matches by event.code regardless of the keyboard layout', () => {
    const manager = new KeyboardEventManager([{ code: 'KeyA', modifiers: Modifier.Ctrl, handler }]);
    const event = key('keydown', 'KeyA', { key: 'ф', ctrlKey: true });

    expect(manager.handle(event)).toBe(true);
    expect(handler).toHaveBeenCalledWith(event, event);
    expect(event.defaultPrevented).toBe(true);
  });

  it('accepts a list of alternative codes', () => {
    const manager = new KeyboardEventManager([{ code: ['Enter', 'NumpadEnter'], handler }]);

    manager.handle(key('keydown', 'NumpadEnter'));
    manager.handle(key('keydown', 'Space'));

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it('leaves unmatched events untouched', () => {
    const manager = new KeyboardEventManager([{ code: 'Space', handler }]);
    const event = key('keydown', 'KeyA');

    expect(manager.handle(event)).toBe(false);
    expect(event.defaultPrevented).toBe(false);
  });

  describe('modifiers', () => {
    it('require no modifiers by default and match the mask exactly', () => {
      const manager = new KeyboardEventManager([
        { code: 'Delete', handler },
        { code: 'Tab', modifiers: Modifier.Ctrl | Modifier.Shift, handler },
      ]);

      manager.handle(key('keydown', 'Delete', { ctrlKey: true }));
      manager.handle(key('keydown', 'Tab', { ctrlKey: true }));
      expect(handler).not.toHaveBeenCalled();

      manager.handle(key('keydown', 'Delete'));
      manager.handle(key('keydown', 'Tab', { ctrlKey: true, shiftKey: true }));
      expect(handler).toHaveBeenCalledTimes(2);
    });

    it('accept a list of alternative masks', () => {
      const manager = new KeyboardEventManager([
        { code: 'ArrowDown', modifiers: [Modifier.None, Modifier.Shift], handler },
      ]);

      manager.handle(key('keydown', 'ArrowDown'));
      manager.handle(key('keydown', 'ArrowDown', { shiftKey: true }));
      manager.handle(key('keydown', 'ArrowDown', { altKey: true }));

      expect(handler).toHaveBeenCalledTimes(2);
    });

    it('ignore the modifier set by the modifier key itself', () => {
      expect(getModifiers(key('keydown', 'AltLeft', { altKey: true }))).toBe(Modifier.None);
      expect(getModifiers(key('keydown', 'ShiftRight', { shiftKey: true, ctrlKey: true }))).toBe(
        Modifier.Ctrl,
      );
    });
  });

  describe('handling result', () => {
    it('a handler returning false declines the event and lets the next binding try', () => {
      const fallback = vi.fn();
      const manager = new KeyboardEventManager([
        { code: 'Tab', handler: () => false },
        { code: 'Tab', handler: fallback },
      ]);

      manager.handle(key('keydown', 'Tab'));

      expect(fallback).toHaveBeenCalledTimes(1);
    });

    it('a declined event is not prevented', () => {
      const manager = new KeyboardEventManager([{ code: 'Tab', handler: () => false }]);
      const event = key('keydown', 'Tab');

      expect(manager.handle(event)).toBe(false);
      expect(event.defaultPrevented).toBe(false);
    });

    it('only the first matching binding runs', () => {
      const second = vi.fn();
      const manager = new KeyboardEventManager([
        { code: 'Enter', handler },
        { code: 'Enter', handler: second },
      ]);

      manager.handle(key('keydown', 'Enter'));

      expect(second).not.toHaveBeenCalled();
    });

    it('a binding is skipped while its condition is false', () => {
      let isEnabled = false;
      const manager = new KeyboardEventManager([{ code: 'Enter', when: () => isEnabled, handler }]);

      manager.handle(key('keydown', 'Enter'));
      isEnabled = true;
      manager.handle(key('keydown', 'Enter'));

      expect(handler).toHaveBeenCalledTimes(1);
    });
  });

  describe('auto-repeat', () => {
    it('is ignored by default', () => {
      const manager = new KeyboardEventManager([{ code: 'KeyA', handler }]);

      manager.handle(key('keydown', 'KeyA', { repeat: true }));

      expect(handler).not.toHaveBeenCalled();
    });

    it('is throttled when allowed, while every throttled event is still prevented', () => {
      const now = vi.spyOn(performance, 'now').mockReturnValue(0);
      const manager = new KeyboardEventManager([
        { code: 'ArrowDown', repeat: true, throttle: 32, handler },
      ]);

      manager.handle(key('keydown', 'ArrowDown'));
      now.mockReturnValue(10);
      const throttled = key('keydown', 'ArrowDown', { repeat: true });
      manager.handle(throttled);
      manager.handle(key('keydown', 'ArrowDown'));
      now.mockReturnValue(50);
      manager.handle(key('keydown', 'ArrowDown', { repeat: true }));

      // a fresh press is never throttled
      expect(handler).toHaveBeenCalledTimes(3);
      expect(throttled.defaultPrevented).toBe(true);
      now.mockRestore();
    });
  });

  describe("trigger: 'keyup'", () => {
    it('suppresses the native action on keydown and acts on keyup', () => {
      const manager = new KeyboardEventManager([{ code: 'Space', trigger: 'keyup', handler }]);
      const down = key('keydown', 'Space');
      const up = key('keyup', 'Space');

      manager.handle(down);
      expect(down.defaultPrevented).toBe(true);
      expect(handler).not.toHaveBeenCalled();

      manager.handle(up);
      expect(handler).toHaveBeenCalledWith(up, down);
    });

    it('ignores a keyup whose keydown it did not see', () => {
      const manager = new KeyboardEventManager([{ code: 'Enter', trigger: 'keyup', handler }]);

      expect(manager.handle(key('keyup', 'Enter'))).toBe(false);
      expect(handler).not.toHaveBeenCalled();
    });

    it('keeps suppressing auto-repeat while held and fires once', () => {
      const manager = new KeyboardEventManager([{ code: 'Space', trigger: 'keyup', handler }]);
      const repeat = key('keydown', 'Space', { repeat: true });

      manager.handle(key('keydown', 'Space'));
      manager.handle(repeat);
      manager.handle(key('keyup', 'Space'));
      manager.handle(key('keyup', 'Space'));

      expect(repeat.defaultPrevented).toBe(true);
      expect(handler).toHaveBeenCalledTimes(1);
    });

    it('solo: fires for a lone press but not after a chord (Alt+Shift)', () => {
      const manager = new KeyboardEventManager([
        { code: 'AltLeft', trigger: 'keyup', solo: true, handler },
      ]);

      manager.handle(key('keydown', 'AltLeft', { altKey: true }));
      manager.handle(key('keydown', 'AltLeft', { altKey: true, repeat: true }));
      manager.handle(key('keyup', 'AltLeft'));
      expect(handler).toHaveBeenCalledTimes(1);

      manager.handle(key('keydown', 'AltLeft', { altKey: true }));
      manager.handle(key('keydown', 'ShiftLeft', { altKey: true, shiftKey: true }));
      manager.handle(key('keyup', 'ShiftLeft', { altKey: true }));
      manager.handle(key('keyup', 'AltLeft'));
      expect(handler).toHaveBeenCalledTimes(1);
    });
  });

  describe('add and attach', () => {
    let host: HTMLElement;

    beforeEach(() => {
      host = document.createElement('div');
      document.body.appendChild(host);
    });

    afterEach(() => host.remove());

    it('add returns a remover', () => {
      const manager = new KeyboardEventManager();
      const remove = manager.add({ code: 'Delete', handler });

      remove();
      remove();
      manager.handle(key('keydown', 'Delete'));

      expect(handler).not.toHaveBeenCalled();
    });

    it('listens on the target until detached', () => {
      const manager = new KeyboardEventManager([{ code: 'Enter', trigger: 'keyup', handler }]);
      const detach = manager.attach(host);

      host.dispatchEvent(key('keydown', 'Enter'));
      host.dispatchEvent(key('keyup', 'Enter'));
      detach();
      host.dispatchEvent(key('keydown', 'Enter'));
      host.dispatchEvent(key('keyup', 'Enter'));

      expect(handler).toHaveBeenCalledTimes(1);
    });

    it('forgets pending presses when the window loses focus', () => {
      const manager = new KeyboardEventManager([{ code: 'Enter', trigger: 'keyup', handler }]);
      const detach = manager.attach(document);

      host.dispatchEvent(key('keydown', 'Enter'));
      window.dispatchEvent(new Event('blur'));
      host.dispatchEvent(key('keyup', 'Enter'));
      detach();

      expect(handler).not.toHaveBeenCalled();
    });
  });
});
