/** Битовые флаги модификаторов. Комбинации — через `|`: `Modifier.Ctrl | Modifier.Shift`. */
export const Modifier = { None: 0, Ctrl: 1, Shift: 2, Alt: 4, Meta: 8 } as const;

/** Модификатор, который выставляет сама клавиша: у keydown `AltLeft` уже `altKey === true`. */
const SELF_MODIFIERS: Record<string, number> = {
  ControlLeft: Modifier.Ctrl,
  ControlRight: Modifier.Ctrl,
  ShiftLeft: Modifier.Shift,
  ShiftRight: Modifier.Shift,
  AltLeft: Modifier.Alt,
  AltRight: Modifier.Alt,
  MetaLeft: Modifier.Meta,
  MetaRight: Modifier.Meta,
};

export interface KeyBinding {
  /** `KeyboardEvent.code` (не зависит от раскладки) или список альтернатив. */
  code: string | string[];
  /** Маска модификаторов или список допустимых масок. По умолчанию — без модификаторов. */
  modifiers?: number | number[];
  /**
   * `'keyup'` — действие на отпускание. Нативное действие клавиши подавляется уже на keydown,
   * а отпускание без «своего» нажатия игнорируется. По умолчанию `'keydown'`.
   */
  trigger?: 'keydown' | 'keyup';
  /** Условие доступности; проверяется на keydown. */
  when?: (event: KeyboardEvent) => boolean;
  /** Обрабатывать автоповтор при удержании. По умолчанию нет. */
  repeat?: boolean;
  /** Минимальный интервал между вызовами при автоповторе, мс. */
  throttle?: number;
  /** Только для `'keyup'`: не срабатывать, если пока клавиша была зажата, нажималось что-то ещё (Alt+Shift). */
  solo?: boolean;
  /**
   * Действие. `pressEvent` — keydown, с которого началось нажатие (для keyup-привязок модификаторы
   * смотреть по нему). Вернуть `false` — событие не обработано: браузер выполнит действие по умолчанию.
   */
  handler: (event: KeyboardEvent, pressEvent: KeyboardEvent) => boolean | void;
}

interface Entry {
  binding: KeyBinding;
  /** keydown, «взведший» keyup-привязку. */
  pressedBy: KeyboardEvent | null;
  lastCalledAt: number;
}

/**
 * Таблица привязок «клавиша + модификаторы → действие». На событие срабатывает первая подходящая привязка;
 * обработанное событие получает `preventDefault`.
 */
export class KeyboardEventManager {
  private readonly entries: Entry[] = [];

  constructor(bindings: KeyBinding[] = []) {
    bindings.forEach((binding) => this.add(binding));
  }

  /** Добавляет привязку; возвращает функцию удаления. */
  add(binding: KeyBinding): () => void {
    const entry: Entry = { binding, pressedBy: null, lastCalledAt: -Infinity };
    this.entries.push(entry);
    return () => {
      const index = this.entries.indexOf(entry);
      if (index !== -1) {
        this.entries.splice(index, 1);
      }
    };
  }

  /** Слушает клавиатуру на `target`; возвращает функцию отписки. */
  attach(target: HTMLElement | Document): () => void {
    const view = (target instanceof Document ? target : target.ownerDocument).defaultView;
    const onKey = (event: Event): void => {
      this.handle(event as KeyboardEvent);
    };
    const onBlur = (): void => this.entries.forEach((entry) => (entry.pressedBy = null));
    target.addEventListener('keydown', onKey);
    target.addEventListener('keyup', onKey);
    view?.addEventListener('blur', onBlur);
    return () => {
      target.removeEventListener('keydown', onKey);
      target.removeEventListener('keyup', onKey);
      view?.removeEventListener('blur', onBlur);
    };
  }

  /** @returns `true`, если событие обработано. */
  handle(event: KeyboardEvent): boolean {
    return event.type === 'keyup' ? this.handleKeyup(event) : this.handleKeydown(event);
  }

  private handleKeydown(event: KeyboardEvent): boolean {
    for (const entry of this.entries) {
      // Любая другая клавиша отменяет одиночное нажатие
      if (entry.binding.solo && entry.pressedBy?.code !== event.code) {
        entry.pressedBy = null;
      }
    }
    for (const entry of this.entries) {
      if (!matches(entry.binding, event)) {
        continue;
      }
      if (entry.binding.trigger === 'keyup') {
        entry.pressedBy ??= event;
        event.preventDefault();
        return true;
      }
      if (this.call(entry, event, event)) {
        return true;
      }
    }
    return false;
  }

  private handleKeyup(event: KeyboardEvent): boolean {
    for (const entry of this.entries) {
      const pressEvent = entry.pressedBy;
      if (pressEvent?.code === event.code) {
        entry.pressedBy = null;
        if (this.call(entry, event, pressEvent)) {
          return true;
        }
      }
    }
    return false;
  }

  private call(entry: Entry, event: KeyboardEvent, pressEvent: KeyboardEvent): boolean {
    const now = performance.now();
    const { throttle = 0 } = entry.binding;
    if (!event.repeat || now - entry.lastCalledAt >= throttle) {
      if (entry.binding.handler(event, pressEvent) === false) {
        return false;
      }
      entry.lastCalledAt = now;
    }
    event.preventDefault();
    return true;
  }
}

function matches(binding: KeyBinding, event: KeyboardEvent): boolean {
  const codes = typeof binding.code === 'string' ? [binding.code] : binding.code;
  const modifiers = binding.modifiers ?? Modifier.None;
  // Автоповтор keyup-привязки пропускаем, чтобы удержание продолжало подавлять нативное действие
  const allowsRepeat = binding.repeat || binding.trigger === 'keyup';
  return (
    codes.includes(event.code) &&
    (typeof modifiers === 'number' ? [modifiers] : modifiers).includes(getModifiers(event)) &&
    (!event.repeat || !!allowsRepeat) &&
    (binding.when?.(event) ?? true)
  );
}

/** Маска зажатых модификаторов без модификатора самой клавиши. */
export function getModifiers(event: KeyboardEvent): number {
  const mask =
    (event.ctrlKey ? Modifier.Ctrl : 0) |
    (event.shiftKey ? Modifier.Shift : 0) |
    (event.altKey ? Modifier.Alt : 0) |
    (event.metaKey ? Modifier.Meta : 0);
  return mask & ~(SELF_MODIFIERS[event.code] ?? 0);
}
