import { Component } from '@angular/core';

import { FocusRealmDirective } from '../a11y';

/** Демонстрационная страница, используемая для e2e-проверки маршрутизации фокуса между областями. */
@Component({
  selector: 'hw-focus-realm-demo',
  standalone: true,
  imports: [FocusRealmDirective],
  templateUrl: './focus-realm-demo.component.html',
})
export class FocusRealmDemoComponent {
  protected showContextPanel = true;
  protected showModulesMenu = true;

  protected toggleContextPanel(): void {
    this.showContextPanel = !this.showContextPanel;
  }

  protected toggleModulesMenu(): void {
    this.showModulesMenu = !this.showModulesMenu;
  }
}
