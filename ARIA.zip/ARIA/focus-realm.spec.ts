import { expect, Page, test } from '@playwright/test';

/**
 * E2E tests for focus routing between realms (`FocusRealm`).
 *
 * The demo page (`FocusRealmDemoComponent`) registers realms in this order:
 * tabs -> content -> contextPanel -> navPanel -> modulesMenu -> mainToolbar
 *
 * `contextPanel` and `modulesMenu` can be hidden with toggle buttons to check
 * that the router skips unavailable realms.
 */

/** Toggles a realm and waits for the re-render: Angular updates the DOM in the next frame. */
async function toggleRealm(page: Page, realm: 'context-panel' | 'modules-menu'): Promise<void> {
  const container = page.getByTestId(`realm-${realm}`);
  const wasVisible = (await container.count()) > 0;
  await page.getByTestId(`toggle-${realm}`).click();
  await expect(container).toHaveCount(wasVisible ? 0 : 1);
}

test.describe('Focus Realm: basic routing', () => {
  test('the first Tab from <body> focuses the first element of the first realm', async ({
    page,
  }) => {
    await page.goto('/');
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('tabs-btn-1')).toBeFocused();
  });

  test('Tab inside a realm moves focus natively, without a jump', async ({ page }) => {
    await page.goto('/');
    await page.getByTestId('tabs-btn-1').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('tabs-btn-2')).toBeFocused();
  });

  test('Tab from the last element of a realm focuses the first element of the next realm', async ({
    page,
  }) => {
    await page.goto('/');
    await page.getByTestId('tabs-btn-2').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('content-textarea')).toBeFocused();
  });

  test('Shift+Tab from the first element of a realm focuses the last element of the previous realm', async ({
    page,
  }) => {
    await page.goto('/');
    await page.getByTestId('content-textarea').focus();
    await page.keyboard.press('Shift+Tab');
    await expect(page.getByTestId('tabs-btn-2')).toBeFocused();
  });
});

test.describe('Focus Realm: full circle', () => {
  test('repeated Tab visits every realm forward and wraps to the start', async ({ page }) => {
    await page.goto('/');

    const forwardOrder = [
      'tabs-btn-1',
      'tabs-btn-2',
      'content-textarea',
      'context-panel-btn',
      'nav-btn-1',
      'nav-btn-2',
      'modules-btn',
      'toolbar-btn',
      'tabs-btn-1', // wrap
    ];

    await page.getByTestId(forwardOrder[0]).focus();
    for (const testId of forwardOrder.slice(1)) {
      await page.keyboard.press('Tab');
      await expect(page.getByTestId(testId)).toBeFocused();
    }
  });

  test('repeated Shift+Tab visits every realm backward and wraps to the end', async ({ page }) => {
    await page.goto('/');

    const backwardOrder = [
      'toolbar-btn',
      'modules-btn',
      'nav-btn-2',
      'nav-btn-1',
      'context-panel-btn',
      'content-textarea',
      'tabs-btn-2',
      'tabs-btn-1',
      'toolbar-btn', // wrap
    ];

    await page.getByTestId(backwardOrder[0]).focus();
    for (const testId of backwardOrder.slice(1)) {
      await page.keyboard.press('Shift+Tab');
      await expect(page.getByTestId(testId)).toBeFocused();
    }
  });

  test('Tab from the last realm wraps to the first', async ({ page }) => {
    await page.goto('/');
    await page.getByTestId('toolbar-btn').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('tabs-btn-1')).toBeFocused();
  });

  test('Shift+Tab from the first realm wraps to the last', async ({ page }) => {
    await page.goto('/');
    await page.getByTestId('tabs-btn-1').focus();
    await page.keyboard.press('Shift+Tab');
    await expect(page.getByTestId('toolbar-btn')).toBeFocused();
  });
});

test.describe('Focus Realm: unavailable realms', () => {
  test('forward: a hidden contextPanel is skipped, focus goes to navPanel', async ({ page }) => {
    await page.goto('/');
    await toggleRealm(page, 'context-panel');

    await page.getByTestId('content-textarea').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('nav-btn-1')).toBeFocused();
  });

  test('backward: a hidden contextPanel is skipped, focus goes to content', async ({ page }) => {
    await page.goto('/');
    await toggleRealm(page, 'context-panel');

    await page.getByTestId('nav-btn-1').focus();
    await page.keyboard.press('Shift+Tab');
    await expect(page.getByTestId('content-textarea')).toBeFocused();
  });

  test('two unavailable realms in a row are skipped (contextPanel and modulesMenu)', async ({
    page,
  }) => {
    await page.goto('/');
    await toggleRealm(page, 'context-panel');
    await toggleRealm(page, 'modules-menu');

    await page.getByTestId('content-textarea').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('nav-btn-1')).toBeFocused();

    await page.getByTestId('nav-btn-2').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('toolbar-btn')).toBeFocused();
  });

  test('a realm takes part in routing again once it is shown again', async ({ page }) => {
    await page.goto('/');
    await toggleRealm(page, 'context-panel'); // hide
    await toggleRealm(page, 'context-panel'); // show again

    await page.getByTestId('content-textarea').focus();
    await page.keyboard.press('Tab');
    await expect(page.getByTestId('context-panel-btn')).toBeFocused();
  });
});

test.describe('Focus Realm: realm jump hotkeys', () => {
  test('Ctrl+Tab jumps to the next realm, skipping the rest of the current one', async ({
    page,
  }) => {
    await page.goto('/');
    await page.getByTestId('nav-btn-1').focus();
    await page.keyboard.press('Control+Tab');
    await expect(page.getByTestId('modules-btn')).toBeFocused();
  });

  test('Ctrl+Shift+Tab jumps to the previous realm', async ({ page }) => {
    await page.goto('/');
    await page.getByTestId('nav-btn-2').focus();
    await page.keyboard.press('Control+Shift+Tab');
    await expect(page.getByTestId('context-panel-btn')).toBeFocused();
  });

  test('the jump starts from the realm focused with the mouse', async ({ page }) => {
    await page.goto('/');
    await page.getByTestId('tabs-btn-1').focus();
    await page.keyboard.press('Control+Tab');
    await expect(page.getByTestId('content-textarea')).toBeFocused();

    await page.getByTestId('nav-btn-2').click();
    await page.keyboard.press('Control+Tab');
    await expect(page.getByTestId('modules-btn')).toBeFocused();
  });
});
