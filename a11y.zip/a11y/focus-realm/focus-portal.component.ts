import { distinctUntilChanged, filter } from 'rxjs/operators';
import { FocusMonitor } from '@angular/cdk/a11y';
import { AfterViewInit, Component, DestroyRef, ElementRef, inject, input, signal, } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { FocusDirection, FocusPortal, FocusRealmId } from './focus-realm.types';
import { FocusRealmRouterService } from './focus-realm-router.service';
import { injectDebugFor } from '../../../../../debug';
import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';

/** Компонент для отлавливания события штатного ухода с области фокуса через `Tab`.
 * Необходим для сообщения маршрутизатору и необходимости прыжка на следующую область */
@Component({
    selector: 'webui-focus-portal',
    template: ``,
    host: {
        '[class]': '`${direction()} cdk-visually-hidden`',
        '[style.outline]': '"none"',
        '[attr.tabindex]': 'isArmed() ? 0 : -1',
    },
})
export class FocusPortalComponent implements AfterViewInit, FocusPortal {
    readonly hostRealmId = input.required<FocusRealmId>();
    readonly direction = input.required<FocusDirection>();

    private readonly focusMonitor = inject(FocusMonitor);
    private readonly elementRef = inject<ElementRef<HTMLElement>>(ElementRef);
    private readonly destroyRef = inject(DestroyRef);
    private readonly focusRealmRouter = inject(FocusRealmRouterService);
    private readonly debug = injectDebugFor('FOCUS_REALM');
    private readonly featureToken = inject(FOCUS_REALM_ENABLED_TOKEN);

    protected readonly isArmed = signal(false);

    get host(): HTMLElement {
        return this.elementRef.nativeElement;
    }

    ngAfterViewInit(): void {
        if (this.featureToken) {
            this.subscribeToFocused();
            this.debug.debug('PORTAL', this.hostRealmId(), `Setup ${this.direction()}-portal`);
        }
    }

    arm(): void {
        this.isArmed.set(true);
    }

    disarm(): void {
        this.isArmed.set(false);
    }

    private subscribeToFocused(): void {
        this.focusMonitor
            .monitor(this.host)
            .pipe(
                distinctUntilChanged(),
                filter(focusOrigin => focusOrigin === 'keyboard' && this.isArmed()),
                takeUntilDestroyed(this.destroyRef),
            )
            .subscribe(() => {
                this.focusRealmRouter.routingRequestSubject$.next({
                    hostRealmId: this.hostRealmId(),
                    direction: this.direction(),
                });
            });
    }
}
