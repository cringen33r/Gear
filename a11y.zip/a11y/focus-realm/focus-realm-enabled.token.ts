import { InjectionToken } from '@angular/core';

export const FOCUS_REALM_ENABLED_TOKEN = new InjectionToken<boolean>('Токен, активирующий функционал фокусных областей UI', {
    factory: (): boolean => false,
});
