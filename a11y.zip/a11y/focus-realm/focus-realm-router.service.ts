import { filter, fromEvent, shareReplay, Subject, tap } from 'rxjs';
import { DestroyRef, inject, Injectable, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { injectDebugFor } from '../../../../../debug';

import {
    FocusDirection,
    FocusRealmId,
    FocusRealmJumpEvent,
    FocusRoutingRequestEvent,
    ModuleToolbarRealmId,
    RealmRouterType,
} from './focus-realm.types';
import { getNextRealmId } from './focus-realm.utils';
import { RealmRouterConfig } from './realm-router-config';
import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';

/** Сервис, отвечающий за маршрутизацию табуляции между областями интерфейса в обход нативного DOM-порядка по
 * {@link https://wiki.infotecs.int/spaces/UEG/pages/218846316/%D0%9E%D0%9A%D0%9F+%D0%A3%D0%BF%D1%80%D0%B0%D0%B2%D0%BB%D0%B5%D0%BD%D0%B8%D0%B5+%D1%81+%D0%BA%D0%BB%D0%B0%D0%B2%D0%B8%D0%B0%D1%82%D1%83%D1%80%D1%8B ОКП "Управление с клавиатуры" }
 * ### Принцип
 * Сервис обрабатывает маршрутизацию между областями фокуса ТОЛЬКО когда пользователь выходит из области через табуляцию.
 * Остальные сценарии проходят без перехвата по штатному алгоритму.
 * ### Архитектура
 * Взаимодействие между `Router` - `Realm` - `Portal` построено через широковещательные `Subject` ({@link routingRequestSubject$} и {@link realmJumpEventSubject$}).
 * #### `Router`
 * Получает запрос на маршрутизацию, определяет следующую область для прыжка, сообщает о прыжке.
 * #### `Realm`
 * Слушает события прыжков, активирует/деактивирует собственные порталы.
 * #### `Portal`
 * Уведомляет `Router` о необходимости маршрутизации при выходе табуляцией из области.
 * ### Подключение в модуле
 * 1. Подключение в сервисе, имеющем доступ к `postMessage` от внешнего/внутреннего `iframe`, инициализация сервиса;
 * 2. Подписка на {@link `realmJumpEvent$`} и отсылка соответствующего сообщения модулю;
 * 3. Подписка на сообщение о прыжке от модуля и пуш в {@link `routingRequestSubject$`}
 * ({@link `FocusRoutingRequestEvent.hostRealmId`} требуется установить в `undefined`, {@link `FocusRoutingRequestEvent.direction`}
 * такой же, как у пришедшего события);
 * 4. Установка {@link `FocusRealmDirective`} на компоненты, являющиеся контейнерами областей UI согласно ОКП (см. {@link `FocusRealmId`})
 * */
@Injectable({
    providedIn: 'root',
})
export class FocusRealmRouterService {
    private readonly destroyRef = inject(DestroyRef);
    private readonly featureToken = inject(FOCUS_REALM_ENABLED_TOKEN);
    private readonly debug = injectDebugFor('FOCUS_REALM');
    config!: RealmRouterConfig;
    routerId!: 'CORE' | 'MODULE';

    readonly currentRealm = signal<FocusRealmId | undefined>(undefined);

    /** Downstream-канал для сообщения областей/модулей о прыжке. Сюда же перенаправляется напрямую запрос из другого модуля */
    readonly realmJumpEventSubject$ = new Subject<FocusRealmJumpEvent | null>();
    readonly realmJumpEvent$ = this.realmJumpEventSubject$.pipe(
        filter(Boolean),
        tap((jmp: FocusRealmJumpEvent) => this.debug.log('JUMP',this.routerId, `TO ${jmp.targetRealmId} WITH ${jmp.direction}`)),
        shareReplay(1),
        takeUntilDestroyed(),
    );

    /** Upstream-канал для сообщения маршрутизатору о необходимости прыжка */
    readonly routingRequestSubject$ = new Subject<FocusRoutingRequestEvent | null>();
    private readonly routingRequest$ = this.routingRequestSubject$.pipe(
        filter(Boolean),
        tap((req: FocusRoutingRequestEvent) => this.debug.log('REQUEST',this.routerId, `FROM ${req.hostRealmId} WITH ${req.direction}`)),
        takeUntilDestroyed(),
    );

    private readonly iframeJumpRequestSubject$ = new Subject<FocusRoutingRequestEvent | null>();
    readonly iframeJumpRequest$ = this.iframeJumpRequestSubject$.pipe(takeUntilDestroyed(this.destroyRef));

    init(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId): void {
        if (this.featureToken) {
            this.config = new RealmRouterConfig(type, moduleToolbarId);
            this.subscribeToTabReset();
            this.subscribeToRoutingRequests();
            this.routerId = type === 'monolith-core'? 'CORE' : 'MODULE';
        }
    }

    changeType(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId): void {
        if (this.featureToken) {
            this.config.changeType(type, moduleToolbarId);
        }
    }

    registerRealm(realmId: FocusRealmId, availabilityChecker: () => boolean): void {
        this.config.setRealmPresence(realmId, 'local');
        this.config.setRealmChecker(realmId, availabilityChecker);
        this.debug.debug('REGISTRATION', realmId, 'Registered');
    }

    unregisterRealm(realmId: FocusRealmId): void {
        this.config.resetRealm(realmId);
        this.debug.debug('REGISTRATION', realmId, 'Unregistered');
    }

    /** Если состояние фокуса сбросилось на базовое (`<body>`), то пробуем увести на наши области при первом табе. */
    private subscribeToTabReset(): void {
        fromEvent<KeyboardEvent>(document, 'keydown')
            .pipe(
                filter(event => event.key === 'Tab' && document.activeElement === document.body),
                tap(() => this.debug.log('REDIRECTION', this.routerId, 'Back to the hood')),
                takeUntilDestroyed(this.destroyRef),
            )
            .subscribe(event => {
                const direction: FocusDirection = event.shiftKey ? 'backward' : 'forward';
                event.preventDefault();
                this.routingRequestSubject$.next({ hostRealmId: undefined, direction });
            });
    }

    private subscribeToRoutingRequests(): void {
        this.routingRequest$.subscribe(req => {
            const withIframeSkip = this.config.getRealmPresence(req.hostRealmId) === 'iframe';
            const nextRealm = getNextRealmId(req.hostRealmId, req.direction, this.config, withIframeSkip, this.debug);
            if (this.config.getRealmPresence(nextRealm) === 'iframe') {
                this.iframeJumpRequestSubject$.next({
                    hostRealmId: req.hostRealmId,
                    direction: req.direction,
                });
            } else {
                this.realmJumpEventSubject$.next({
                    targetRealmId: nextRealm,
                    direction: req.direction,
                });
            }
        });
    }
}
