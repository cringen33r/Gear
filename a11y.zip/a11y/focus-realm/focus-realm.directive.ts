import { distinctUntilChanged } from 'rxjs/operators';
import { isEqual } from 'lodash-es';
import { FocusMonitor, InteractivityChecker } from '@angular/cdk/a11y';
import {
    AfterViewInit,
    ComponentRef,
    DestroyRef,
    Directive,
    DOCUMENT,
    ElementRef,
    inject,
    input,
    inputBinding,
    linkedSignal,
    OnDestroy,
    Renderer2,
    ViewContainerRef,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { injectDebugFor } from '../../../../../debug';
import { FocusBoundary, focusFocusableChild, getFocusableChild } from '../focus-utils';

import { FocusPortalComponent } from './focus-portal.component';
import { FocusDirection, FocusRealmId } from './focus-realm.types';
import { FocusRealmRouterService } from './focus-realm-router.service';
import { FOCUS_REALM_ENABLED_TOKEN } from './focus-realm-enabled.token';

/** Директива области фокуса UI.
 * Ответственность:
 * 1. Инициализация порталов;
 * 2. Установка фокуса на содержимое согласно команде из {@link `realmJumpEvent$`};
 * 3. Активация и деактивация порталов при изменении фокуса. */
@Directive({
    selector: '[webuiFocusRealm]',
    standalone: true,
    host: {
        '[attr.data-focusrealm]': 'this.realmId()',
    },
})
export class FocusRealmDirective implements AfterViewInit, OnDestroy {
    readonly webuiFocusRealm = input<FocusRealmId | undefined>(undefined);
    readonly realmId = linkedSignal(() => this.webuiFocusRealm());

    private readonly elementRef = inject<ElementRef<HTMLElement>>(ElementRef);
    private readonly focusRealmRouter = inject(FocusRealmRouterService);
    private readonly destroyRef = inject(DestroyRef);
    private readonly focusMonitor = inject(FocusMonitor);
    private readonly viewContainerRef = inject(ViewContainerRef);
    private readonly checker = inject(InteractivityChecker);
    private readonly renderer = inject(Renderer2);
    private readonly document = inject(DOCUMENT);
    private readonly debug = injectDebugFor('FOCUS_REALM');
    private readonly featureToken = inject(FOCUS_REALM_ENABLED_TOKEN);

    private forwardPortal!: ComponentRef<FocusPortalComponent>;
    private backwardPortal!: ComponentRef<FocusPortalComponent>;

    private registeredInterval: number | undefined;

    ngAfterViewInit(): void {
        if (this.featureToken) {
            this.registeredInterval = window.setInterval(() => {
                if (this.realmId()) {
                    this.clearInterval();
                    this.registerSelfInRouter();
                    this.setUpPortals();
                    this.subscribeToRealmJumps();
                    this.subscribeToFocus();
                }
            }, 32);
        }
    }

    ngOnDestroy(): void {
        this.unregisterSelfInRouter();
        this.destroyPortals();
    }

    private get host(): HTMLElement {
        return this.elementRef.nativeElement;
    }

    private setUpPortals(): void {
        this.forwardPortal = this.viewContainerRef.createComponent(FocusPortalComponent, {
            bindings: [
                inputBinding('direction', () => 'forward'),
                inputBinding('hostRealmId', () => this.realmId()),
            ],
        });
        this.backwardPortal = this.viewContainerRef.createComponent(FocusPortalComponent, {
            bindings: [
                inputBinding('direction', () => 'backward'),
                inputBinding('hostRealmId', () => this.realmId()),
            ],
        });

        // Перенос заднего портала на место перед хостом
        const parent = this.renderer.parentNode(this.host) as HTMLElement;
        this.renderer.insertBefore(parent, this.backwardPortal.location.nativeElement, this.host);
    }

    private destroyPortals(): void {
        this.forwardPortal.destroy();
        this.backwardPortal.destroy();
    }

    private clearInterval(): void {
        clearInterval(this.registeredInterval);
    }

    private subscribeToFocus(): void {
        this.focusMonitor.monitor(this.host, true).pipe(
            distinctUntilChanged(isEqual),
            takeUntilDestroyed(this.destroyRef),
        ).subscribe(focus => {
            if (focus) {
                this.debug.log('FOCUS', this.realmId(), 'Focused');
                this.armPortals();
            } else {
                setTimeout(() => this.disarmPortals(), 0);
            }
        });
    }

    private armPortals(): void {
        this.debug.debug('PORTAL', this.realmId(), 'Portals armed');
        this.forwardPortal.instance.arm();
        this.backwardPortal.instance.arm();
    }

    private disarmPortals(): void {
        this.debug.debug('PORTAL', this.realmId(), 'Portals disarmed');
        this.forwardPortal.instance.disarm();
        this.backwardPortal.instance.disarm();
    }

    private subscribeToRealmJumps(): void {
        this.focusRealmRouter.realmJumpEvent$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(realmJump => {
                if (realmJump.targetRealmId === this.realmId()) {
                    if (this.checkAvailability()) {
                        this.setFocus(realmJump.direction);
                        this.armPortals();
                        this.focusRealmRouter.currentRealm.set(this.realmId());
                    } else {
                        this.debug.warn('REALM', this.realmId(), `Realm is unreachable, requesting further routing`);
                        this.disarmPortals();
                        this.focusRealmRouter.routingRequestSubject$.next({
                            hostRealmId: this.realmId(),
                            direction: realmJump.direction,
                        });
                    }
                } else {
                    this.disarmPortals();
                }
            });
        this.focusRealmRouter.iframeJumpRequest$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
                this.document.body.focus();
                this.disarmPortals();
            });
    }

    private setFocus(direction: FocusDirection): boolean {
        const boundary: FocusBoundary = direction === 'forward' ? 'start' : 'end';
        return focusFocusableChild(this.host, boundary, this.checker);
    }

    private checkAvailability(): boolean {
        const isConnected = this.host.isConnected
            && !!this.host.parentElement;
        if (!isConnected) {
            this.debug.error('FOCUS', this.realmId(), 'No connection to DOM');
            return false;
        }
        const result = getFocusableChild(this.host, 'start', this.checker);
        if (!result) {
            this.debug.warn('FOCUS', this.realmId(), 'No focusable children');
        }
        return !!result;
    }

    private registerSelfInRouter(): void {
        const realmId = this.realmId();
        if (realmId) {
            this.focusRealmRouter.registerRealm(realmId, this.checkAvailability.bind(this));
        }
    }

    private unregisterSelfInRouter(): void {
        const realmId = this.realmId();
        if (realmId) {
            this.focusRealmRouter.unregisterRealm(realmId);
        }
    }
}
