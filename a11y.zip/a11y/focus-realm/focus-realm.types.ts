import { InputSignal } from '@angular/core';

/** Для каждого модуля имеется собственный компонент тулбара, потому области нужно указать явно */
export type ModuleToolbarRealmId = 'mainToolbarVPN' | 'mainToolbarNVS' | 'mainToolbarPMM' | 'mainToolbarCB' | 'mainToolbarROC';

/** Заранее определённые области фокуса на UI */
export type FocusRealmId = 'tabs'
    | 'content'
    | 'contextPanel'
    | 'navPanel'
    | 'modulesMenu'
    | 'mainToolbarSMP' | 'mainToolbarAdmin'
    | ModuleToolbarRealmId;

/** Область фокуса может быть определена как присутствующая либо в этом же документе (`'local'`),
 * либо в родительском или дочернем документе (`'iframe'`), либо ещё незарегистрированная (`undefined`).
 * Область в `iframe` считается по умолчанию всегда доступной, поскольку её невозможно проверить - обработка
 * маршрутизации передаётся в соседний модуль, в котором эта область может быть объявлена.
 * */
export type FocusRealmPresence = 'local' | 'iframe' | undefined;

/** Направление перехода фокуса. */
export type FocusDirection = 'forward' | 'backward';

/** Фокусный портал для триггера события о необходимости маршрутизации (см. {@link FocusRoutingRequestEvent}) */
export interface FocusPortal {
    hostRealmId: InputSignal<FocusRealmId>;
    direction: InputSignal<FocusDirection>;
}

/** Широковещательное событие о прыжке в новую область. Может вести на `<body>` (`undefined`), если нет доступных областей */
export interface FocusRealmJumpEvent {
    targetRealmId: FocusRealmId | undefined;
    direction: FocusDirection;
}

/** Сообщение маршрутизатору о необходимости прыжка с области `hostRealmId` на следующую доступную в направлении
 * `direction`. Может инициализироваться с `<body>` (undefined) */
export interface FocusRoutingRequestEvent {
    hostRealmId: FocusRealmId | undefined;
    direction: FocusDirection;
    isSelf?: boolean;
}

/** Определение области */
export interface RealmRoute {
    id: FocusRealmId;
    presence: FocusRealmPresence;
    availabilityChecker: (() => boolean) | null;
}

/** Тип роутера в модуле влияет на доступность тех или иных фокусных областей UI, что необходимо для верного определения
 *  `iframe` областей*/
export type RealmRouterType = 'module' | 'moduled-core' | 'monolith-core';
