import { FocusDirection, FocusRealmId } from './focus-realm.types';
import { RealmRouterConfig } from './realm-router-config';
import { FeatureDebug } from '../../../../../debug';

/** Получаем следующую доступную область в направлении `event.direction` */
export function getNextRealmId(
    hostRealmId: FocusRealmId | undefined,
    direction: FocusDirection,
    config: RealmRouterConfig,
    withIframeSkip: boolean,
    debug?: FeatureDebug<'FOCUS_REALM'>,
): FocusRealmId | undefined {
    const step = direction === 'forward' ? 1 : -1;
    const order = config.getOrder();
    const n = order.length;
    const hasHost = hostRealmId !== undefined;
    let start: number;
    if (hostRealmId) {
        start = order.indexOf(hostRealmId);
    } else {
        start = 0;
    }
    let i = hasHost ? start + step : 0;
    const steps = hasHost ? n - 1 : n;
    let nextRealm: FocusRealmId | undefined;
    for (let k = 0; k < steps; k++) {
        const idx = wrapOrderIndex(i, n);
        const candidate = order[idx];
        const isAvailable = isRealmAvailable(candidate, config, withIframeSkip, debug);
        if (isAvailable === true) {
            nextRealm = candidate;
            break;
        }
        i += step;
    }
    if (nextRealm) {
        debug?.log('ROUTING', nextRealm, `Next realm is ${nextRealm}`);
    } else {
        debug?.warn('ROUTING', hostRealmId, `No available realms, returning back to ${hostRealmId}`);
    }
    return nextRealm ?? hostRealmId;
}

/** Проверка на фактическую доступность области в данный момент времени. Необходимо в силу неустойчивости UI при навигации. */
export function isRealmAvailable(
    targetRealmId: FocusRealmId,
    config: RealmRouterConfig,
    withIframeSkip: boolean,
    debug?: FeatureDebug<'FOCUS_REALM'>,
): boolean | 'iframe' {
    const realm = config.getRealmRoute(targetRealmId);
    let isAvailable;
    if (realm.presence === 'iframe') {
        isAvailable = !withIframeSkip;
    } else {
        isAvailable = realm.availabilityChecker?.() ?? false;
    }
    debug?.log('AVAILABILITY', targetRealmId, `Realm is ${realm.presence}, status: ${isAvailable ? 'available' : 'not available'}`);
    return isAvailable;
}

export function wrapOrderIndex(i: number, length: number): number {
    return ((i % length) + length) % length;
}
