import {
    FocusRealmId,
    FocusRealmPresence,
    ModuleToolbarRealmId,
    RealmRoute,
    RealmRouterType,
} from './focus-realm.types';

/** Конфигурация маршрутизатора областей фокуса. Определяет порядок переключения между {@link FocusRealmId}
 * и хранит присутствие маршрутов ({@link FocusRealmPresence})*/
export class RealmRouterConfig {
    private readonly order: FocusRealmId[] = [
        'tabs',
        'content',
        'contextPanel',
        'navPanel',
        'modulesMenu',
        'mainToolbarSMP',
        'mainToolbarAdmin',
        'mainToolbarVPN',
        'mainToolbarNVS',
        'mainToolbarPMM',
        'mainToolbarCB',
        'mainToolbarROC',
    ];
    private readonly routes: Record<string, RealmRoute> = {
        tabs: { id: 'tabs', presence: undefined, availabilityChecker: null },
        content: { id: 'content', presence: undefined, availabilityChecker: null },
        contextPanel: { id: 'contextPanel', presence: undefined, availabilityChecker: null },
        navPanel: { id: 'navPanel', presence: undefined, availabilityChecker: null },
        modulesMenu: { id: 'modulesMenu', presence: undefined, availabilityChecker: null },
        // В ядре для каждого модуля свой `smp-module-page-layout` и собственный `webui-toolbar`
        mainToolbarSMP: { id: 'mainToolbarSMP', presence: undefined, availabilityChecker: null },
        mainToolbarAdmin: { id: 'mainToolbarAdmin', presence: undefined, availabilityChecker: null },
        mainToolbarVPN: { id: 'mainToolbarVPN', presence: undefined, availabilityChecker: null },
        mainToolbarNVS: { id: 'mainToolbarNVS', presence: undefined, availabilityChecker: null },
        mainToolbarPMM: { id: 'mainToolbarPMM', presence: undefined, availabilityChecker: null },
        mainToolbarCB: { id: 'mainToolbarCB', presence: undefined, availabilityChecker: null },
        mainToolbarROC: { id: 'mainToolbarROC', presence: undefined, availabilityChecker: null },
    };

    constructor(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId) {
        this.changeType(type, moduleToolbarId);
    }

    changeType(type: RealmRouterType, moduleToolbarId?: ModuleToolbarRealmId): void {
        if (type === 'module') {
            this.setRealmPresence('modulesMenu', 'iframe');
            if (moduleToolbarId) {
                this.setRealmPresence(moduleToolbarId, 'iframe');
            }
        } else {
            const presence = type === 'monolith-core' ? undefined : 'iframe';
            this.setRealmPresence('tabs', presence);
            this.setRealmPresence('content', presence);
            this.setRealmPresence('contextPanel', presence);
            this.setRealmPresence('navPanel', presence);
        }
    }

    getOrder(): FocusRealmId[] {
        return this.order;
    }

    getRealmRoute(route: FocusRealmId): RealmRoute {
        return this.routes[route];
    }

    setRealmPresence(realmId: FocusRealmId, presence: FocusRealmPresence): void {
        this.routes[realmId].presence = presence;
    }

    getRealmPresence(realmId: FocusRealmId | undefined): FocusRealmPresence | undefined {
        if (realmId) {
            return this.routes[realmId].presence;
        } else {
            return undefined;
        }
    }

    setRealmChecker(realmId: FocusRealmId, checker: () => boolean): void {
        this.routes[realmId].availabilityChecker = checker;
    }

    resetRealm(realmId: FocusRealmId): void {
        this.routes[realmId].presence = undefined;
        this.routes[realmId].availabilityChecker = null;
    }
}
