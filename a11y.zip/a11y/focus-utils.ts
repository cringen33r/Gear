import { InteractivityChecker } from '@angular/cdk/a11y';
import { FocusDirection } from './index';
import { FeatureDebug } from '../../../../debug';

export type FocusBoundary = 'start' | 'end';

export function focusFocusableChild(
    root: HTMLElement,
    boundary: FocusBoundary,
    checker: InteractivityChecker,
): boolean {
    const element = getFocusableChild(root, boundary, checker);
    element?.focus();
    return !!element;
}

export function getFocusableChild(
    root: HTMLElement,
    boundary: FocusBoundary,
    checker: InteractivityChecker,
    depth = 0,
): HTMLElement | null {
    if (!root) {
        return null;
    }
    if (depth++ && checker.isFocusable(root) && checker.isTabbable(root)) {
        return root;
    }
    const children = root.children;
    const isForward = boundary === 'start';
    let i = isForward ? 0 : children.length - 1;
    const end = isForward ? children.length : -1;
    const step = isForward ? 1 : -1;
    while (i !== end) {
        const node = children[i];
        if (node.nodeType === document.ELEMENT_NODE) {
            const isFound = getFocusableChild(node as HTMLElement, boundary, checker, depth);
            if (isFound) {
                return isFound;
            }
        }
        i += step;
    }
    return null;
}

export function getNextFocusable(
    root: HTMLElement,
    direction: FocusDirection,
    checker: InteractivityChecker,
    debug: FeatureDebug<'GRID'>,
    height = 0,
): HTMLElement | null {
    root.classList.add('focus-root');
    const parent = root.parentElement;
    const step = direction === 'forward' ? 1 : -1;
    if (parent) {
        debug.debug('FOCUS', parent.tagName, `Start checking, height is ${height}`);
        const children = Array.from(parent.children) as HTMLElement[];
        debug.debug('FOCUS', parent.tagName, `Children are...`);
        debug.raw(children);
        const rootIndex = children.findIndex(el => el.classList.contains('focus-root'));
        root.classList.remove('focus-root');
        if (rootIndex === -1) {
            return null;
        }
        let i = rootIndex + step;
        debug.debug('FOCUS', parent.tagName, `Starting index is ${i}`);
        let nextToFocus: HTMLElement | null = null;
        let counter = 1;
        while (counter++ !== children.length) {
            if (i === rootIndex) {
                debug.debug('FOCUS', parent.tagName, `Full circle`);
                break;
            }
            const nextElement = children[i];
            debug.debug('FOCUS', parent.tagName, `Checking child...`);
            debug.raw(nextElement);
            i += step;
            const focusableChild = getFocusableChild(nextElement, direction === 'forward' ? 'start' : 'end', checker, 1);
            if (focusableChild) {
                nextToFocus = focusableChild;
                break;
            }
        }
        if (!nextToFocus) {
            return getNextFocusable(parent, direction, checker, debug, height++);
        }
        debug.debug('FOCUS', parent.tagName, `Next to focus is...`);
        debug.raw(nextToFocus);
        return nextToFocus;
    }
    return null;
}
