import { Component, DestroyRef, inject, InputSignal, output } from '@angular/core';
import { TreeNode } from '../../../../tree-table/tree-node';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { GridService } from './grid.service';
import { RowPointerPosition } from './grid.types';
import { filter } from 'rxjs/operators';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { getRowColumnIds } from './grid-utils';

@Component({
    template: ``,
})
export abstract class GridBaseComponent<T = unknown> {
    protected readonly gridService = inject(GridService);
    protected readonly destroyRef = inject(DestroyRef);
    protected readonly gridKeyboardToken = inject(GRID_KEYBOARD_ENABLED_TOKEN);

    readonly customGridAction = output<string>();
    readonly contextPanelToggled = output<TreeNode<T>>();

    protected constructor() {
        if (this.gridKeyboardToken) {
            this.subscribeToGridCustomActions();
            this.subscribeToGridRowActions();
        }
    }

    protected subscribeToGridRowPointer(): void {
        this.gridService.pointer$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(pointer => {
            if (pointer?.targetId) {
                const split = getRowColumnIds(pointer.targetId);
                this.scrollIntoCenterIfNeededById(split[0]);
            }
        });
    }

    private subscribeToGridCustomActions(): void {
        this.gridService.customAction$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(action => this.customGridAction.emit(action));
    }

    private subscribeToGridRowActions(): void {
        this.gridService.gridAction$
            .pipe(
                filter(action => action?.currentPointer?.state?.position?.type === 'row'),
                takeUntilDestroyed(this.destroyRef),
            )
            .subscribe(action => {
                const rowAction = this.gridService.getActionFor('row', action.action);
                const pointerIndex= (action.currentPointer.state.position as RowPointerPosition).rowIndex;
                const rows = action.currentPointer.state.selectedRowRange ?? [pointerIndex];
                switch(rowAction) {
                    case 'check':
                        this.checkNodes(this.getPointedNodes(rows));
                        break;
                    case 'expand':
                        this.expandNodes(this.getPointedNodes(rows));
                        break;
                    case 'toggle-context-panel':
                        this.contextPanelToggled.emit(this.getPointedNodes([pointerIndex])[0]);
                        break;
                }
            });
    }

    private getPointedNodes(rowIndexes: number[]): TreeNode<T>[] {
        return this.items().slice(rowIndexes[0], rowIndexes[rowIndexes.length - 1] + 1);
    }

    readonly abstract items: InputSignal<TreeNode<T>[]>;
    abstract scrollIntoCenterIfNeededById(nodeId: string): void;
    protected abstract checkNodes(nodes: TreeNode<T>[]): void;
    protected abstract expandNodes(nodes: TreeNode<T>[]): void;
    protected abstract initGrid(): void;
}
