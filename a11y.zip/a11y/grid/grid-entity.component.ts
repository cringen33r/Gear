import { fromEvent } from 'rxjs';
import { FocusTrap, FocusTrapFactory, InteractivityChecker } from '@angular/cdk/a11y';
import { Component, computed, DestroyRef, effect, ElementRef, inject, input, OnInit, signal, viewChildren } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { injectDebugFor } from '../../../../../debug';

import { GridService } from './grid.service';
import { CellPrimaryAction, GridEntity } from './grid.types';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { getRowColumnIds, getUnitedColumnsIfNeeded } from './grid-utils';
import { filter } from 'rxjs/operators';
import { getFocusableChild } from '../focus-utils';
import { WebuiOverflowTooltipDirective } from '../../../tooltip';
import { IS_TOOLTIP_FOCUSABLE } from '../../../tooltip/focusable-tooltip.token';

@Component({
    template: ``,
    host: {
        '[class.pointed]': 'isPointed()',
        '[class.range-pointed]': 'isRangePointed()',
        '[class.focus-trapped]': 'this.focusTrapSet()',
        '[attr.gridid]': 'this.gridEntityId()',
    },
})
export abstract class GridEntityComponent<E extends GridEntity> implements OnInit {
    readonly gridEntityId = input<string | undefined>(undefined, {
        transform: id =>
            getUnitedColumnsIfNeeded(this.gridService?.config?.columnsToUnite ?? [], id as string),
    });

    protected readonly destroyRef = inject(DestroyRef);
    protected readonly gridService = inject(GridService);
    protected readonly debug = injectDebugFor('GRID');
    protected readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
    protected readonly featureToken = inject(GRID_KEYBOARD_ENABLED_TOKEN);
    private readonly focusTrapFactory = inject(FocusTrapFactory);
    private readonly checker = inject(InteractivityChecker);

    private focusTrap: FocusTrap | undefined;
    protected focusTrapSet = signal(false);
    private focusTrapRegistrationInterval: number | undefined;

    protected gridActions: Record<CellPrimaryAction, () => void> | undefined = {
        'focus-first': this.focusFirst,
    };
    protected withActions = true;

    protected isRangePointed = computed<boolean>(() => {
        const id = this.gridEntityId();
        if (id) {
            const rowId = getRowColumnIds(id)[0];
            const pointer = this.gridService.pointer();
            const isCellPointed = pointer?.selectedTargetIds?.includes(id) ?? false;
            const isRowPointed = pointer?.selectedTargetIds?.includes(rowId) ?? false;
            const isPointed = isCellPointed || isRowPointed;
            if (isPointed) {
                this.debug.log('ENTITY', this.entity, `${this.gridEntityId()} is range-pointed`);
            }
            return isPointed;
        }
        return false;
    });

    protected readonly isPointed = computed<boolean>(() => {
        const id = this.gridEntityId();
        if (id) {
            const rowId = getRowColumnIds(id)[0];
            const pointer = this.gridService.pointer();
            const isCellPointed = pointer?.targetId === id;
            const isRowPointed = pointer?.targetId === rowId;
            const isPointed = isCellPointed || isRowPointed;
            if (isPointed) {
                this.debug.log('ENTITY', this.entity, `${this.gridEntityId()} is pointed`);
            }
            return isPointed;
        }
        return false;
    });

    // === Инициализация ===

    constructor() {
        effect(() => {
            if (this.entity !== 'row' && !this.isPointed()) {
                this.destroyFocusTrap();
            }
        });
    }

    ngOnInit(): void {
        if (this.featureToken) {
            if (this.gridEntityId() && this.withActions) {
                this.subscribeToGridActions();
            }
            if (this.gridEntityId()) {
                this.subscribeToMouseActions();
            }
        }
    }

    private focusFirst(): void {
        const firstFocusable = getFocusableChild(this.host, 'start', this.checker);
        if (firstFocusable) {
            this.debug.log('FOCUS', this.gridEntityId(), 'Activated first focusable');
            this.setupFocusTrap();
        } else {
            this.debug.warn('FOCUS', this.gridEntityId(), 'No focusable');
        }
    }

    private toggleFocusTrap(): void {
        if (this.focusTrap) {
            this.destroyFocusTrap();
        } else {
            this.setupFocusTrap();
        }
    }

    // === Подписки ===

    private destroyFocusTrap(): void {
        if (this.focusTrap) {
            this.debug.log('FOCUS_TRAP', this.gridEntityId(), `DestroyFocusTrap`);
            this.focusTrap?.destroy();
            this.focusTrap = undefined;
            clearInterval(this.focusTrapRegistrationInterval);
            this.gridService.isFocusTrapActive.set(false);
            this.focusTrapSet.set(false);
            this.gridService.focusTable();
        }
    }

    private setupFocusTrap(): void {
        this.debug.log('FOCUS_TRAP', this.gridEntityId(), `Handling focus trap`);
        this.focusTrap = this.focusTrapFactory.create(this.host);
        clearInterval(this.focusTrapRegistrationInterval);
        this.focusTrapRegistrationInterval = window.setInterval(() => {
            if (this.focusTrap?.hasAttached()) {
                clearInterval(this.focusTrapRegistrationInterval);
                this.focusTrap?.focusFirstTabbableElementWhenReady()
                    .then(focused => {
                        if (focused && this.focusTrap) {
                            this.focusTrap.enabled = true;
                            this.gridService.isFocusTrapActive.set(true);
                            this.focusTrapSet.set(true);
                        } else {
                            this.destroyFocusTrap();
                        }
                    });
            }
        }, 16);
    }

    private subscribeToMouseActions(): void {
        fromEvent<MouseEvent>(this.host, 'click')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(event => {
                const id = this.gridEntityId();
                if (id) {
                    this.gridService.changePointerTo(this.entity, id, event.shiftKey);
                    window.getSelection()?.removeAllRanges();
                }
            });
    }

    private subscribeToGridActions(): void {
        const isThereActions =
            (!!this.gridService.getActionFor(this.entity, 'primary')
            || !!this.gridService.getActionFor(this.entity, 'secondary'))
            && this.gridActions;
        if (isThereActions) {
            this.gridService.gridAction$.pipe(
                filter(action => action.currentPointer.targetId === this.gridEntityId()),
                takeUntilDestroyed(this.destroyRef),
            ).subscribe(action => {
                this.debug.log('ACTION', this.entity, `Received action '${action.action}' for ${this.gridEntityId()}`);
                const gridAction = this.gridService.getActionFor(this.entity, action.action) as CellPrimaryAction;
                if (gridAction) {
                    this.debug.log('ACTION', this.entity, `Performing action '${gridAction}' for ${this.gridEntityId()}`);
                    this.gridActions?.[gridAction]?.call(this);
                }
            });
        }
    }

    // === Абстракции ===

    protected abstract entity: E;
}
