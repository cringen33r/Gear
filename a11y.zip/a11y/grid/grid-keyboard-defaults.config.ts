import { GridActionsConfig, GridSettings } from './grid.types';

export const defaultGridActionsConfig: GridActionsConfig = {
    header: {
        primary: 'focus-first',
        secondary: undefined,
    },
    cell: {
        primary: 'focus-first',
        secondary: undefined,
    },
    row: {
        primary: undefined,
        secondary: undefined,
    },
};

export const defaultGridSettings: GridSettings = {
    gridActionsConfig: defaultGridActionsConfig,
    isRowingOnly: false,
    withWrap: false,
    customGridActions: [
        {
            name: 'delete',
            key: 'Delete',
        },
    ],
    columnsToUnite: ['checkbox', 'numberInLayer', 'priority'],
};

export const downKeys = ['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'KeyA', 'Tab'];
export const upKeys = ['Enter', 'Space', 'AltLeft', 'Home', 'End'];
export const badKeys = ['ArrowUp', 'ArrowDown', 'Space', 'Home', 'End', 'AltLeft', 'KeyA'];
