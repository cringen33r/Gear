import { InjectionToken } from '@angular/core';

export const GRID_KEYBOARD_ENABLED_TOKEN = new InjectionToken<boolean>('Токен, активирующий функционал управления таблицами с клавиатуры', {
    factory: (): boolean => false,
});

