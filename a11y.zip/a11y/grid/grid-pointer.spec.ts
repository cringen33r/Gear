import { beforeEach, describe, expect, it } from 'vitest';

import { GridPointerConfig, GridPointerPosition } from './grid.types';
import { GridPointer } from './grid-pointer';
function createPointer(overrides: Partial<GridPointerConfig> = {}): GridPointer {
    const config: GridPointerConfig = {
        rowCount: 3,
        columnCount: 3,
        isRowingOnly: true,
        withWrap: false,
        ...overrides,
    };

    return new GridPointer(config);
}

describe('GridPointer', () => {
    describe('resetToFirstHeader', () => {
        it('moves the pointer to the first header column and clears selection', () => {
            const pointer = createPointer();
            const state = pointer.resetToFirstHeader();

            expect(state.position).toEqual({ type: 'header', columnIndex: 0 });
            expect(pointer.current).toEqual({ type: 'header', columnIndex: 0 });
            expect(pointer.lastColumnIndex).toBe(0);
            expect(pointer.selectionAnchor).toBeNull();
        });

        it('clears an active selection anchor', () => {
            const pointer = createPointer();
            pointer.resetToFirstHeader();
            pointer.moveDown();
            pointer.moveDown(true);
            expect(pointer.selectionAnchor).not.toBeNull();

            pointer.resetToFirstHeader();
            expect(pointer.selectionAnchor).toBeNull();
        });
    });

    describe('header row navigation', () => {
        let pointer: GridPointer;

        beforeEach(() => {
            pointer = createPointer();
            pointer.resetToFirstHeader();
        });

        it('moves left/right across headers and clamps at the edges without wrap', () => {
            expect(pointer.moveRight().position).toEqual({ type: 'header', columnIndex: 1 });
            expect(pointer.moveRight().position).toEqual({ type: 'header', columnIndex: 2 });
            expect(pointer.moveRight().position).toEqual({ type: 'header', columnIndex: 2 });

            expect(pointer.moveLeft().position).toEqual({ type: 'header', columnIndex: 1 });
        });

        it('wraps across headers when withWrap is enabled', () => {
            const wrapping = createPointer({ withWrap: true });
            wrapping.resetToFirstHeader();

            expect(wrapping.moveLeft().position).toEqual({ type: 'header', columnIndex: 2 });
            expect(wrapping.moveRight().position).toEqual({ type: 'header', columnIndex: 0 });
        });

        it('remembers the last column when leaving the header row', () => {
            const cellular = createPointer({ isRowingOnly: false });
            cellular.setMode('cellular');
            cellular.resetToFirstHeader();
            cellular.moveRight();
            cellular.moveRight();

            expect(cellular.lastColumnIndex).toBe(2);
            expect(cellular.moveDown().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 2 });
        });

        it('jumps to the first/last column with Home/End', () => {
            pointer.moveRight();

            expect(pointer.moveHome().position).toEqual({ type: 'header', columnIndex: 0 });
            expect(pointer.moveEnd().position).toEqual({ type: 'header', columnIndex: 2 });
        });
    });

    describe('rowing mode', () => {
        let pointer: GridPointer;

        beforeEach(() => {
            pointer = createPointer();
            pointer.resetToFirstHeader();
        });

        it('moves down into the first row, then between rows', () => {
            expect(pointer.moveDown().position).toEqual({ type: 'row', rowIndex: 0 });
            expect(pointer.moveDown().position).toEqual({ type: 'row', rowIndex: 1 });
            expect(pointer.moveDown().position).toEqual({ type: 'row', rowIndex: 2 });
        });

        it('clamps at the last row without wrap', () => {
            pointer.moveDown();
            pointer.moveDown();
            pointer.moveDown();

            expect(pointer.moveDown().position).toEqual({ type: 'row', rowIndex: 2 });
        });

        it('moves back to the header from the first row', () => {
            pointer.moveDown();
            expect(pointer.moveUp().position).toEqual({ type: 'header', columnIndex: 0 });
        });

        it('wraps from the last row back to the header when withWrap is enabled', () => {
            const wrapping = createPointer({ withWrap: true });
            wrapping.resetToFirstHeader();
            wrapping.moveDown();
            wrapping.moveDown();
            wrapping.moveDown();

            expect(wrapping.current).toEqual({ type: 'row', rowIndex: 2 });
            expect(wrapping.moveDown().position).toEqual({ type: 'header', columnIndex: 0 });
        });

        it('ignores left/right on a row position', () => {
            pointer.moveDown();
            const before = pointer.current;

            expect(pointer.moveRight().position).toEqual(before);
            expect(pointer.moveLeft().position).toEqual(before);
        });

        it('moves to the first/last row with Home/End', () => {
            pointer.moveDown();

            expect(pointer.moveHome().position).toEqual({ type: 'row', rowIndex: 0 });
            expect(pointer.moveEnd().position).toEqual({ type: 'row', rowIndex: 2 });
        });
    });

    describe('cellular mode', () => {
        let pointer: GridPointer;

        beforeEach(() => {
            pointer = createPointer({ isRowingOnly: false });
            pointer.setMode('cellular');
            pointer.resetToFirstHeader();
        });

        it('moves through cells and back into the header', () => {
            expect(pointer.moveDown().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 0 });
            expect(pointer.moveRight().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 1 });
            expect(pointer.moveDown().position).toEqual({ type: 'cell', rowIndex: 1, columnIndex: 1 });
            expect(pointer.moveUp().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 1 });

            pointer.moveUp();
            expect(pointer.moveUp().position).toEqual({ type: 'header', columnIndex: 1 });
        });

        it('preserves column position when re-entering from the header', () => {
            pointer.moveRight();
            pointer.moveRight();

            expect(pointer.moveDown().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 2 });
        });

        it('clamps column navigation at the row edges without wrap', () => {
            pointer.moveDown();

            expect(pointer.moveLeft().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 0 });

            pointer.moveRight();
            pointer.moveRight();
            expect(pointer.moveRight().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 2 });
        });

        it('clamps at the last row without wrap and wraps to the header when enabled', () => {
            const wrapping = createPointer({ isRowingOnly: false, withWrap: true });
            wrapping.setMode('cellular');
            wrapping.resetToFirstHeader();
            wrapping.moveDown();
            wrapping.moveDown();
            wrapping.moveDown();

            expect(wrapping.current).toEqual({ type: 'cell', rowIndex: 2, columnIndex: 0 });
            expect(wrapping.moveDown().position).toEqual({ type: 'header', columnIndex: 0 });
        });

        it('moves Home/End within a row', () => {
            pointer.moveDown();
            pointer.moveRight();

            expect(pointer.moveHome().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 0 });
            expect(pointer.moveEnd().position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 2 });
        });

        it('jumps to the last row with shift+End, keeping the remembered column', () => {
            pointer.moveDown();
            pointer.moveRight();

            const state = pointer.moveEnd(true);
            expect(state.position).toEqual({ type: 'cell', rowIndex: 2, columnIndex: 1 });
        });
    });

    describe('shift-selection (rowing mode)', () => {
        let pointer: GridPointer;

        beforeEach(() => {
            pointer = createPointer();
            pointer.resetToFirstHeader();
            pointer.moveDown();
        });

        it('captures the anchor on the first shift move and extends the range', () => {
            const first = pointer.moveDown(true);
            expect(first.selectedRowRange).toEqual([0, 1]);
            expect(pointer.selectionAnchor).toBe(0);

            const second = pointer.moveDown(true);
            expect(second.selectedRowRange).toEqual([0, 1, 2]);

            const backUp = pointer.moveUp(true);
            expect(backUp.selectedRowRange).toEqual([0, 1]);
        });

        it('clears the selection on a plain (non-shift) move', () => {
            pointer.moveDown(true);
            expect(pointer.selectionAnchor).not.toBeNull();

            const plain = pointer.moveDown();
            expect(plain.selectedRowRange).toBeNull();
            expect(pointer.selectionAnchor).toBeNull();
        });

        it('selects the full range with shift+Home / shift+End', () => {
            pointer.moveDown();
            const shiftEnd = pointer.moveEnd(true);
            expect(shiftEnd.selectedRowRange).toEqual([1, 2]);

            const shiftHome = pointer.moveHome(true);
            expect(shiftHome.selectedRowRange).toEqual([0, 1]);
        });

        it('does not build a selection range in cellular mode', () => {
            const cellular = createPointer({ isRowingOnly: false });
            cellular.setMode('cellular');
            cellular.resetToFirstHeader();
            cellular.moveDown();

            const state = cellular.moveDown(true);
            expect(state.selectedRowRange).toBeNull();
            expect(cellular.selectionAnchor).toBeNull();
        });
    });

    describe('setMode', () => {
        it('converts a row position into a cell using the remembered column', () => {
            const pointer = createPointer();
            pointer.resetToFirstHeader();
            pointer.moveDown();
            pointer.moveRight();

            const state = pointer.setMode('cellular');
            expect(state.position).toEqual({ type: 'cell', rowIndex: 0, columnIndex: 0 });
            expect(pointer.mode).toBe('cellular');
        });

        it('converts a cell position into a row', () => {
            const pointer = createPointer({ isRowingOnly: false });
            pointer.setMode('cellular');
            pointer.resetToFirstHeader();
            pointer.moveDown();
            pointer.moveRight();

            const state = pointer.setMode('rowing');
            expect(state.position).toEqual({ type: 'row', rowIndex: 0 });
        });

        it('clears the selection anchor', () => {
            const pointer = createPointer();
            pointer.resetToFirstHeader();
            pointer.moveDown();
            pointer.moveDown(true);
            expect(pointer.selectionAnchor).not.toBeNull();

            pointer.setMode('rowing');
            expect(pointer.selectionAnchor).toBeNull();
        });
    });

    describe('setPosition', () => {
        it('normalizes and adopts the given position, clearing selection', () => {
            const pointer = createPointer({ isRowingOnly: false });
            pointer.setMode('cellular');
            pointer.resetToFirstHeader();
            const target: GridPointerPosition = { type: 'cell', rowIndex: 1, columnIndex: 2 };

            const state = pointer.setPosition(target);
            expect(state.position).toEqual(target);
            expect(pointer.lastColumnIndex).toBe(2);
            expect(pointer.selectionAnchor).toBeNull();
        });

        it('clamps out-of-range positions', () => {
            const pointer = createPointer({ isRowingOnly: false });
            pointer.setMode('cellular');
            pointer.resetToFirstHeader();

            const state = pointer.setPosition({ type: 'cell', rowIndex: 99, columnIndex: 99 });
            expect(state.position).toEqual({ type: 'cell', rowIndex: 2, columnIndex: 2 });
        });

        it('accepts a null position', () => {
            const pointer = createPointer();
            pointer.resetToFirstHeader();

            const state = pointer.setPosition(null);
            expect(state.position).toBeNull();
            expect(pointer.current).toBeNull();
        });
    });

    describe('setWrap', () => {
        it('toggles wrap-around without touching position or selection', () => {
            const pointer = createPointer({ withWrap: false });
            pointer.resetToFirstHeader();
            pointer.moveDown();

            const before = pointer.current;
            pointer.setWrap(true);

            expect(pointer.withWrap).toBe(true);
            expect(pointer.current).toEqual(before);
        });
    });

    describe('getSelectionRange', () => {
        it('is null without an active anchor', () => {
            const pointer = createPointer();
            pointer.resetToFirstHeader();

            expect(pointer.getSelectionRange()).toBeNull();
        });

        it('reflects the pointer state after a shift move', () => {
            const pointer = createPointer();
            pointer.resetToFirstHeader();
            pointer.moveDown();
            pointer.moveDown(true);

            expect(pointer.getSelectionRange()).toEqual([0, 1]);
        });
    });
});
