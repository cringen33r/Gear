import {
    CellPointerPosition,
    GridNavigationMode,
    GridPointerConfig,
    GridPointerPosition,
    GridPointerState,
    RowPointerPosition,
} from './grid.types';

type Direction = 'up' | 'down' | 'home' | 'end';
type NonNullGridPointerPosition = Exclude<GridPointerPosition, null>;

export class GridPointer {
    private position: GridPointerPosition = null;
    private selectionAnchorRowIndex: number | null = null;

    readonly rowCount: number;
    readonly columnCount: number;
    mode: GridNavigationMode = 'rowing';
    isRowingOnly: boolean;
    withWrap: boolean;
    lastColumnIndex: number | undefined;

    constructor(config: GridPointerConfig) {
        this.rowCount = config.rowCount ?? 0;
        this.columnCount = config.columnCount ?? 0;
        this.isRowingOnly = config.isRowingOnly ?? true;
        this.withWrap = config.withWrap;
        this.lastColumnIndex = undefined;
    }

    get current(): GridPointerPosition {
        return this.position;
    }

    get selectionAnchor(): number | null {
        return this.selectionAnchorRowIndex;
    }

    setPosition(position: GridPointerPosition, shiftKey = false): GridPointerState {
        if (shiftKey) {
            this.ensureSelectionAnchor();
        } else {
            this.clearSelectionAnchor();
        }
        this.position = this.normalizePosition(position);
        return this.result();
    }

    setMode(mode: GridNavigationMode): GridPointerState {
        this.mode = mode;
        this.position = this.normalizePosition(this.position);
        this.clearSelectionAnchor();
        return this.result();
    }

    getMode(): 'rowing' | 'cellular' {
        return this.mode;
    }

    setWrap(withWrap: boolean): void {
        this.withWrap = withWrap;
    }

    resetToFirstHeader(): GridPointerState {
        this.position = { type: 'header', columnIndex: 0 };
        this.lastColumnIndex = 0;
        this.clearSelectionAnchor();
        return this.result();
    }

    moveUp(shiftKey = false): GridPointerState {
        return this.moveVertical('up', shiftKey);
    }

    moveDown(shiftKey = false): GridPointerState {
        return this.moveVertical('down', shiftKey);
    }

    changeMode(): GridPointerState {
        if (this.isRowingOnly) {
            return this.result();
        }
        return this.setMode(this.mode === 'rowing' ? 'cellular' : 'rowing');
    }

    moveLeft(): GridPointerState {
        this.clearSelectionAnchor();

        if (this.position === null) {
            return this.resetToFirstHeader();
        }

        if (this.position.type === 'header') {
            this.position = {
                type: 'header',
                columnIndex: this.previousIndex(this.position.columnIndex, this.columnCount),
            };
            this.rememberColumn(this.position.columnIndex);
            return this.result();
        }

        if (this.mode === 'cellular' && this.position.type === 'cell') {
            this.position = {
                type: 'cell',
                rowIndex: this.position.rowIndex,
                columnIndex: this.previousIndex(this.position.columnIndex, this.columnCount),
            };
            this.rememberColumn(this.position.columnIndex);
        }

        return this.result();
    }

    moveRight(): GridPointerState {
        this.clearSelectionAnchor();

        if (this.position === null) {
            return this.resetToFirstHeader();
        }

        if (this.position.type === 'header') {
            this.position = {
                type: 'header',
                columnIndex: this.nextIndex(this.position.columnIndex, this.columnCount),
            };
            this.rememberColumn(this.position.columnIndex);
            return this.result();
        }

        if (this.mode === 'cellular' && this.position.type === 'cell') {
            this.position = {
                type: 'cell',
                rowIndex: this.position.rowIndex,
                columnIndex: this.nextIndex(this.position.columnIndex, this.columnCount),
            };
            this.rememberColumn(this.position.columnIndex);
        }

        return this.result();
    }

    moveHome(shiftKey = false): GridPointerState {
        if (shiftKey) {
            return this.moveToRowBoundary('home');
        }

        this.clearSelectionAnchor();

        if (this.position === null) {
            return this.resetToFirstHeader();
        }

        if (this.position.type === 'header') {
            this.position = { type: 'header', columnIndex: 0 };
            this.rememberColumn(0);
            return this.result();
        }

        if (this.mode === 'rowing' && this.position.type === 'row') {
            this.position = { type: 'row', rowIndex: 0 };
            return this.result();
        }

        if (this.mode === 'cellular' && this.position.type === 'cell') {
            this.position = { type: 'cell', rowIndex: this.position.rowIndex, columnIndex: 0 };
            this.rememberColumn(0);
        }

        return this.result();
    }

    moveEnd(shiftKey = false): GridPointerState {
        if (shiftKey) {
            return this.moveToRowBoundary('end');
        }

        this.clearSelectionAnchor();

        if (this.position === null) {
            return this.resetToFirstHeader();
        }

        if (this.position.type === 'header') {
            this.position = { type: 'header', columnIndex: this.clampColumn(this.columnCount - 1) };
            this.rememberColumn(this.position.columnIndex);
            return this.result();
        }

        if (this.mode === 'rowing' && this.position.type === 'row') {
            this.position = { type: 'row', rowIndex: this.clampRow(this.rowCount - 1) };
            return this.result();
        }

        if (this.mode === 'cellular' && this.position.type === 'cell') {
            this.position = {
                type: 'cell',
                rowIndex: this.position.rowIndex,
                columnIndex: this.clampColumn(this.columnCount - 1),
            };
            this.rememberColumn(this.position.columnIndex);
        }

        return this.result();
    }

    selectAll(): GridPointerState {
        if (this.mode === 'rowing') {
            this.moveHome();
            this.moveEnd(true);
        }
        return this.result();
    }

    getSelectionRange(): number[] | null {
        const row = this.currentRowPosition();

        if (this.selectionAnchorRowIndex === null || row === null) {
            return null;
        }

        return this.buildRange(this.selectionAnchorRowIndex, row.rowIndex);
    }

    private moveVertical(
        direction: Exclude<Direction, 'home' | 'end'>,
        shiftKey: boolean,
    ): GridPointerState {
        if (shiftKey) {
            this.ensureSelectionAnchor();
        } else {
            this.clearSelectionAnchor();
        }

        if (this.position === null) {
            return this.resetToFirstHeader();
        }

        if (this.mode === 'rowing') {
            this.position = this.moveVerticalInRowing(this.position, direction);
        } else {
            this.position = this.moveVerticalInCellular(this.position, direction);
        }

        return this.result();
    }

    private moveVerticalInRowing(
        position: NonNullGridPointerPosition,
        direction: Exclude<Direction, 'home' | 'end'>,
    ): GridPointerPosition {
        if (position.type === 'header') {
            if (direction === 'down') {
                return { type: 'row', rowIndex: 0 };
            }

            if (direction === 'up' && this.withWrap) {
                return { type: 'row', rowIndex: this.rowCount - 1 };
            }

            return position;
        }

        const rowIndex = position.rowIndex;

        if (direction === 'up') {
            if (rowIndex === 0) {
                return { type: 'header', columnIndex: this.lastColumnIndex ?? 0 };
            }

            return { type: 'row', rowIndex: rowIndex - 1 };
        }

        if (rowIndex === this.rowCount - 1) {
            return this.withWrap ? { type: 'header', columnIndex: this.lastColumnIndex ?? 0 } : position;
        }

        return { type: 'row', rowIndex: rowIndex + 1 };
    }

    private moveVerticalInCellular(
        position: NonNullGridPointerPosition,
        direction: Exclude<Direction, 'home' | 'end'>,
    ): GridPointerPosition {
        if (position.type === 'header') {
            if (direction === 'down') {
                return { type: 'cell', rowIndex: 0, columnIndex: this.clampColumn(position.columnIndex) };
            }

            if (direction === 'up' && this.withWrap) {
                return {
                    type: 'cell',
                    rowIndex: this.rowCount - 1,
                    columnIndex: this.clampColumn(position.columnIndex),
                };
            }

            return position;
        }

        if (position.type === 'row') {
            return this.normalizePosition(position);
        }

        if (direction === 'up') {
            if (position.rowIndex === 0) {
                return { type: 'header', columnIndex: position.columnIndex };
            }

            return { type: 'cell', rowIndex: position.rowIndex - 1, columnIndex: position.columnIndex };
        }

        if (position.rowIndex === this.rowCount - 1) {
            return this.withWrap ? { type: 'header', columnIndex: position.columnIndex } : position;
        }

        return { type: 'cell', rowIndex: position.rowIndex + 1, columnIndex: position.columnIndex };
    }

    private moveToRowBoundary(direction: Extract<Direction, 'home' | 'end'>): GridPointerState {
        this.ensureSelectionAnchor();
        const row = this.currentRowPosition();

        if (row === null) {
            return this.result();
        }

        const rowIndex = direction === 'home' ? 0 : this.clampRow(this.rowCount - 1);
        this.position =
            this.mode === 'rowing'
                ? { type: 'row', rowIndex: rowIndex ?? 0 }
                : { type: 'cell', rowIndex: rowIndex ?? 0, columnIndex: this.lastColumnIndex ?? 0 };

        return this.result();
    }

    private normalizePosition(position: GridPointerPosition): GridPointerPosition {
        if (position === null) {
            return null;
        }

        if (position.type === 'header') {
            const columnIndex = this.clampColumn(position.columnIndex);
            this.rememberColumn(columnIndex);
            return { type: 'header', columnIndex };
        }

        if (position.type === 'row') {
            const rowIndex = this.clampRow(position.rowIndex);

            if (this.mode === 'cellular') {
                return { type: 'cell', rowIndex, columnIndex: this.lastColumnIndex ?? 0 };
            }

            return { type: 'row', rowIndex };
        }

        const cell = {
            type: 'cell',
            rowIndex: this.clampRow(position.rowIndex),
            columnIndex: this.clampColumn(position.columnIndex),
        } as CellPointerPosition;
        this.rememberColumn(cell.columnIndex);

        if (this.mode === 'rowing') {
            return { type: 'row', rowIndex: cell.rowIndex };
        }

        return cell;
    }

    private ensureSelectionAnchor(): void {
        if (this.mode !== 'rowing') {
            return;
        }

        if (this.selectionAnchorRowIndex !== null) {
            return;
        }

        const row = this.currentRowPosition();
        this.selectionAnchorRowIndex = row?.rowIndex ?? null;
    }

    private clearSelectionAnchor(): void {
        this.selectionAnchorRowIndex = null;
    }

    private currentRowPosition(): RowPointerPosition | null {
        if (this.position === null) {
            return null;
        }

        if (this.position.type === 'row') {
            return this.position;
        }

        if (this.position.type === 'cell') {
            return { type: 'row', rowIndex: this.position.rowIndex };
        }

        return null;
    }

    private previousIndex(index: number, count: number): number {
        if (index <= 0) {
            return this.withWrap ? count - 1 : 0;
        }

        return index - 1;
    }

    private nextIndex(index: number, count: number): number {
        if (index >= count - 1) {
            return this.withWrap ? 0 : count - 1;
        }

        return index + 1;
    }

    private clampRow(rowIndex: number): number {
        return this.clamp(rowIndex, this.rowCount);
    }

    private clampColumn(columnIndex: number): number {
        return this.clamp(columnIndex, this.columnCount);
    }

    private clamp(index: number, count: number): number {
        return Math.min(index, count - 1);
    }

    private rememberColumn(columnIndex: number): void {
        this.lastColumnIndex = this.clampColumn(columnIndex);
    }

    private result(): GridPointerState {
        return {
            position: this.current,
            selectedRowRange: this.getSelectionRange(),
        };
    }

    private buildRange(start: number, end: number): number[] {
        const from = Math.min(start, end);
        const to = Math.max(start, end);

        return Array.from({ length: to - from + 1 }, (_, offset) => from + offset);
    }
}
