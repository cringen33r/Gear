export function getCellId(rowId: string, columnId: string): string;
export function getCellId(rowId: number, columnId: number): string;
export function getCellId(rowId: number | string, columnId: number | string): string {
    return `${rowId}:${columnId}`;
}

export function getRowColumnIds(cellId: string | undefined): string[] {
    return cellId?.split(':') ?? [];
}

export function getUnitedColumnsIfNeeded(columnsToUnite: string[], column: string | undefined): string | undefined {
    const separated = getRowColumnIds(column);
    const isCellId = separated?.length === 2;
    const toCheck = isCellId ? separated[1] : column;
    if (toCheck && columnsToUnite.includes(toCheck)) {
        return isCellId ? getCellId(separated[0], columnsToUnite[0]) : columnsToUnite[0];
    } else {
        return column;
    }
}
