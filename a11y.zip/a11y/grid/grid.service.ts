import { fromEvent, shareReplay, Subject, Subscription, throttleTime } from 'rxjs';
import { distinctUntilChanged, filter, map, takeUntil } from 'rxjs/operators';
import { computed, DestroyRef, inject, Injectable, signal } from '@angular/core';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';

import {
    CustomGridActions,
    GridAction,
    GridBasicAction,
    GridConfig,
    GridEntity,
    GridEntityAction,
    GridPointerState,
    KnownKeys,
    MappedPointerState,
} from './grid.types';
import { GridPointer } from './grid-pointer';
import { getCellId } from './grid-utils';
import { FocusMonitor, InteractivityChecker } from '@angular/cdk/a11y';
import { getNextFocusable } from '../focus-utils';
import { injectDebugFor } from '../../../../../debug';
import { GRID_KEYBOARD_ENABLED_TOKEN } from './grid-keyboard-enabled.token';
import { badKeys, downKeys, upKeys } from './grid-keyboard-defaults.config';

@Injectable()
export class GridService {
    private readonly destroyRef = inject(DestroyRef);
    private readonly focusMonitor = inject(FocusMonitor);
    private readonly checker = inject(InteractivityChecker);
    private readonly featureToken = inject(GRID_KEYBOARD_ENABLED_TOKEN);
    private readonly debug = injectDebugFor('GRID');

    config!: GridConfig;
    private _pointer!: GridPointer;
    private keydownSubscription!: Subscription;
    private keyupSubscription!: Subscription;

    private readonly gridIds = new Map<'rows' | 'columns', string[]>([
        ['rows', []],
        ['columns', []],
    ]);
    private customGridActions: CustomGridActions[] = [];

    private readonly pointerState = signal<GridPointerState | null>(null);
    readonly pointer = computed<MappedPointerState | null>(() => this.mapPointerState(this.pointerState()));
    readonly mode = signal<'rowing' | 'cellular' | undefined>(undefined);
    readonly pointer$ = toObservable(this.pointer).pipe(takeUntilDestroyed(this.destroyRef));

    private readonly gridActionSubject$ = new Subject<GridAction | null>();
    readonly gridAction$ = this.gridActionSubject$.pipe(
        filter(Boolean),
        takeUntilDestroyed(this.destroyRef),
    );
    readonly isFocusTrapActive = signal(false);
    private readonly preventTab = computed(() => !this.isFocusTrapActive());

    private readonly customActionSubject$ = new Subject<string>();
    readonly customAction$ = this.customActionSubject$.pipe(
        filter(Boolean),
        takeUntilDestroyed(this.destroyRef),
    );

    private lastPointerState: GridPointerState | null = null;
    private readonly resetSubscriptions$ = new Subject<void>();

    private readonly keyHandlers: Record<KnownKeys, (
        event: KeyboardEvent,
        pointer: MappedPointerState,
    ) => void> = {
        'ArrowDown': this.moveDown,
        'ArrowUp': this.moveUp,
        'ArrowLeft': this.moveLeft,
        'ArrowRight': this.moveRight,
        'Home': this.moveHome,
        'End': this.moveEnd,
        'KeyA': this.selectAll,
        'AltLeft': this.changeMode,
        'Enter': this.emitPrimaryAction,
        'Space': this.emitSecondaryAction,
        'AnyKey': this.emitCustomAction,
    };

    constructor() {
        this.debug.raw(this.pointerState());
    }

    init(config: GridConfig): void {
        if (this.featureToken) {
            this.lastPointerState = this.pointerState();
            this.resetSubscriptions$.next();
            this.debug.log('SERVICE', 'INIT', 'INIT');
            this.config = config;
            this._pointer = new GridPointer({
                rowCount: config.rowIds.length,
                columnCount: config.columnIds.length,
                isRowingOnly: config.isRowingOnly ?? true,
                withWrap: config.withWrap ?? false,
            });
            this.gridIds.set('rows', config.rowIds);
            this.gridIds.set('columns', config.columnIds);
            this.customGridActions = config.customGridActions ?? [];
            this.subscribeToTableFocused();
        }
    }

    getActionFor(entity: GridEntity, action: GridBasicAction): GridEntityAction | undefined {
        const actionsConfig = this.config.gridActionsConfig;
        if (actionsConfig) {
            return actionsConfig[entity]?.[action];
        }
        return undefined;
    }

    changePointerTo(entity: GridEntity, id: string, shiftKey = false): void {
        switch (entity) {
            case 'cell':
                if (this._pointer.mode === 'cellular') {
                    this.pointerState.set(this._pointer.setPosition({
                        type: 'cell',
                        rowIndex: this.getIndex('rows', id.split(':')[0]),
                        columnIndex: this.getIndex('columns', id.split(':')[1]),
                    }));
                }
                break;
            case 'row': {
                if (this._pointer.mode === 'rowing') {
                    this.pointerState.set(this._pointer.setPosition({
                        type: 'row',
                        rowIndex: this.getIndex('rows', id),
                    }, shiftKey));
                }
                break;
            }
            case 'header':
                this.pointerState.set(this._pointer.setPosition({
                    type: 'header',
                    columnIndex: this.getIndex('columns', id),
                }));
                break;
        }
    }

    getIndex(line: 'rows' | 'columns', id: string): number {
        return this.gridIds.get(line)?.indexOf(id) ?? 0;
    }

    focusTable(): void {
        this.config.getHost().focus();
    }

    private subscribeToTableFocused(): void {
        this.setupFocusListener();
        this.setupKeyboardListener();
    }

    private setupFocusListener(): void {
        this.focusMonitor.monitor(this.config.getHost(), true).pipe(
            distinctUntilChanged((prev, cur) => !!prev === !!cur),
            takeUntilDestroyed(this.destroyRef),
            takeUntil(this.resetSubscriptions$),
        ).subscribe(focus => {
            if (focus) {
                this.debug.log('POINTER', 'FOCUS', 'Reset to header');
                this.pointerState.set(this._pointer.resetToFirstHeader());
            } else {
                this.pointerState.set(this._pointer.setPosition(null));
            }
        });
    }

    private moveDown(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('NAVIGATION', 'DOWN');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.moveDown(event.shiftKey));
    }

    private moveUp(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('NAVIGATION', 'UP');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.moveUp(event.shiftKey));
    }

    private moveLeft(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('NAVIGATION', 'LEFT');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.moveLeft());
    }

    private moveRight(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('NAVIGATION', 'RIGHT');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.moveRight());
    }

    private moveHome(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('NAVIGATION', 'HOME');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.moveHome(event.shiftKey));
    }

    private moveEnd(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('NAVIGATION', 'END');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.moveEnd(event.shiftKey));
    }

    private changeMode(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('ACTION', 'SELECT_ALL');
        this.debug.raw(pointer);
        this.pointerState.set(this._pointer.changeMode());
        this.mode.set(this._pointer.getMode());
    }

    private selectAll(event: KeyboardEvent, pointer: MappedPointerState): void {
        if (event.ctrlKey && this.mode() === 'rowing') {
            this.debug.log('ACTION', 'SELECT_ALL');
            this.debug.raw(pointer);
            this.pointerState.set(this._pointer.selectAll());
            window.getSelection()?.removeAllRanges();
        }
    }

    private emitPrimaryAction(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('ACTION', 'PRIMARY', `Primary action sent`);
        this.debug.raw(pointer);
        this.gridActionSubject$.next({
            action: 'primary',
            currentPointer: pointer,
        });
    }

    private emitSecondaryAction(event: KeyboardEvent, pointer: MappedPointerState): void {
        this.debug.log('ACTION', 'SECONDARY', `Secondary action sent`);
        this.debug.raw(pointer);
        this.gridActionSubject$.next({
            action: 'secondary',
            currentPointer: pointer,
        });
    }

    private emitCustomAction(event: KeyboardEvent, pointer: MappedPointerState): void {
        for (const action of this.customGridActions) {
            if (
                action.key === event.code
                && ((action.ctrlKey === event.ctrlKey) || !action.ctrlKey)
                && ((action.altKey === event.altKey) || !action.altKey)
                && ((action.metaKey === event.metaKey) || !action.metaKey)
                && ((action.shiftKey === event.shiftKey) || !action.shiftKey)
            ) {
                this.customActionSubject$.next(action.name);
            }
        }
    }

    private eventHandling(event: KeyboardEvent): void {
        const pointer = this.pointer();
        if (this.preventTab() && event.code === 'Tab') {
            event.preventDefault();
            const nextToFocus = getNextFocusable(
                this.config.getHost(),
                event.shiftKey ? 'backward' : 'forward',
                this.checker,
                this.debug,
            );
            nextToFocus?.focus();
        }
        if (pointer) {
            const handler = this.keyHandlers[event.code as KnownKeys];
            if (handler) {
                handler.call(this, event, pointer);
            } else {
                this.keyHandlers['AnyKey'].call(this, event, pointer);
            }
        }
    }

    private eventPreHandling(event: KeyboardEvent): KeyboardEvent {
        if (badKeys.includes(event.code)) {
            this.debug.log('KEY_PREVENT', event.code, 'Bad key prevented');
            event.preventDefault();
            event.stopImmediatePropagation();
        }
        return event;
    }

    private setupKeyboardListener(): void {
        this.keyupSubscription ??= fromEvent<KeyboardEvent>(this.config.getHost(), 'keyup').pipe(
            map(event => this.eventPreHandling(event)),
            filter(event => upKeys.includes(event.code)),
            throttleTime(32),
            takeUntilDestroyed(this.destroyRef),
        ).subscribe(event => {
            this.debug.log('KEY_UP', event.code, 'Start handling');
            this.eventHandling(event);
        });

        this.keydownSubscription ??= fromEvent<KeyboardEvent>(this.config.getHost(), 'keydown').pipe(
            map(event => this.eventPreHandling(event)),
            filter(event => downKeys.includes(event.code)),
            throttleTime(32),
            takeUntilDestroyed(this.destroyRef),
        ).subscribe(event => {
            this.debug.log('KEY_DOWN', event.code, 'Start handling');
            this.eventHandling(event);
        });
    }

    private mapPointerState(pointerState: GridPointerState | null): MappedPointerState | null {
        if (pointerState) {
            const mappedPointerState: MappedPointerState = {
                targetId: undefined,
                state: pointerState,
                selectedTargetIds: null,
            };
            if (!pointerState.position) {
                return null;
            }
            const pos = pointerState.position;

            switch (pos.type) {
                case 'row':
                    mappedPointerState.targetId = this.gridIds.get('rows')?.[pos.rowIndex];
                    if (mappedPointerState.state.selectedRowRange) {
                        mappedPointerState.selectedTargetIds = pointerState.selectedRowRange?.map(rowId => {
                            return this.gridIds.get('rows')?.[rowId] as string;
                        }) ?? null;
                    }
                    break;
                case 'header':
                    mappedPointerState.targetId = this.gridIds.get('columns')?.[pos.columnIndex];
                    break;
                case 'cell':
                    mappedPointerState.targetId = getCellId(this.gridIds.get('rows')?.[pos.rowIndex] ?? '', this.gridIds.get('columns')?.[pos.columnIndex] ?? '');
                    break;
            }
            return mappedPointerState;
        }
        return null;
    }
}
