export type GridEntity = 'header' | 'row' | 'cell';
export type GridBasicAction = 'primary' | 'secondary';
export interface GridAction {
    action: GridBasicAction;
    currentPointer: MappedPointerState;
}

export interface HeaderPointerPosition {
    type: 'header';
    columnIndex: number;
}

export interface RowPointerPosition {
    type: 'row';
    rowIndex: number;
}

export interface CellPointerPosition {
    type: 'cell';
    rowIndex: number;
    columnIndex: number;
}

export type GridPointerPosition =
  HeaderPointerPosition | RowPointerPosition | CellPointerPosition | null;

export type GridNavigationMode = 'rowing' | 'cellular';

export interface GridPointerConfig {
    rowCount: number;
    columnCount: number;
    isRowingOnly: boolean;
    withWrap: boolean;
}

export interface GridPointerState {
    position: GridPointerPosition;
    selectedRowRange: number[] | null;
}

export interface MappedPointerState {
    targetId: string | undefined;
    state: GridPointerState;
    selectedTargetIds: string[] | null;
}

export interface CustomGridActions {
    name: string;
    key: string;
    ctrlKey?: boolean;
    altKey?: boolean;
    metaKey?: boolean;
    shiftKey?: boolean;
}

/** Внутренний конфиг, формируемый на уровне {@link `TreeTableComponent`} */
export type GridConfig = {
    rowIds: string[];
    columnIds: string[];
    getHost: () => HTMLElement;
} & GridSettings;

export type RowPrimaryAction = 'toggle-context-panel' | undefined;
export type RowSecondaryAction = 'check' | 'expand' | undefined;
export type RowAction = RowPrimaryAction | RowSecondaryAction;
export type CellPrimaryAction = 'focus-first';
export type GridEntityAction = RowAction | CellPrimaryAction;
export type KnownKeys =
    'ArrowDown' | 'ArrowUp' | 'ArrowLeft' | 'ArrowRight'
    | 'Home' | 'End'
    | 'AltLeft'
    | 'KeyA'
    | 'Enter'
    | 'Space'
    | 'AnyKey';

export interface GridActionsConfig {
    header: {
        primary: CellPrimaryAction;
        secondary: undefined;
    };
    cell: {
        primary: CellPrimaryAction;
        secondary: undefined;
    };
    row: {
        primary: RowPrimaryAction;
        secondary: RowSecondaryAction;
    };
}

export interface GridSettings {
    /** Конфигурация действий сущностей таблицы */
    gridActionsConfig?: Partial<GridActionsConfig>;
    /** Осуществляется ли навигация по таблице только по строкам */
    isRowingOnly?: boolean;
    /** Должна ли навигация по крайним элементам быть закольцованной */
    withWrap?: boolean;
    /** Кастомные действия, чья логика реализована на стороне модуля */
    customGridActions?: CustomGridActions[];
    /** Идентификаторы колонок, которые должны обрабатываться как единое целое */
    columnsToUnite?: string[];
}
