import { DestroyRef, inject, Injectable } from '@angular/core';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FocusRealmRouterService } from './focus-realm';
import { injectDebugFor } from '../../../../debug';

@Injectable({
    providedIn: 'root',
})
export class HotkeysService {
    private readonly destroyRef = inject(DestroyRef);
    private readonly focusRouter = inject(FocusRealmRouterService);

    init(): void {
        fromEvent<KeyboardEvent>(document.body, 'keydown')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(event => {
                if (event.code === 'Tab' && event.ctrlKey) {
                    event.preventDefault();
                    if (event.shiftKey) {
                        this.jumpPrevRealm();
                    } else {
                        this.jumpNextRealm();
                    }
                }
            });
    }

    private showHotkeysInfo(): void {

    }

    private jumpNextRealm(): void {
        this.focusRouter.routingRequestSubject$.next({
            hostRealmId: this.focusRouter.currentRealm(),
            direction: 'forward',
        });
    }

    private jumpPrevRealm(): void {
        this.focusRouter.routingRequestSubject$.next({
            hostRealmId: this.focusRouter.currentRealm(),
            direction: 'backward',
        });
    }
}
